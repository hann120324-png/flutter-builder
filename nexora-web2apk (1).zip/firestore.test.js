const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_hann";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function pastDate(offsetMs = 5000) {
  return new Date(Date.now() - offsetMs);
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write protected collections", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("builds").where("userId", "==", ALICE_UID).get());
  await assertFails(unauthDb.collection("packages").get());
  await assertFails(unauthDb.collection("settings").doc("platform").get());
  await assertFails(
    unauthDb.collection("builds").doc("b1").set({
      userId: ALICE_UID,
      appName: "Test",
      packageName: "com.nexora.test",
      versionName: "1.0.0",
      versionCode: 1,
      sourceType: "url",
      sourceValue: "https://example.com",
      splashType: "default",
      orientation: "portrait",
      permissions: ["INTERNET"],
      status: "waiting",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
});

test("Users: owner create/update works; role escalation & shadow fields fail", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const created = pastDate(10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice",
      email: "alice@example.com",
      role: "user",
      status: "active",
      plan: "free",
      createdAt: created,
      updatedAt: created,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      name: "Alice Updated",
      updatedAt: pastDate(1000),
    })
  );

  // Reject self-escalation to admin or pro without paid transaction
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "admin",
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      plan: "pro",
      updatedAt: pastDate(500),
    })
  );

  // Reject Ghost / Shadow field on create
  await assertFails(
    aliceDb.collection("users").doc("alice_shadow").set({
      userId: "alice_shadow",
      name: "Shadow",
      email: "s@example.com",
      role: "user",
      status: "active",
      plan: "free",
      isVerified: true,
      createdAt: created,
      updatedAt: created,
    })
  );
});

test("Users: Pro upgrade succeeds only when backed by a paid transaction", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, {
    email: "alice@example.com",
    email_verified: true,
  }).firestore();
  const created = pastDate(10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      name: "Alice",
      email: "alice@example.com",
      role: "user",
      status: "active",
      plan: "free",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Create pending transaction
  await assertSucceeds(
    aliceDb.collection("transactions").doc("NX_ORDER_1").set({
      userId: ALICE_UID,
      orderId: "NX_ORDER_1",
      packageCode: "pro",
      amount: 10000,
      status: "pending",
      paymentMethod: "qris",
      qrString: "000201010212...",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Cannot upgrade while transaction is still pending
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      plan: "pro",
      lastPaidOrderId: "NX_ORDER_1",
      updatedAt: pastDate(2000),
    })
  );

  // Mark transaction paid with midtransTransactionId
  await assertSucceeds(
    aliceDb.collection("transactions").doc("NX_ORDER_1").update({
      status: "paid",
      midtransTransactionId: "mid-tx-999",
      paidAt: pastDate(1500),
      updatedAt: pastDate(1500),
    })
  );

  // Now user can activate Pro subscription & profile plan
  await assertSucceeds(
    aliceDb.collection("subscriptions").doc(ALICE_UID).set({
      userId: ALICE_UID,
      packageCode: "pro",
      status: "active",
      orderId: "NX_ORDER_1",
      startedAt: pastDate(1000),
      updatedAt: pastDate(1000),
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      plan: "pro",
      lastPaidOrderId: "NX_ORDER_1",
      updatedAt: pastDate(1000),
    })
  );
});

test("Builds: owner CRUD, terminal state lock, and cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = pastDate(10000);

  await assertSucceeds(
    aliceDb.collection("builds").doc("build_1").set({
      userId: ALICE_UID,
      appName: "Toko Saya",
      packageName: "com.nexora.tokosaya",
      versionName: "1.0.0",
      versionCode: 1,
      sourceType: "url",
      sourceValue: "https://tokosaya.id",
      splashType: "default",
      orientation: "portrait",
      permissions: ["INTERNET"],
      status: "processing",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Update from processing -> success
  await assertSucceeds(
    aliceDb.collection("builds").doc("build_1").update({
      buildId: "rfb_101",
      status: "success",
      fileName: "toko-saya.apk",
      fileSize: "4.2 MB",
      downloadUrl: "https://rfweb2apk.rfdevv.com/dl/toko-saya.apk",
      updatedAt: pastDate(1000),
    })
  );

  // Terminal state lock: owner cannot mutate after success
  await assertFails(
    aliceDb.collection("builds").doc("build_1").update({
      status: "failed",
      updatedAt: pastDate(500),
    })
  );

  // Bob cannot read Alice's build or list unfiltered
  await assertFails(bobDb.collection("builds").doc("build_1").get());
  await assertFails(bobDb.collection("builds").get());

  // Filtered query for Alice succeeds
  await assertSucceeds(
    aliceDb.collection("builds").where("userId", "==", ALICE_UID).get()
  );
});

test("BuildUsage: owner daily counter create & increment by 1", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const docId = `${ALICE_UID}_20261119`;

  // Reading non-existent doc for own UID succeeds
  await assertSucceeds(aliceDb.collection("build_usage").doc(docId).get());

  await assertSucceeds(
    aliceDb.collection("build_usage").doc(docId).set({
      userId: ALICE_UID,
      date: "2026-11-19",
      totalBuild: 1,
      updatedAt: pastDate(5000),
    })
  );

  await assertSucceeds(
    aliceDb.collection("build_usage").doc(docId).update({
      totalBuild: 2,
      updatedAt: pastDate(1000),
    })
  );

  // Cannot decrement or jump quota
  await assertFails(
    aliceDb.collection("build_usage").doc(docId).update({
      totalBuild: 0,
      updatedAt: pastDate(500),
    })
  );
});

test("Admin: verified admin email succeeds; spoofed unverified email fails", async () => {
  const spoofedAdminDb = testEnv.authenticatedContext("spoof_uid", {
    email: "hann120324@gmail.com",
    email_verified: false,
  }).firestore();

  const realAdminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: "hann120324@gmail.com",
    email_verified: true,
  }).firestore();

  await assertFails(spoofedAdminDb.collection("users").get());
  await assertFails(
    spoofedAdminDb.collection("settings").doc("platform").set({
      platformName: "Hacked",
      tagline: "Hacked",
      description: "Hacked",
      updatedAt: pastDate(1000),
    })
  );

  await assertSucceeds(realAdminDb.collection("users").get());
  await assertSucceeds(
    realAdminDb.collection("settings").doc("platform").set({
      platformName: "NEXORA WEB2APK",
      tagline: "Your Website, Your Android App.",
      description: "Platform builder APK online.",
      whatsappAdmin: "6281234567890",
      updatedAt: pastDate(1000),
    })
  );

  await assertSucceeds(
    realAdminDb.collection("audit_logs").doc("log_1").set({
      adminId: ADMIN_UID,
      adminEmail: "hann120324@gmail.com",
      action: "UPDATE_SETTINGS",
      details: "Updated WhatsApp admin number",
      createdAt: pastDate(1000),
    })
  );

  // Audit logs are immutable
  await assertFails(
    realAdminDb.collection("audit_logs").doc("log_1").update({
      action: "TAMPERED",
    })
  );
});
