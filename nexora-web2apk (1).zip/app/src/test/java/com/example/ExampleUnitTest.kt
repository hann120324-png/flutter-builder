package com.example

import com.example.data.model.BuildStatus
import com.example.data.model.PlanTier
import com.example.data.model.SourceType
import com.example.data.model.TransactionStatus
import com.example.data.remote.RfBuilderService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun `valid android package names pass regex`() {
    assertTrue(RfBuilderService.isValidPackageName("com.nexora.aplikasi"))
    assertTrue(RfBuilderService.isValidPackageName("id.co.tokoku.app2"))
    assertFalse(RfBuilderService.isValidPackageName("invalid"))
    assertFalse(RfBuilderService.isValidPackageName("Com.Nexora.App"))
    assertFalse(RfBuilderService.isValidPackageName("com..app"))
  }

  @Test
  fun `domain enums parse known and fallback values`() {
    assertEquals(BuildStatus.SUCCESS, BuildStatus.from("success"))
    assertEquals(BuildStatus.WAITING, BuildStatus.from("unknown"))
    assertEquals(SourceType.ZIP, SourceType.from("zip"))
    assertEquals(PlanTier.PRO, PlanTier.from("pro"))
    assertEquals(TransactionStatus.PAID, TransactionStatus.from("paid"))
  }
}
