package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AccountStatus
import com.example.data.model.ApkBuild
import com.example.data.model.BuildStatus
import com.example.data.model.PlanTier
import com.example.data.model.ScreenOrientationOption
import com.example.data.model.SourceType
import com.example.data.model.SplashType
import com.example.data.model.UserProfile
import com.example.data.remote.RfBuildRequest
import com.example.data.remote.RfBuildResult
import com.example.data.remote.RfBuilderService
import com.example.data.repository.NexoraRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AndroidPermissionOption(
    val name: String,
    val description: String,
    val isSensitive: Boolean = false
)

val ALL_ANDROID_PERMISSIONS = listOf(
    AndroidPermissionOption("INTERNET", "Akses jaringan internet untuk memuat website."),
    AndroidPermissionOption("ACCESS_NETWORK_STATE", "Memeriksa status koneksi internet."),
    AndroidPermissionOption("ACCESS_WIFI_STATE", "Memeriksa status jaringan Wi-Fi."),
    AndroidPermissionOption("VIBRATE", "Mengaktifkan getaran perangkat."),
    AndroidPermissionOption("WAKE_LOCK", "Menjaga layar tetap aktif saat diperlukan."),
    AndroidPermissionOption("FOREGROUND_SERVICE", "Menjalankan layanan latar depan."),
    AndroidPermissionOption("POST_NOTIFICATIONS", "Menampilkan notifikasi Android 13+.", isSensitive = true),
    AndroidPermissionOption("CAMERA", "Akses kamera perangkat untuk foto/scan QR.", isSensitive = true),
    AndroidPermissionOption("RECORD_AUDIO", "Akses mikrofon untuk rekam suara/panggilan.", isSensitive = true),
    AndroidPermissionOption("READ_EXTERNAL_STORAGE", "Baca file penyimpanan lama (Android <= 12).", isSensitive = true),
    AndroidPermissionOption("WRITE_EXTERNAL_STORAGE", "Tulis file penyimpanan lama (Android <= 10).", isSensitive = true),
    AndroidPermissionOption("ACCESS_FINE_LOCATION", "Akses lokasi GPS presisi.", isSensitive = true),
    AndroidPermissionOption("ACCESS_COARSE_LOCATION", "Akses lokasi perkiraan berbasis jaringan.", isSensitive = true),
    AndroidPermissionOption("READ_CONTACTS", "Membaca daftar kontak pengguna.", isSensitive = true),
    AndroidPermissionOption("WRITE_CONTACTS", "Menulis atau mengubah kontak.", isSensitive = true),
    AndroidPermissionOption("BLUETOOTH", "Koneksi perangkat Bluetooth klasik."),
    AndroidPermissionOption("BLUETOOTH_CONNECT", "Koneksi Bluetooth Android 12+.", isSensitive = true),
    AndroidPermissionOption("NFC", "Membaca tag atau transaksi NFC."),
    AndroidPermissionOption("USE_BIOMETRIC", "Autentikasi sidik jari / biometrik.")
)

data class BuildFormState(
    val currentStep: Int = 0,
    val appName: String = "",
    val packageName: String = "com.nexora.aplikasi",
    val versionName: String = "1.0.0",
    val versionCode: String = "1",
    val sourceType: SourceType = SourceType.URL,
    val url: String = "https://",
    val sourceFileUri: Uri? = null,
    val sourceFileName: String? = null,
    val iconUri: Uri? = null,
    val iconFileName: String? = null,
    val splashType: SplashType = SplashType.DEFAULT,
    val splashFileUri: Uri? = null,
    val splashFileName: String? = null,
    val orientation: ScreenOrientationOption = ScreenOrientationOption.PORTRAIT,
    val selectedPermissions: Set<String> = setOf("INTERNET", "ACCESS_NETWORK_STATE")
)

sealed interface BuildExecutionState {
    data object Idle : BuildExecutionState
    data class Processing(val docId: String) : BuildExecutionState
    data class Success(val docId: String, val result: RfBuildResult.Success) : BuildExecutionState
    data class Error(
        val docId: String?,
        val message: String,
        val isConfigError: Boolean = false,
        val isQuotaExhausted: Boolean = false
    ) : BuildExecutionState
}

class BuildViewModel(
    private val repository: NexoraRepository,
    private val rfBuilderService: RfBuilderService,
    private val currentUserId: String
) : ViewModel() {

    private val _form = MutableStateFlow(BuildFormState())
    val form = _form.asStateFlow()

    private val _executionState = MutableStateFlow<BuildExecutionState>(BuildExecutionState.Idle)
    val executionState = _executionState.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage = _statusMessage.asStateFlow()

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun setStep(step: Int) {
        _form.update { it.copy(currentStep = step.coerceIn(0, 6)) }
    }

    fun updateAppInfo(appName: String, packageName: String, versionName: String, versionCode: String) {
        _form.update {
            it.copy(
                appName = appName,
                packageName = packageName,
                versionName = versionName,
                versionCode = versionCode
            )
        }
    }

    fun updateSourceType(type: SourceType) {
        _form.update {
            it.copy(
                sourceType = type,
                sourceFileUri = if (type == SourceType.URL) null else it.sourceFileUri,
                sourceFileName = if (type == SourceType.URL) null else it.sourceFileName
            )
        }
    }

    fun updateUrl(url: String) {
        _form.update { it.copy(url = url) }
    }

    fun updateSourceFile(uri: Uri?, name: String?) {
        _form.update { it.copy(sourceFileUri = uri, sourceFileName = name) }
    }

    fun updateIcon(uri: Uri?, name: String?) {
        _form.update { it.copy(iconUri = uri, iconFileName = name) }
    }

    fun updateSplashType(type: SplashType) {
        _form.update {
            it.copy(
                splashType = type,
                splashFileUri = if (type == SplashType.DEFAULT) null else it.splashFileUri,
                splashFileName = if (type == SplashType.DEFAULT) null else it.splashFileName
            )
        }
    }

    fun updateSplashFile(uri: Uri?, name: String?) {
        _form.update { it.copy(splashFileUri = uri, splashFileName = name) }
    }

    fun updateOrientation(orientation: ScreenOrientationOption) {
        _form.update { it.copy(orientation = orientation) }
    }

    fun togglePermission(permission: String) {
        _form.update { state ->
            val next = state.selectedPermissions.toMutableSet()
            if (next.contains(permission)) next.remove(permission) else next.add(permission)
            state.copy(selectedPermissions = next)
        }
    }

    fun resetExecution() {
        _executionState.value = BuildExecutionState.Idle
    }

    fun prefillFromBuild(build: ApkBuild) {
        _form.value = BuildFormState(
            currentStep = 6,
            appName = build.appName,
            packageName = build.packageName,
            versionName = build.versionName,
            versionCode = build.versionCode.toString(),
            sourceType = SourceType.from(build.sourceType),
            url = if (build.sourceType == "url") build.sourceValue else "https://",
            splashType = SplashType.from(build.splashType),
            orientation = ScreenOrientationOption.from(build.orientation),
            selectedPermissions = build.permissions.toSet()
        )
        _executionState.value = BuildExecutionState.Idle
    }

    fun validateStep(step: Int): String? {
        val state = _form.value
        return when (step) {
            0 -> {
                if (state.appName.trim().isEmpty()) return "Nama aplikasi wajib diisi."
                if (!RfBuilderService.isValidPackageName(state.packageName)) {
                    return "Package name tidak valid. Gunakan format seperti com.nexora.aplikasi"
                }
                if (state.versionName.trim().isEmpty()) return "Version Name wajib diisi."
                val vc = state.versionCode.toIntOrNull()
                if (vc == null || vc < 1) return "Version Code harus berupa angka >= 1."
                null
            }
            1 -> {
                when (state.sourceType) {
                    SourceType.URL -> {
                        val u = state.url.trim()
                        if (!u.startsWith("https://") && !u.startsWith("http://")) {
                            "Masukkan URL website yang valid (https://...)."
                        } else null
                    }
                    SourceType.HTML -> if (state.sourceFileUri == null) "Pilih file HTML terlebih dahulu." else null
                    SourceType.ZIP -> if (state.sourceFileUri == null) "Pilih file ZIP proyek website terlebih dahulu." else null
                }
            }
            3 -> {
                if (state.splashType != SplashType.DEFAULT && state.splashFileUri == null) {
                    "Pilih file splash screen sesuai tipe ${state.splashType.label}."
                } else null
            }
            else -> null
        }
    }

    fun saveDraft() {
        val state = _form.value
        val sourceVal = when (state.sourceType) {
            SourceType.URL -> state.url.trim().ifBlank { "https://example.com" }
            else -> state.sourceFileName ?: state.sourceType.value
        }
        viewModelScope.launch {
            val res = repository.createBuildRecord(
                appName = state.appName.ifBlank { "Draft Aplikasi" },
                packageName = state.packageName.ifBlank { "com.nexora.draft" },
                versionName = state.versionName.ifBlank { "1.0.0" },
                versionCode = state.versionCode.toLongOrNull()?.coerceAtLeast(1L) ?: 1L,
                sourceType = state.sourceType.value,
                sourceValue = sourceVal,
                splashType = state.splashType.value,
                orientation = state.orientation.value,
                permissions = state.selectedPermissions.toList(),
                status = BuildStatus.DRAFT
            )
            _statusMessage.value = res.fold(
                onSuccess = { "Draft konfigurasi disimpan ke Riwayat Build." },
                onFailure = { it.localizedMessage ?: "Gagal menyimpan draft." }
            )
        }
    }

    fun startBuild(
        userProfile: UserProfile?,
        todayUsageCount: Int,
        freeDailyQuota: Int
    ) {
        if (_executionState.value is BuildExecutionState.Processing) return

        if (userProfile != null && AccountStatus.from(userProfile.status) == AccountStatus.SUSPENDED) {
            _executionState.value = BuildExecutionState.Error(
                docId = null,
                message = "Akun Anda sedang ditangguhkan. Hubungi Admin atau CS."
            )
            return
        }

        val plan = PlanTier.from(userProfile?.plan)
        if (plan == PlanTier.FREE && freeDailyQuota >= 0 && todayUsageCount >= freeDailyQuota) {
            _executionState.value = BuildExecutionState.Error(
                docId = null,
                message = "Kuota build harian kamu sudah habis. Upgrade ke Pro untuk mendapatkan kuota lebih besar.",
                isQuotaExhausted = true
            )
            return
        }

        for (step in 0..3) {
            val err = validateStep(step)
            if (err != null) {
                _executionState.value = BuildExecutionState.Error(null, err)
                return
            }
        }

        if (!rfBuilderService.isConfigured()) {
            _executionState.value = BuildExecutionState.Error(
                docId = null,
                message = "RFBUILDER_API_KEY belum dikonfigurasi di Secrets panel AI Studio. Hubungi Admin untuk melengkapi konfigurasi API.",
                isConfigError = true
            )
            return
        }

        val state = _form.value
        val sourceVal = when (state.sourceType) {
            SourceType.URL -> state.url.trim()
            else -> state.sourceFileName ?: state.sourceType.value
        }

        viewModelScope.launch {
            val createRes = repository.createBuildRecord(
                appName = state.appName.trim(),
                packageName = state.packageName.trim(),
                versionName = state.versionName.trim(),
                versionCode = state.versionCode.toLongOrNull() ?: 1L,
                sourceType = state.sourceType.value,
                sourceValue = sourceVal,
                splashType = state.splashType.value,
                orientation = state.orientation.value,
                permissions = state.selectedPermissions.toList(),
                status = BuildStatus.PROCESSING
            )

            val docId = createRes.getOrElse { err ->
                _executionState.value = BuildExecutionState.Error(
                    docId = null,
                    message = err.localizedMessage ?: "Gagal mencatat antrean build di database."
                )
                return@launch
            }

            _executionState.value = BuildExecutionState.Processing(docId)

            val apiResult = rfBuilderService.buildApk(
                RfBuildRequest(
                    appName = state.appName.trim(),
                    packageName = state.packageName.trim(),
                    versionName = state.versionName.trim(),
                    versionCode = state.versionCode.toIntOrNull() ?: 1,
                    sourceType = state.sourceType,
                    url = state.url.trim(),
                    sourceFileUri = state.sourceFileUri,
                    iconUri = state.iconUri,
                    splashType = state.splashType,
                    splashFileUri = state.splashFileUri,
                    orientation = state.orientation,
                    permissions = state.selectedPermissions.toList()
                )
            )

            when (apiResult) {
                is RfBuildResult.Success -> {
                    repository.completeBuildSuccess(
                        docId = docId,
                        rfBuildId = apiResult.buildId,
                        fileName = apiResult.fileName,
                        fileSize = apiResult.size,
                        downloadUrl = apiResult.downloadUrl
                    )
                    _executionState.value = BuildExecutionState.Success(docId, apiResult)
                }
                is RfBuildResult.Failure -> {
                    repository.completeBuildFailure(docId, apiResult.message)
                    _executionState.value = BuildExecutionState.Error(
                        docId = docId,
                        message = apiResult.message,
                        isConfigError = apiResult.isConfigError
                    )
                }
            }
        }
    }
}
