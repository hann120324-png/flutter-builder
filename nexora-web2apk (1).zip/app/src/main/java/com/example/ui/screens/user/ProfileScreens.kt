package com.example.ui.screens.user

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.data.model.PlanTier
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.StatusPill
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent

@Composable
fun ProfileScreen(
    userProfileState: UiState<UserProfile?>,
    onUpdateProfile: (String, String?) -> Unit,
    onOpenSecurity: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val profile = (userProfileState as? UiState.Success)?.data
    var nameInput by remember { mutableStateOf("") }
    var selectedPhotoUri by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(profile) {
        if (profile != null && nameInput.isBlank()) {
            nameInput = profile.name
        }
    }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let {
            selectedPhotoUri = it.toString()
            onUpdateProfile(nameInput.ifBlank { profile?.name ?: "Pengguna" }, it.toString())
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    val avatarUrl = selectedPhotoUri ?: profile?.photoUrl
                    if (!avatarUrl.isNullOrBlank()) {
                        Image(
                            painter = rememberAsyncImagePainter(avatarUrl),
                            contentDescription = "Foto profil pengguna",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(64.dp).clip(CircleShape)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(NexoraSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = NexoraCyanGlow, modifier = Modifier.size(32.dp))
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(profile?.name ?: "Pengguna NEXORA", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                        Text(profile?.email ?: "-", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                        Spacer(Modifier.height(6.dp))
                        val isPro = PlanTier.from(profile?.plan) == PlanTier.PRO
                        StatusPill(if (isPro) "NEXORA PRO" else "FREE", if (isPro) NexoraVioletAccent else NexoraElectricBlue)
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Ganti Foto Profil")
                }
            }
        }

        item {
            GlassCard {
                Text("Informasi Akun", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("User ID", style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                        Text(profile?.userId ?: "-", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                    }
                    OutlinedButton(
                        onClick = { profile?.userId?.let { copyToClipboard(context, "User ID", it) } }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Salin User ID", modifier = Modifier.size(16.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Tanggal Registrasi: ${formatTimestamp(profile?.createdAt)}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Edit Nama") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("profile_name_input")
                )
                Spacer(Modifier.height(10.dp))
                GradientPrimaryButton(
                    text = "Simpan Perubahan Nama",
                    icon = Icons.Default.Edit,
                    onClick = { onUpdateProfile(nameInput, selectedPhotoUri) },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "profile_save_button"
                )
            }
        }

        item {
            OutlinedButton(
                onClick = onOpenSecurity,
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.Security, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Pengaturan Keamanan Akun")
            }
        }

        item {
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("profile_logout_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = NexoraError)
                Spacer(Modifier.width(8.dp))
                Text("Logout", color = NexoraError)
            }
        }
    }
}

@Composable
fun ProfileSecurityScreen(
    userProfileState: UiState<UserProfile?>,
    onSignOut: () -> Unit
) {
    val profile = (userProfileState as? UiState.Success)?.data
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard(borderColor = NexoraSuccess.copy(alpha = 0.5f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = NexoraSuccess)
                    Text("Keamanan Google Sign-In Aktif", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Akun Anda dilindungi oleh Firebase Authentication dan Google Identity Credential Manager. Email terverifikasi: ${profile?.email ?: "-"}.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexoraTextSecondary
                )
                Spacer(Modifier.height(8.dp))
                StatusPill("STATUS: ${profile?.status?.uppercase() ?: "ACTIVE"}", NexoraSuccess)
            }
        }

        item {
            GlassCard {
                Text("Manajemen Sesi", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Keluar dari aplikasi akan membersihkan token Credential Manager di perangkat ini.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexoraTextSecondary
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onSignOut,
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = NexoraError)
                    Spacer(Modifier.width(8.dp))
                    Text("Keluar & Bersihkan Sesi", color = NexoraError)
                }
            }
        }
    }
}
