package com.example.ui.screens.user

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.Announcement
import com.example.data.model.ApkBuild
import com.example.data.model.PlatformSettings
import com.example.data.model.SupportTicket
import com.example.data.model.TicketStatus
import com.example.data.model.UiState
import com.example.data.model.UserNotification
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.StatusPill
import com.example.ui.components.WhatsAppSupportButtons
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent
import com.example.ui.theme.NexoraWarning

@Composable
fun SupportScreen(
    ticketsState: UiState<List<SupportTicket>>,
    settingsState: UiState<PlatformSettings>,
    onCreateTicket: () -> Unit,
    onOpenTicketDetail: (String) -> Unit
) {
    val tickets = (ticketsState as? UiState.Success)?.data.orEmpty()
    val settings = (settingsState as? UiState.Success)?.data ?: PlatformSettings()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Text("Pusat Bantuan & CS", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Mengalami kendala build APK atau verifikasi pembayaran? Buat tiket dukungan atau hubungi kontak resmi di bawah.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexoraTextSecondary
                )
                Spacer(Modifier.height(12.dp))
                GradientPrimaryButton(
                    text = "Buat Tiket Kendala",
                    icon = Icons.Default.Add,
                    onClick = onCreateTicket,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "support_create_ticket_button"
                )
            }
        }

        item {
            WhatsAppSupportButtons(settings = settings)
        }

        item {
            Text("Riwayat Tiket Saya", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
        }

        if (tickets.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "Belum Ada Tiket",
                    description = "Anda belum pernah membuat tiket kendala.",
                    actionLabel = "Buat Tiket Pertama",
                    onAction = onCreateTicket
                )
            }
        } else {
            items(tickets, key = { it.id }) { ticket ->
                val st = TicketStatus.from(ticket.status)
                val color = when (st) {
                    TicketStatus.OPEN -> NexoraWarning
                    TicketStatus.IN_PROGRESS -> NexoraCyanGlow
                    TicketStatus.RESOLVED -> NexoraSuccess
                    TicketStatus.CLOSED -> NexoraTextSecondary
                }
                GlassCard(onClick = { onOpenTicketDetail(ticket.id) }) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(ticket.category, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        StatusPill(st.label, color)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(ticket.message, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary, maxLines = 2)
                    Spacer(Modifier.height(6.dp))
                    Text(formatTimestamp(ticket.createdAt), style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                }
            }
        }
    }
}

@Composable
fun SupportCreateScreen(
    buildsState: UiState<List<ApkBuild>>,
    onSubmitTicket: (category: String, buildId: String?, message: String, screenshotUrl: String?) -> Unit,
    onBack: () -> Unit
) {
    val builds = (buildsState as? UiState.Success)?.data.orEmpty()
    val categories = listOf("Build Gagal", "Pembayaran QRIS", "Download APK", "Akun & Kuota", "Lainnya")
    var selectedCategory by remember { mutableStateOf(categories.first()) }
    var buildIdInput by remember { mutableStateOf(builds.firstOrNull()?.buildId ?: "") }
    var message by remember { mutableStateOf("") }
    var screenshotUri by remember { mutableStateOf<String?>(null) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { screenshotUri = it.toString() }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Text("Kategori Kendala", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { cat ->
                                FilterChip(
                                    selected = selectedCategory == cat,
                                    onClick = { selectedCategory = cat },
                                    label = { Text(cat) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = buildIdInput,
                    onValueChange = { buildIdInput = it },
                    label = { Text("Build ID (Opsional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Deskripsi Kendala") },
                    placeholder = { Text("Jelaskan kendala yang Anda alami...") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth().testTag("support_message_input")
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = {
                        imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Image, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (screenshotUri == null) "Lampirkan Screenshot (Opsional)" else "Screenshot Terlampir")
                }
                if (!errorText.isNullOrBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(errorText!!, color = com.example.ui.theme.NexoraError)
                }
                Spacer(Modifier.height(14.dp))
                GradientPrimaryButton(
                    text = "Kirim Tiket Kendala",
                    icon = Icons.Default.Send,
                    onClick = {
                        if (message.trim().length < 5) {
                            errorText = "Deskripsi minimal 5 karakter."
                        } else {
                            errorText = null
                            onSubmitTicket(selectedCategory, buildIdInput.ifBlank { null }, message, screenshotUri)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "support_submit_button"
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Batal")
                }
            }
        }
    }
}

@Composable
fun SupportDetailScreen(
    ticketId: String,
    ticketsState: UiState<List<SupportTicket>>,
    onBack: () -> Unit
) {
    val tickets = (ticketsState as? UiState.Success)?.data.orEmpty()
    val ticket = tickets.firstOrNull { it.id == ticketId }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (ticket == null) {
            item {
                EmptyStateCard(
                    title = "Tiket Tidak Ditemukan",
                    description = "Tiket tidak tersedia atau Anda tidak memiliki akses.",
                    actionLabel = "Kembali",
                    onAction = onBack
                )
            }
        } else {
            item {
                val st = TicketStatus.from(ticket.status)
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(ticket.category, style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                        StatusPill(st.label, NexoraCyanGlow)
                    }
                    Spacer(Modifier.height(6.dp))
                    if (!ticket.buildId.isNullOrBlank()) {
                        Text("Build ID: ${ticket.buildId}", style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                    }
                    Text("Dibuat: ${formatTimestamp(ticket.createdAt)}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                    Spacer(Modifier.height(10.dp))
                    Text(ticket.message, style = MaterialTheme.typography.bodyLarge, color = NexoraTextPrimary)
                }
            }

            item {
                GlassCard(borderColor = NexoraVioletAccent.copy(alpha = 0.5f)) {
                    Text("Balasan Tim Support / Admin", style = MaterialTheme.typography.titleMedium, color = NexoraVioletAccent)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = ticket.adminReply?.ifBlank { null } ?: "Belum ada balasan dari Admin. Mohon menunggu.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NexoraTextPrimary
                    )
                }
            }

            item {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Kembali ke Pusat Bantuan")
                }
            }
        }
    }
}

@Composable
fun NotificationsScreen(
    notificationsState: UiState<List<UserNotification>>,
    announcementsState: UiState<List<Announcement>>,
    onMarkRead: (String) -> Unit
) {
    val notifications = (notificationsState as? UiState.Success)?.data.orEmpty()
    val announcements = (announcementsState as? UiState.Success)?.data.orEmpty()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (announcements.isNotEmpty()) {
            item {
                Text("Pengumuman Platform", style = MaterialTheme.typography.titleMedium, color = NexoraCyanGlow)
            }
            items(announcements, key = { it.id }) { ann ->
                GlassCard(borderColor = NexoraCyanGlow.copy(alpha = 0.45f)) {
                    Text(ann.title, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                    Spacer(Modifier.height(4.dp))
                    Text(ann.message, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                }
            }
        }

        item {
            Text("Notifikasi Akun", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
        }

        if (notifications.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "Belum Ada Notifikasi",
                    description = "Notifikasi status build APK dan konfirmasi pembayaran akan muncul di sini."
                )
            }
        } else {
            items(notifications, key = { it.id }) { ntf ->
                GlassCard(
                    onClick = { if (!ntf.read) onMarkRead(ntf.id) },
                    borderColor = if (ntf.read) com.example.ui.theme.NexoraBorderSubtle else NexoraElectricBlue
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                if (ntf.read) Icons.Default.MarkEmailRead else Icons.Default.Notifications,
                                contentDescription = null,
                                tint = if (ntf.read) NexoraTextSecondary else NexoraCyanGlow
                            )
                            Text(ntf.title, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        }
                        if (!ntf.read) StatusPill("BARU", NexoraElectricBlue)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(ntf.message, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text(formatTimestamp(ntf.createdAt), style = MaterialTheme.typography.labelSmall, color = NexoraTextSecondary)
                }
            }
        }
    }
}
