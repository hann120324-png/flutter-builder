package com.example.ui.screens.user

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Announcement
import com.example.data.model.ApkBuild
import com.example.data.model.BuildStatus
import com.example.data.model.BuildUsage
import com.example.data.model.PlanTier
import com.example.data.model.Testimonial
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.SkeletonPlaceholderCard
import com.example.ui.components.StatusPill
import com.example.ui.components.formatTimestamp
import com.example.ui.navigation.NexoraRoutes
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent
import com.example.ui.theme.NexoraWarning

@Composable
fun UserDashboardScreen(
    userProfileState: UiState<UserProfile?>,
    buildsState: UiState<List<ApkBuild>>,
    usageState: UiState<BuildUsage?>,
    announcementsState: UiState<List<Announcement>>,
    testimonialsState: UiState<List<Testimonial>>,
    freeDailyQuota: Int,
    onNavigate: (String) -> Unit
) {
    val profile = (userProfileState as? UiState.Success)?.data
    val builds = (buildsState as? UiState.Success)?.data.orEmpty()
    val usageCount = ((usageState as? UiState.Success)?.data?.totalBuild ?: 0L).toInt()
    val announcements = (announcementsState as? UiState.Success)?.data.orEmpty()
    val testimonials = (testimonialsState as? UiState.Success)?.data.orEmpty()

    val isPro = PlanTier.from(profile?.plan) == PlanTier.PRO
    val remainingQuotaText = if (isPro) {
        "Tanpa Batas Internal"
    } else {
        "${(freeDailyQuota - usageCount).coerceAtLeast(0)} / $freeDailyQuota hari ini"
    }
    val successCount = builds.count { BuildStatus.from(it.status) == BuildStatus.SUCCESS }
    val failedCount = builds.count { BuildStatus.from(it.status) == BuildStatus.FAILED }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (announcements.isNotEmpty()) {
            item {
                val latest = announcements.first()
                GlassCard(borderColor = NexoraCyanGlow.copy(alpha = 0.45f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null, tint = NexoraCyanGlow)
                        Text(latest.title, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(latest.message, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                }
            }
        }

        // Greeting + Active Plan & Quota
        item {
            if (userProfileState is UiState.Loading) {
                SkeletonPlaceholderCard()
            } else {
                GlassCard(borderColor = NexoraElectricBlue.copy(alpha = 0.45f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Halo, ${profile?.name ?: "Creator"}",
                                style = MaterialTheme.typography.headlineMedium,
                                color = NexoraTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Siap mengubah website jadi aplikasi Android?",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NexoraTextSecondary
                            )
                        }
                        StatusPill(
                            label = if (isPro) "PRO" else "FREE",
                            color = if (isPro) NexoraVioletAccent else NexoraElectricBlue
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Sisa Kuota Build", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                            Text(
                                text = remainingQuotaText,
                                style = MaterialTheme.typography.titleLarge,
                                color = NexoraCyanGlow,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (!isPro) {
                            OutlinedButton(
                                onClick = { onNavigate(NexoraRoutes.PACKAGES) },
                                modifier = Modifier.testTag("dashboard_upgrade_pro_button")
                            ) {
                                Icon(Icons.Default.Upgrade, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Upgrade Pro")
                            }
                        }
                    }
                    if (!isPro && usageCount >= freeDailyQuota) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = "Kuota build harian kamu sudah habis. Upgrade ke Pro untuk mendapatkan kuota lebih besar.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = NexoraWarning
                        )
                    }
                }
            }
        }

        // Real Build Metrics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricBox(
                    label = "Total Build",
                    value = builds.size.toString(),
                    accent = NexoraElectricBlue,
                    modifier = Modifier.weight(1f)
                )
                MetricBox(
                    label = "Berhasil",
                    value = successCount.toString(),
                    accent = NexoraSuccess,
                    modifier = Modifier.weight(1f)
                )
                MetricBox(
                    label = "Gagal",
                    value = failedCount.toString(),
                    accent = NexoraError,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Shortcuts
        item {
            GlassCard {
                Text("Pintasan Cepat", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                Spacer(Modifier.height(12.dp))
                GradientPrimaryButton(
                    text = "Mulai Build APK Baru",
                    icon = Icons.Default.Build,
                    onClick = { onNavigate(NexoraRoutes.BUILD) },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "shortcut_build_apk"
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ShortcutChip("Riwayat", Icons.Default.History, Modifier.weight(1f)) {
                        onNavigate(NexoraRoutes.BUILD_HISTORY)
                    }
                    ShortcutChip("Paket", Icons.Default.Upgrade, Modifier.weight(1f)) {
                        onNavigate(NexoraRoutes.PACKAGES)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ShortcutChip("Profil", Icons.Default.Person, Modifier.weight(1f)) {
                        onNavigate(NexoraRoutes.PROFILE)
                    }
                    ShortcutChip("Bantuan", Icons.Default.SupportAgent, Modifier.weight(1f)) {
                        onNavigate(NexoraRoutes.SUPPORT)
                    }
                }
            }
        }

        // Recent Activity
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Aktivitas Build Terbaru", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                if (builds.isNotEmpty()) {
                    OutlinedButton(onClick = { onNavigate(NexoraRoutes.BUILD_HISTORY) }) {
                        Text("Semua")
                    }
                }
            }
        }

        when (buildsState) {
            is UiState.Loading -> {
                item { SkeletonPlaceholderCard() }
                item { SkeletonPlaceholderCard() }
            }
            is UiState.Error -> {
                item {
                    GlassCard(borderColor = NexoraError) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = NexoraError)
                            Text(buildsState.message, style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                        }
                    }
                }
            }
            is UiState.Success -> {
                if (builds.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "Belum Ada Build APK",
                            description = "Buat aplikasi Android pertama Anda dari URL website, HTML, atau arsip ZIP sekarang.",
                            actionLabel = "Build APK Sekarang",
                            onAction = { onNavigate(NexoraRoutes.BUILD) }
                        )
                    }
                } else {
                    items(builds.take(4), key = { it.id }) { build ->
                        BuildSummaryCard(build = build) {
                            onNavigate(NexoraRoutes.buildDetail(build.id))
                        }
                    }
                }
            }
        }

        // Real Published Testimonials from Firestore
        if (testimonials.isNotEmpty()) {
            item {
                Text("Testimoni Pelanggan", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
            }
            items(testimonials.take(5), key = { it.id }) { item ->
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.name, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = NexoraWarning, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("${item.rating}/5", style = MaterialTheme.typography.labelSmall, color = NexoraWarning)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(item.description, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                }
            }
        }
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier, contentPadding = PaddingValues(12.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.headlineMedium, color = accent, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ShortcutChip(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(48.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun BuildSummaryCard(
    build: ApkBuild,
    onClick: () -> Unit
) {
    val status = BuildStatus.from(build.status)
    val statusColor = when (status) {
        BuildStatus.SUCCESS -> NexoraSuccess
        BuildStatus.FAILED -> NexoraError
        BuildStatus.PROCESSING, BuildStatus.WAITING -> NexoraCyanGlow
        BuildStatus.DRAFT -> NexoraWarning
    }
    GlassCard(onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = build.appName,
                    style = MaterialTheme.typography.titleMedium,
                    color = NexoraTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = build.packageName,
                    style = MaterialTheme.typography.labelSmall,
                    color = NexoraCyanGlow,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            StatusPill(status.value, statusColor)
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Sumber: ${build.sourceType.uppercase()} • v${build.versionName}",
                style = MaterialTheme.typography.bodyMedium,
                color = NexoraTextSecondary
            )
            Text(
                text = formatTimestamp(build.createdAt),
                style = MaterialTheme.typography.labelSmall,
                color = NexoraTextSecondary
            )
        }
        if (!build.buildId.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexoraSuccess, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    text = "Build ID: ${build.buildId} (${build.fileSize ?: "-"})",
                    style = MaterialTheme.typography.labelSmall,
                    color = NexoraTextSecondary
                )
            }
        }
    }
}
