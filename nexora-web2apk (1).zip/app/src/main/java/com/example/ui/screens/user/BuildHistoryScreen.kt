package com.example.ui.screens.user

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ApkBuild
import com.example.data.model.BuildStatus
import com.example.data.model.UiState
import com.example.data.remote.RfBuilderService
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.SkeletonPlaceholderCard
import com.example.ui.components.StatusPill
import com.example.ui.components.formatTimestamp
import com.example.ui.components.openExternalUrl
import com.example.ui.navigation.NexoraRoutes
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraWarning

@Composable
fun BuildHistoryScreen(
    buildsState: UiState<List<ApkBuild>>,
    onOpenDetail: (String) -> Unit,
    onStartNewBuild: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selectedStatus by remember { mutableStateOf("all") }
    var pageSize by remember { mutableIntStateOf(15) }

    val allBuilds = (buildsState as? UiState.Success)?.data.orEmpty()
    val filtered = remember(allBuilds, query, selectedStatus) {
        allBuilds.filter { build ->
            val matchesQuery = query.isBlank() ||
                build.appName.contains(query, ignoreCase = true) ||
                build.packageName.contains(query, ignoreCase = true) ||
                (build.buildId?.contains(query, ignoreCase = true) == true)
            val matchesStatus = selectedStatus == "all" || build.status.equals(selectedStatus, ignoreCase = true)
            matchesQuery && matchesStatus
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Cari nama aplikasi, package, atau Build ID") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("history_search_input")
            )
        }

        item {
            val statuses = listOf("all" to "Semua", "success" to "Success", "processing" to "Processing", "failed" to "Failed", "draft" to "Draft")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(statuses) { (key, label) ->
                    FilterChip(
                        selected = selectedStatus == key,
                        onClick = { selectedStatus = key },
                        label = { Text(label) }
                    )
                }
            }
        }

        when (buildsState) {
            is UiState.Loading -> {
                item { SkeletonPlaceholderCard() }
                item { SkeletonPlaceholderCard() }
            }
            is UiState.Error -> {
                item {
                    GlassCard(borderColor = NexoraError) {
                        Text(buildsState.message, color = NexoraError)
                    }
                }
            }
            is UiState.Success -> {
                if (filtered.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "Riwayat Build Kosong",
                            description = "Belum ada build yang sesuai filter Anda.",
                            actionLabel = "Buat APK Baru",
                            onAction = onStartNewBuild
                        )
                    }
                } else {
                    items(filtered.take(pageSize), key = { it.id }) { build ->
                        BuildSummaryCard(build = build) {
                            onOpenDetail(build.id)
                        }
                    }
                    if (filtered.size > pageSize) {
                        item {
                            OutlinedButton(
                                onClick = { pageSize += 15 },
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text("Muat Lebih Banyak (${filtered.size - pageSize} lagi)")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BuildDetailScreen(
    buildId: String,
    buildsState: UiState<List<ApkBuild>>,
    onRetryBuild: (ApkBuild) -> Unit,
    onDeleteDraft: (String) -> Unit,
    onBackToHistory: () -> Unit
) {
    val context = LocalContext.current
    val builds = (buildsState as? UiState.Success)?.data.orEmpty()
    val build = builds.firstOrNull { it.id == buildId }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (build == null) {
            item {
                EmptyStateCard(
                    title = "Detail Build Tidak Ditemukan",
                    description = "Data build mungkin telah dihapus atau Anda tidak memiliki akses.",
                    actionLabel = "Kembali ke Riwayat",
                    onAction = onBackToHistory
                )
            }
            return@LazyColumn
        }

        val status = BuildStatus.from(build.status)
        val statusColor = when (status) {
            BuildStatus.SUCCESS -> NexoraSuccess
            BuildStatus.FAILED -> NexoraError
            BuildStatus.PROCESSING, BuildStatus.WAITING -> NexoraCyanGlow
            BuildStatus.DRAFT -> NexoraWarning
        }

        item {
            GlassCard(borderColor = statusColor.copy(alpha = 0.55f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(build.appName, style = MaterialTheme.typography.headlineMedium, color = NexoraTextPrimary)
                        Text(build.packageName, style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                    }
                    StatusPill(status.value, statusColor)
                }
                Spacer(Modifier.height(12.dp))
                DetailLine("Build ID", build.buildId ?: build.id)
                DetailLine("Tanggal", formatTimestamp(build.createdAt))
                DetailLine("Versi", "${build.versionName} (${build.versionCode})")
                DetailLine("Sumber", "${build.sourceType.uppercase()} — ${build.sourceValue}")
                DetailLine("Splash Screen", build.splashType.uppercase())
                DetailLine("Orientasi", build.orientation.uppercase())
                DetailLine("Permissions", build.permissions.joinToString(", "))
                if (!build.fileName.isNullOrBlank()) {
                    DetailLine("Nama APK", build.fileName)
                }
                if (!build.fileSize.isNullOrBlank()) {
                    DetailLine("Ukuran File", build.fileSize)
                }
            }
        }

        if (!build.errorMessage.isNullOrBlank()) {
            item {
                GlassCard(borderColor = NexoraError) {
                    Text("Pesan Error", style = MaterialTheme.typography.titleMedium, color = NexoraError)
                    Spacer(Modifier.height(4.dp))
                    Text(build.errorMessage, style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val dl = build.downloadUrl
                if (status == BuildStatus.SUCCESS && !dl.isNullOrBlank() && RfBuilderService.isTrustedDownloadUrl(dl)) {
                    GradientPrimaryButton(
                        text = "Download APK",
                        icon = Icons.Default.Download,
                        onClick = { openExternalUrl(context, dl) },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "detail_download_apk_button"
                    )
                }

                if (status == BuildStatus.FAILED || status == BuildStatus.DRAFT) {
                    GradientPrimaryButton(
                        text = if (status == BuildStatus.DRAFT) "Lanjutkan Draft Build" else "Coba Lagi",
                        icon = Icons.Default.Refresh,
                        onClick = { onRetryBuild(build) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedButton(
                    onClick = { copyToClipboard(context, "Build ID", build.buildId ?: build.id) },
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Salin Build ID")
                }

                if (status == BuildStatus.DRAFT) {
                    OutlinedButton(
                        onClick = {
                            onDeleteDraft(build.id)
                            onBackToHistory()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = NexoraError)
                        Spacer(Modifier.width(8.dp))
                        Text("Hapus Draft", color = NexoraError)
                    }
                }

                OutlinedButton(
                    onClick = onBackToHistory,
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Kembali ke Riwayat")
                }
            }
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = NexoraTextSecondary)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
    }
}
