package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.R
import com.example.data.model.UiState
import com.example.data.remote.MidtransService
import com.example.data.remote.RfBuilderService
import com.example.data.repository.AuthActionResult
import com.example.data.repository.AuthRepository
import com.example.data.repository.NexoraRepository
import com.example.ui.components.AdminDrawerContent
import com.example.ui.components.UserBottomNavBar
import com.example.ui.components.UserDrawerContent
import com.example.ui.navigation.NexoraRoutes
import com.example.ui.screens.admin.AdminAnnouncementsScreen
import com.example.ui.screens.admin.AdminApiSettingsScreen
import com.example.ui.screens.admin.AdminBuildDetailScreen
import com.example.ui.screens.admin.AdminBuildsScreen
import com.example.ui.screens.admin.AdminLogsScreen
import com.example.ui.screens.admin.AdminOverviewScreen
import com.example.ui.screens.admin.AdminPackagesScreen
import com.example.ui.screens.admin.AdminPaymentSettingsScreen
import com.example.ui.screens.admin.AdminSubscriptionsScreen
import com.example.ui.screens.admin.AdminSupportScreen
import com.example.ui.screens.admin.AdminTestimonialsScreen
import com.example.ui.screens.admin.AdminTransactionsScreen
import com.example.ui.screens.admin.AdminUserDetailScreen
import com.example.ui.screens.admin.AdminUsersScreen
import com.example.ui.screens.admin.AdminWebsiteSettingsScreen
import com.example.ui.screens.admin.AdminWhatsAppSettingsScreen
import com.example.ui.screens.public.AuthScreen
import com.example.ui.screens.public.PublicInfoScreen
import com.example.ui.screens.public.PublicLandingScreen
import com.example.ui.screens.user.BuildDetailScreen
import com.example.ui.screens.user.BuildHistoryScreen
import com.example.ui.screens.user.BuildWizardScreen
import com.example.ui.screens.user.NotificationsScreen
import com.example.ui.screens.user.PackagesScreen
import com.example.ui.screens.user.PaymentHistoryScreen
import com.example.ui.screens.user.PaymentScreen
import com.example.ui.screens.user.ProfileScreen
import com.example.ui.screens.user.ProfileSecurityScreen
import com.example.ui.screens.user.SupportCreateScreen
import com.example.ui.screens.user.SupportDetailScreen
import com.example.ui.screens.user.SupportScreen
import com.example.ui.screens.user.UserDashboardScreen
import com.example.ui.theme.NexoraAdminCrimson
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraDeepNavy
import com.example.ui.theme.NexoraObsidian
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.BuildViewModel
import com.example.ui.viewmodel.PaymentViewModel
import com.example.ui.viewmodel.UserViewModel
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

@Composable
fun NexoraApp(
    authRepository: AuthRepository = remember { AuthRepository() }
) {
    val context = LocalContext.current
    val currentUser by authRepository.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = authRepository.currentUser())

    LaunchedEffect(Unit) {
        authRepository.attemptAutoSignIn(context)
    }

    val user = currentUser
    if (user == null) {
        PublicNavigationHost(authRepository = authRepository)
    } else {
        key(user.uid) {
            AuthenticatedShell(
                firebaseUser = user,
                authRepository = authRepository
            )
        }
    }
}

@Composable
private fun PublicNavigationHost(authRepository: AuthRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val navController = rememberNavController()
    var authLoading by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }

    fun triggerGoogleSignIn() {
        if (authLoading) return
        authLoading = true
        authError = null
        scope.launch {
            when (val res = authRepository.signInWithGoogle(context)) {
                is AuthActionResult.Success -> authLoading = false
                is AuthActionResult.Cancelled -> authLoading = false
                is AuthActionResult.Error -> {
                    authLoading = false
                    authError = res.message
                }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = NexoraRoutes.HOME
    ) {
        composable(NexoraRoutes.HOME) {
            PublicLandingScreen(onNavigate = { navController.navigate(it) })
        }
        composable(NexoraRoutes.LOGIN) {
            AuthScreen(
                initialTab = NexoraRoutes.LOGIN,
                isLoading = authLoading,
                errorMessage = authError,
                onGoogleSignIn = ::triggerGoogleSignIn,
                onBack = { navController.popBackStack() },
                onNavigate = { navController.navigate(it) }
            )
        }
        composable(NexoraRoutes.REGISTER) {
            AuthScreen(
                initialTab = NexoraRoutes.REGISTER,
                isLoading = authLoading,
                errorMessage = authError,
                onGoogleSignIn = ::triggerGoogleSignIn,
                onBack = { navController.popBackStack() },
                onNavigate = { navController.navigate(it) }
            )
        }
        composable(NexoraRoutes.FORGOT_PASSWORD) {
            AuthScreen(
                initialTab = NexoraRoutes.FORGOT_PASSWORD,
                isLoading = authLoading,
                errorMessage = authError,
                onGoogleSignIn = ::triggerGoogleSignIn,
                onBack = { navController.popBackStack() },
                onNavigate = { navController.navigate(it) }
            )
        }
        listOf(
            NexoraRoutes.PUBLIC_PACKAGES,
            NexoraRoutes.ABOUT,
            NexoraRoutes.CONTACT,
            NexoraRoutes.PRIVACY,
            NexoraRoutes.TERMS,
            NexoraRoutes.FAQ
        ).forEach { route ->
            composable(route) {
                PublicInfoScreen(
                    route = route,
                    onBack = { navController.popBackStack() },
                    onGoToLogin = { navController.navigate(NexoraRoutes.LOGIN) }
                )
            }
        }
    }
}

@Composable
private fun AuthenticatedShell(
    firebaseUser: FirebaseUser,
    authRepository: AuthRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val uid = firebaseUser.uid

    val userViewModel: UserViewModel = viewModel(
        key = "user_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                UserViewModel(NexoraRepository(db), uid)
            }
        }
    )

    val buildViewModel: BuildViewModel = viewModel(
        key = "build_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                BuildViewModel(NexoraRepository(db), RfBuilderService(app), uid)
            }
        }
    )

    val paymentViewModel: PaymentViewModel = viewModel(
        key = "payment_$uid",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                PaymentViewModel(NexoraRepository(db), MidtransService(), uid)
            }
        }
    )

    LaunchedEffect(uid) {
        val db = FirebaseFirestore.getInstance(context.applicationContext.getString(R.string.firestore_database_id))
        NexoraRepository(db).ensureUserProfile(firebaseUser)
    }

    val userProfileState by userViewModel.userProfile.collectAsStateWithLifecycle()
    val profile = (userProfileState as? UiState.Success)?.data
    val isBootstrappedAdmin = firebaseUser.email.equals(AuthRepository.BOOTSTRAPPED_ADMIN_EMAIL, ignoreCase = true) &&
        firebaseUser.isEmailVerified
    val isAdmin = isBootstrappedAdmin || profile?.role == "admin"

    var inAdminConsole by remember(uid) { mutableStateOf(false) }

    val onSignOut: () -> Unit = {
        scope.launch { authRepository.signOut(context) }
    }

    if (isAdmin && inAdminConsole) {
        val adminViewModel: AdminViewModel = viewModel(
            key = "admin_$uid",
            factory = viewModelFactory {
                initializer {
                    val app = checkNotNull(this[APPLICATION_KEY])
                    val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                    AdminViewModel(NexoraRepository(db), RfBuilderService(app), MidtransService(), uid)
                }
            }
        )
        AdminConsoleShell(
            adminViewModel = adminViewModel,
            onSwitchToUser = { inAdminConsole = false },
            onSignOut = onSignOut
        )
    } else {
        UserConsoleShell(
            userViewModel = userViewModel,
            buildViewModel = buildViewModel,
            paymentViewModel = paymentViewModel,
            isAdmin = isAdmin,
            onSwitchToAdmin = { inAdminConsole = true },
            onSignOut = onSignOut
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UserConsoleShell(
    userViewModel: UserViewModel,
    buildViewModel: BuildViewModel,
    paymentViewModel: PaymentViewModel,
    isAdmin: Boolean,
    onSwitchToAdmin: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val userProfileState by userViewModel.userProfile.collectAsStateWithLifecycle()
    val buildsState by userViewModel.builds.collectAsStateWithLifecycle()
    val usageState by userViewModel.todayUsage.collectAsStateWithLifecycle()
    val transactionsState by userViewModel.transactions.collectAsStateWithLifecycle()
    val ticketsState by userViewModel.tickets.collectAsStateWithLifecycle()
    val notificationsState by userViewModel.notifications.collectAsStateWithLifecycle()
    val packagesState by userViewModel.packages.collectAsStateWithLifecycle()
    val testimonialsState by userViewModel.testimonials.collectAsStateWithLifecycle()
    val announcementsState by userViewModel.announcements.collectAsStateWithLifecycle()
    val settingsState by userViewModel.platformSettings.collectAsStateWithLifecycle()
    val toastMessage by userViewModel.toastMessage.collectAsStateWithLifecycle()

    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            userViewModel.clearToast()
        }
    }

    val packages = (packagesState as? UiState.Success)?.data.orEmpty()
    val freeDailyQuota = (packages.firstOrNull { it.code == "free" }?.dailyQuota ?: 3L).toInt()
    val proPrice = packages.firstOrNull { it.code == "pro" }?.price ?: 10000L
    val profile = (userProfileState as? UiState.Success)?.data
    val settings = (settingsState as? UiState.Success)?.data ?: com.example.data.model.PlatformSettings()
    val unreadCount = (notificationsState as? UiState.Success)?.data?.count { !it.read } ?: 0

    val navigateTo: (String) -> Unit = { route ->
        scope.launch { drawerState.close() }
        navController.navigate(route) {
            launchSingleTop = true
        }
    }

    val screenTitle = when {
        currentRoute == NexoraRoutes.DASHBOARD -> "Dashboard"
        currentRoute == NexoraRoutes.BUILD -> "Build APK"
        currentRoute == NexoraRoutes.BUILD_HISTORY -> "Riwayat Build"
        currentRoute?.startsWith("user_build_detail") == true -> "Detail Build"
        currentRoute == NexoraRoutes.PACKAGES -> "Paket Langganan"
        currentRoute == NexoraRoutes.PAYMENT -> "Pembayaran QRIS"
        currentRoute == NexoraRoutes.PAYMENT_HISTORY -> "Riwayat Transaksi"
        currentRoute == NexoraRoutes.PROFILE -> "Profil Pengguna"
        currentRoute == NexoraRoutes.PROFILE_SECURITY -> "Keamanan Akun"
        currentRoute == NexoraRoutes.SUPPORT -> "Pusat Bantuan"
        currentRoute == NexoraRoutes.SUPPORT_CREATE -> "Buat Tiket Kendala"
        currentRoute?.startsWith("user_support_detail") == true -> "Detail Tiket"
        currentRoute == NexoraRoutes.NOTIFICATIONS -> "Notifikasi"
        else -> "NEXORA WEB2APK"
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            UserDrawerContent(
                user = profile,
                isAdmin = isAdmin,
                currentRoute = currentRoute,
                unreadNotifications = unreadCount,
                settings = settings,
                onNavigate = navigateTo,
                onSwitchToAdmin = {
                    scope.launch { drawerState.close() }
                    onSwitchToAdmin()
                },
                onSignOut = {
                    scope.launch { drawerState.close() }
                    onSignOut()
                }
            )
        }
    ) {
        Scaffold(
            containerColor = NexoraDeepNavy,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraSurfaceDark),
                    navigationIcon = {
                        IconButton(
                            onClick = { scope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("user_menu_drawer_button")
                        ) {
                            Icon(Icons.Default.Menu, contentDescription = "Buka menu navigasi")
                        }
                    },
                    title = { Text(screenTitle, style = MaterialTheme.typography.titleLarge) },
                    actions = {
                        if (isAdmin) {
                            TextButton(
                                onClick = onSwitchToAdmin,
                                modifier = Modifier.testTag("switch_to_admin_button")
                            ) {
                                Icon(
                                    Icons.Default.AdminPanelSettings,
                                    contentDescription = "Admin Console",
                                    tint = NexoraAdminCrimson,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text("Admin", color = NexoraAdminCrimson)
                            }
                        }
                        IconButton(onClick = { navigateTo(NexoraRoutes.NOTIFICATIONS) }) {
                            BadgedBox(
                                badge = {
                                    if (unreadCount > 0) {
                                        Badge { Text(unreadCount.toString()) }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Notifications, contentDescription = "Notifikasi", tint = NexoraCyanGlow)
                            }
                        }
                    }
                )
            },
            bottomBar = {
                UserBottomNavBar(currentRoute = currentRoute, onNavigate = navigateTo)
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.TopCenter
            ) {
                Box(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
                    NavHost(
                        navController = navController,
                        startDestination = NexoraRoutes.DASHBOARD
                    ) {
                        composable(NexoraRoutes.DASHBOARD) {
                            UserDashboardScreen(
                                userProfileState = userProfileState,
                                buildsState = buildsState,
                                usageState = usageState,
                                announcementsState = announcementsState,
                                testimonialsState = testimonialsState,
                                freeDailyQuota = freeDailyQuota,
                                onNavigate = navigateTo
                            )
                        }
                        composable(NexoraRoutes.BUILD) {
                            BuildWizardScreen(
                                viewModel = buildViewModel,
                                userProfileState = userProfileState,
                                usageState = usageState,
                                freeDailyQuota = freeDailyQuota,
                                onNavigate = navigateTo
                            )
                        }
                        composable(NexoraRoutes.BUILD_HISTORY) {
                            BuildHistoryScreen(
                                buildsState = buildsState,
                                onOpenDetail = { id -> navigateTo(NexoraRoutes.buildDetail(id)) },
                                onStartNewBuild = { navigateTo(NexoraRoutes.BUILD) }
                            )
                        }
                        composable(
                            route = NexoraRoutes.BUILD_DETAIL,
                            arguments = listOf(navArgument("buildId") { type = NavType.StringType })
                        ) { entry ->
                            val bId = entry.arguments?.getString("buildId").orEmpty()
                            BuildDetailScreen(
                                buildId = bId,
                                buildsState = buildsState,
                                onRetryBuild = { build ->
                                    buildViewModel.prefillFromBuild(build)
                                    navigateTo(NexoraRoutes.BUILD)
                                },
                                onDeleteDraft = { userViewModel.deleteDraft(it) },
                                onBackToHistory = { navController.popBackStack() }
                            )
                        }
                        composable(NexoraRoutes.PACKAGES) {
                            PackagesScreen(
                                userProfileState = userProfileState,
                                usageState = usageState,
                                packagesState = packagesState,
                                onUpgradePro = { navigateTo(NexoraRoutes.PAYMENT) },
                                onOpenPaymentHistory = { navigateTo(NexoraRoutes.PAYMENT_HISTORY) }
                            )
                        }
                        composable(NexoraRoutes.PAYMENT) {
                            PaymentScreen(
                                paymentViewModel = paymentViewModel,
                                userProfileState = userProfileState,
                                transactionsState = transactionsState,
                                proPrice = proPrice,
                                onNavigate = navigateTo
                            )
                        }
                        composable(NexoraRoutes.PAYMENT_HISTORY) {
                            PaymentHistoryScreen(
                                transactionsState = transactionsState,
                                onGoToPayment = { navigateTo(NexoraRoutes.PAYMENT) }
                            )
                        }
                        composable(NexoraRoutes.PROFILE) {
                            ProfileScreen(
                                userProfileState = userProfileState,
                                onUpdateProfile = { name, photo -> userViewModel.updateProfile(name, photo) },
                                onOpenSecurity = { navigateTo(NexoraRoutes.PROFILE_SECURITY) },
                                onSignOut = onSignOut
                            )
                        }
                        composable(NexoraRoutes.PROFILE_SECURITY) {
                            ProfileSecurityScreen(
                                userProfileState = userProfileState,
                                onSignOut = onSignOut
                            )
                        }
                        composable(NexoraRoutes.SUPPORT) {
                            SupportScreen(
                                ticketsState = ticketsState,
                                settingsState = settingsState,
                                onCreateTicket = { navigateTo(NexoraRoutes.SUPPORT_CREATE) },
                                onOpenTicketDetail = { id -> navigateTo(NexoraRoutes.supportDetail(id)) }
                            )
                        }
                        composable(NexoraRoutes.SUPPORT_CREATE) {
                            SupportCreateScreen(
                                buildsState = buildsState,
                                onSubmitTicket = { cat, bId, msg, shot ->
                                    userViewModel.createSupportTicket(cat, bId, msg, shot) { ticketId ->
                                        navController.navigate(NexoraRoutes.supportDetail(ticketId)) {
                                            popUpTo(NexoraRoutes.SUPPORT)
                                        }
                                    }
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(
                            route = NexoraRoutes.SUPPORT_DETAIL,
                            arguments = listOf(navArgument("ticketId") { type = NavType.StringType })
                        ) { entry ->
                            val tId = entry.arguments?.getString("ticketId").orEmpty()
                            SupportDetailScreen(
                                ticketId = tId,
                                ticketsState = ticketsState,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(NexoraRoutes.NOTIFICATIONS) {
                            NotificationsScreen(
                                notificationsState = notificationsState,
                                announcementsState = announcementsState,
                                onMarkRead = { userViewModel.markNotificationRead(it) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminConsoleShell(
    adminViewModel: AdminViewModel,
    onSwitchToUser: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val allUsers by adminViewModel.allUsers.collectAsStateWithLifecycle()
    val allBuilds by adminViewModel.allBuilds.collectAsStateWithLifecycle()
    val allTransactions by adminViewModel.allTransactions.collectAsStateWithLifecycle()
    val allSubscriptions by adminViewModel.allSubscriptions.collectAsStateWithLifecycle()
    val allTickets by adminViewModel.allTickets.collectAsStateWithLifecycle()
    val allTestimonials by adminViewModel.allTestimonials.collectAsStateWithLifecycle()
    val allAnnouncements by adminViewModel.allAnnouncements.collectAsStateWithLifecycle()
    val auditLogs by adminViewModel.auditLogs.collectAsStateWithLifecycle()
    val packages by adminViewModel.packages.collectAsStateWithLifecycle()
    val settings by adminViewModel.platformSettings.collectAsStateWithLifecycle()
    val rfStatus by adminViewModel.rfStatus.collectAsStateWithLifecycle()
    val testingConnection by adminViewModel.testingConnection.collectAsStateWithLifecycle()
    val adminToast by adminViewModel.adminToast.collectAsStateWithLifecycle()

    LaunchedEffect(adminToast) {
        adminToast?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            adminViewModel.clearToast()
        }
    }

    val navigateTo: (String) -> Unit = { route ->
        scope.launch { drawerState.close() }
        navController.navigate(route) {
            launchSingleTop = true
        }
    }

    val adminTitle = when {
        currentRoute == NexoraRoutes.ADMIN_OVERVIEW -> "Admin Overview"
        currentRoute == NexoraRoutes.ADMIN_USERS -> "Manajemen Pengguna"
        currentRoute?.startsWith("admin_user_detail") == true -> "Detail Pengguna"
        currentRoute == NexoraRoutes.ADMIN_BUILDS -> "Semua Build"
        currentRoute?.startsWith("admin_build_detail") == true -> "Detail Build (Admin)"
        currentRoute == NexoraRoutes.ADMIN_TRANSACTIONS -> "Manajemen Transaksi"
        currentRoute == NexoraRoutes.ADMIN_SUBSCRIPTIONS -> "Manajemen Langganan"
        currentRoute == NexoraRoutes.ADMIN_PACKAGES -> "Manajemen Paket"
        currentRoute == NexoraRoutes.ADMIN_TESTIMONIALS -> "Manajemen Testimoni"
        currentRoute == NexoraRoutes.ADMIN_SUPPORT -> "Manajemen Tiket CS"
        currentRoute == NexoraRoutes.ADMIN_ANNOUNCEMENTS -> "Pengumuman"
        currentRoute == NexoraRoutes.ADMIN_SETTINGS -> "Pengaturan Website"
        currentRoute == NexoraRoutes.ADMIN_SETTINGS_API -> "Pengaturan RFBuilder API"
        currentRoute == NexoraRoutes.ADMIN_SETTINGS_PAYMENT -> "Pengaturan Midtrans"
        currentRoute == NexoraRoutes.ADMIN_SETTINGS_WHATSAPP -> "Pengaturan WhatsApp"
        currentRoute == NexoraRoutes.ADMIN_LOGS -> "Activity Logs"
        else -> "Admin Console"
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AdminDrawerContent(
                currentRoute = currentRoute,
                onNavigate = navigateTo,
                onSwitchToUser = {
                    scope.launch { drawerState.close() }
                    onSwitchToUser()
                },
                onSignOut = {
                    scope.launch { drawerState.close() }
                    onSignOut()
                }
            )
        }
    ) {
        Scaffold(
            containerColor = NexoraObsidian,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraSurfaceDark),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Buka menu admin")
                        }
                    },
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(adminTitle, style = MaterialTheme.typography.titleLarge)
                        }
                    },
                    actions = {
                        TextButton(onClick = onSwitchToUser) {
                            Text("User View", color = NexoraCyanGlow)
                        }
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.TopCenter
            ) {
                Box(modifier = Modifier.fillMaxSize().widthIn(max = 780.dp)) {
                    NavHost(
                        navController = navController,
                        startDestination = NexoraRoutes.ADMIN_OVERVIEW
                    ) {
                        composable(NexoraRoutes.ADMIN_OVERVIEW) {
                            AdminOverviewScreen(
                                usersState = allUsers,
                                buildsState = allBuilds,
                                transactionsState = allTransactions,
                                ticketsState = allTickets,
                                onNavigate = navigateTo
                            )
                        }
                        composable(NexoraRoutes.ADMIN_USERS) {
                            AdminUsersScreen(
                                usersState = allUsers,
                                onOpenUserDetail = { uid -> navigateTo(NexoraRoutes.adminUserDetail(uid)) }
                            )
                        }
                        composable(
                            route = NexoraRoutes.ADMIN_USER_DETAIL,
                            arguments = listOf(navArgument("userId") { type = NavType.StringType })
                        ) { entry ->
                            val targetUid = entry.arguments?.getString("userId").orEmpty()
                            AdminUserDetailScreen(
                                userId = targetUid,
                                usersState = allUsers,
                                onUpdateUser = { u, st, pl -> adminViewModel.updateUser(u, st, pl) },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_BUILDS) {
                            AdminBuildsScreen(
                                buildsState = allBuilds,
                                onOpenBuildDetail = { bId -> navigateTo(NexoraRoutes.adminBuildDetail(bId)) }
                            )
                        }
                        composable(
                            route = NexoraRoutes.ADMIN_BUILD_DETAIL,
                            arguments = listOf(navArgument("buildId") { type = NavType.StringType })
                        ) { entry ->
                            val bId = entry.arguments?.getString("buildId").orEmpty()
                            AdminBuildDetailScreen(
                                buildId = bId,
                                buildsState = allBuilds,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_TRANSACTIONS) {
                            AdminTransactionsScreen(transactionsState = allTransactions)
                        }
                        composable(NexoraRoutes.ADMIN_SUBSCRIPTIONS) {
                            AdminSubscriptionsScreen(subscriptionsState = allSubscriptions)
                        }
                        composable(NexoraRoutes.ADMIN_PACKAGES) {
                            AdminPackagesScreen(
                                packagesState = packages,
                                onSavePackage = { c, n, p, q, d, f -> adminViewModel.updatePackage(c, n, p, q, d, f) }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_TESTIMONIALS) {
                            AdminTestimonialsScreen(
                                testimonialsState = allTestimonials,
                                onSaveTestimonial = { id, n, d, r, st, img -> adminViewModel.saveTestimonial(id, n, d, r, st, img) },
                                onDeleteTestimonial = { adminViewModel.deleteTestimonial(it) }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_SUPPORT) {
                            AdminSupportScreen(
                                ticketsState = allTickets,
                                onReplyTicket = { tId, st, rep -> adminViewModel.replySupportTicket(tId, st, rep) }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_ANNOUNCEMENTS) {
                            AdminAnnouncementsScreen(
                                announcementsState = allAnnouncements,
                                onCreateAnnouncement = { t, m, a -> adminViewModel.createAnnouncement(t, m, a) },
                                onToggleAnnouncement = { id, a -> adminViewModel.toggleAnnouncement(id, a) }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_SETTINGS) {
                            AdminWebsiteSettingsScreen(
                                settingsState = settings,
                                onSaveSettings = { adminViewModel.savePlatformSettings(it) }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_SETTINGS_API) {
                            AdminApiSettingsScreen(
                                rfStatus = rfStatus,
                                testing = testingConnection,
                                onTestConnection = { adminViewModel.testRfBuilderConnection() }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_SETTINGS_PAYMENT) {
                            AdminPaymentSettingsScreen(status = adminViewModel.midtransConfigStatus)
                        }
                        composable(NexoraRoutes.ADMIN_SETTINGS_WHATSAPP) {
                            AdminWhatsAppSettingsScreen(
                                settingsState = settings,
                                onSaveSettings = { adminViewModel.savePlatformSettings(it) }
                            )
                        }
                        composable(NexoraRoutes.ADMIN_LOGS) {
                            AdminLogsScreen(logsState = auditLogs)
                        }
                    }
                }
            }
        }
    }
}
