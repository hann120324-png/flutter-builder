package com.example.ui.screens.user

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.rememberAsyncImagePainter
import com.example.data.model.BuildUsage
import com.example.data.model.ScreenOrientationOption
import com.example.data.model.SourceType
import com.example.data.model.SplashType
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.remote.RfBuilderService
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.StatusPill
import com.example.ui.components.openExternalUrl
import com.example.ui.navigation.NexoraRoutes
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent
import com.example.ui.theme.NexoraWarning
import com.example.ui.viewmodel.ALL_ANDROID_PERMISSIONS
import com.example.ui.viewmodel.BuildExecutionState
import com.example.ui.viewmodel.BuildViewModel

@Composable
fun BuildWizardScreen(
    viewModel: BuildViewModel,
    userProfileState: UiState<UserProfile?>,
    usageState: UiState<BuildUsage?>,
    freeDailyQuota: Int,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val form by viewModel.form.collectAsStateWithLifecycle()
    val execState by viewModel.executionState.collectAsStateWithLifecycle()
    val statusMsg by viewModel.statusMessage.collectAsStateWithLifecycle()

    val profile = (userProfileState as? UiState.Success)?.data
    val todayUsage = ((usageState as? UiState.Success)?.data?.totalBuild ?: 0L).toInt()
    var stepValidationError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(statusMsg) {
        statusMsg?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearStatusMessage()
        }
    }

    val sourceFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.updateSourceFile(it, resolveDisplayName(context, it)) }
    }

    val iconPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.updateIcon(it, resolveDisplayName(context, it)) }
    }

    val splashVisualPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let { viewModel.updateSplashFile(it, resolveDisplayName(context, it)) }
    }

    val splashHtmlPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.updateSplashFile(it, resolveDisplayName(context, it)) }
    }

    val stepTitles = listOf(
        "A. Info Aplikasi",
        "B. Sumber Aplikasi",
        "C. Icon Aplikasi",
        "D. Splash Screen",
        "E. Orientasi",
        "F. Permissions",
        "G. Review & Build"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stepTitles[form.currentStep],
                        style = MaterialTheme.typography.titleLarge,
                        color = NexoraTextPrimary
                    )
                    StatusPill("Langkah ${form.currentStep + 1}/7", NexoraCyanGlow)
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    stepTitles.forEachIndexed { idx, _ ->
                        FilterChip(
                            selected = form.currentStep == idx,
                            onClick = { viewModel.setStep(idx) },
                            label = { Text("${idx + 1}") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Execution Result / Processing Card
        when (val state = execState) {
            is BuildExecutionState.Processing -> {
                item {
                    GlassCard(borderColor = NexoraCyanGlow) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(28.dp), color = NexoraCyanGlow)
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Status: Processing", style = MaterialTheme.typography.titleMedium, color = NexoraCyanGlow)
                                Text(
                                    "Mengompilasi APK melalui RFBuilder API. Mohon tunggu hingga proses selesai...",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = NexoraTextSecondary
                                )
                            }
                        }
                    }
                }
            }
            is BuildExecutionState.Success -> {
                item {
                    GlassCard(borderColor = NexoraSuccess) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexoraSuccess)
                            Text("Build APK Berhasil!", style = MaterialTheme.typography.titleLarge, color = NexoraSuccess)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Nama File: ${state.result.fileName}", style = MaterialTheme.typography.bodyLarge, color = NexoraTextPrimary)
                        Text("Ukuran: ${state.result.size}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                        Text("Build ID: ${state.result.buildId}", style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                        Spacer(Modifier.height(12.dp))
                        GradientPrimaryButton(
                            text = "Download APK",
                            icon = Icons.Default.Download,
                            onClick = { openExternalUrl(context, state.result.downloadUrl) },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "build_result_download_button"
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    copyToClipboard(context, "Build ID", state.result.buildId)
                                },
                                modifier = Modifier.weight(1f).height(48.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Salin ID")
                            }
                            OutlinedButton(
                                onClick = { onNavigate(NexoraRoutes.BUILD_HISTORY) },
                                modifier = Modifier.weight(1f).height(48.dp)
                            ) {
                                Text("Riwayat")
                            }
                        }
                    }
                }
            }
            is BuildExecutionState.Error -> {
                item {
                    GlassCard(borderColor = NexoraError) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = NexoraError)
                            Text("Build Tidak Dapat Diproses", style = MaterialTheme.typography.titleMedium, color = NexoraError)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(state.message, style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                        Spacer(Modifier.height(10.dp))
                        if (state.isQuotaExhausted) {
                            GradientPrimaryButton(
                                text = "Upgrade ke NEXORA PRO",
                                onClick = { onNavigate(NexoraRoutes.PACKAGES) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            OutlinedButton(
                                onClick = { viewModel.resetExecution() },
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text("Coba Lagi")
                            }
                        }
                    }
                }
            }
            BuildExecutionState.Idle -> Unit
        }

        // Step Form Body
        item {
            GlassCard {
                when (form.currentStep) {
                    0 -> {
                        OutlinedTextField(
                            value = form.appName,
                            onValueChange = { viewModel.updateAppInfo(it, form.packageName, form.versionName, form.versionCode) },
                            label = { Text("App Name") },
                            placeholder = { Text("Toko Online Saya") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("build_app_name_input")
                        )
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = form.packageName,
                            onValueChange = { viewModel.updateAppInfo(form.appName, it, form.versionName, form.versionCode) },
                            label = { Text("Package Name") },
                            placeholder = { Text("com.nexora.aplikasi") },
                            supportingText = {
                                val ok = RfBuilderService.isValidPackageName(form.packageName)
                                Text(
                                    text = if (ok) "Format package name valid" else "Contoh valid: com.nexora.aplikasi",
                                    color = if (ok) NexoraSuccess else NexoraWarning
                                )
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("build_package_name_input")
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = form.versionName,
                                onValueChange = { viewModel.updateAppInfo(form.appName, form.packageName, it, form.versionCode) },
                                label = { Text("Version Name") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = form.versionCode,
                                onValueChange = { viewModel.updateAppInfo(form.appName, form.packageName, form.versionName, it.filter { c -> c.isDigit() }) },
                                label = { Text("Version Code") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    1 -> {
                        Text("Pilih Sumber Aplikasi", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        Spacer(Modifier.height(8.dp))
                        SourceType.entries.forEach { src ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = form.sourceType == src,
                                    onClick = { viewModel.updateSourceType(src) }
                                )
                                Text(src.label, color = NexoraTextPrimary)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        when (form.sourceType) {
                            SourceType.URL -> {
                                OutlinedTextField(
                                    value = form.url,
                                    onValueChange = { viewModel.updateUrl(it) },
                                    label = { Text("Website URL") },
                                    placeholder = { Text("https://websiteanda.com") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("build_url_input")
                                )
                            }
                            SourceType.HTML -> {
                                OutlinedButton(
                                    onClick = { sourceFilePicker.launch(arrayOf("text/html", "application/xhtml+xml")) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Icon(Icons.Default.UploadFile, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(form.sourceFileName ?: "Pilih File HTML (.html)")
                                }
                            }
                            SourceType.ZIP -> {
                                OutlinedButton(
                                    onClick = { sourceFilePicker.launch(arrayOf("application/zip", "application/x-zip-compressed")) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Icon(Icons.Default.UploadFile, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(form.sourceFileName ?: "Pilih Arsip Website (.zip)")
                                }
                            }
                        }
                    }

                    2 -> {
                        Text("Upload Icon Aplikasi (PNG, maks 5 MB)", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        Spacer(Modifier.height(10.dp))
                        if (form.iconUri != null) {
                            Image(
                                painter = rememberAsyncImagePainter(form.iconUri),
                                contentDescription = "Preview icon aplikasi",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(96.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .align(Alignment.CenterHorizontally)
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "Terpilih: ${form.iconFileName ?: "icon.png"}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NexoraSuccess
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                        OutlinedButton(
                            onClick = {
                                iconPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (form.iconUri == null) "Pilih Gambar Icon" else "Ganti Gambar Icon")
                        }
                    }

                    3 -> {
                        Text("Konfigurasi Splash Screen", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        Spacer(Modifier.height(8.dp))
                        SplashType.entries.forEach { st ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = form.splashType == st,
                                    onClick = { viewModel.updateSplashType(st) }
                                )
                                Text(st.label, color = NexoraTextPrimary)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        when (form.splashType) {
                            SplashType.DEFAULT -> {
                                Text("Menggunakan splash screen bawaan dari icon & tema aplikasi.", color = NexoraTextSecondary)
                            }
                            SplashType.IMAGE -> {
                                OutlinedButton(
                                    onClick = { splashVisualPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Text(form.splashFileName ?: "Pilih Gambar Splash (PNG/JPG)")
                                }
                            }
                            SplashType.HTML -> {
                                OutlinedButton(
                                    onClick = { splashHtmlPicker.launch(arrayOf("text/html")) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Text(form.splashFileName ?: "Pilih File HTML Splash")
                                }
                            }
                            SplashType.VIDEO -> {
                                OutlinedButton(
                                    onClick = { splashVisualPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Text(form.splashFileName ?: "Pilih Video Splash (MP4)")
                                }
                            }
                        }
                    }

                    4 -> {
                        Text("Orientasi Layar Aplikasi", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        Spacer(Modifier.height(8.dp))
                        ScreenOrientationOption.entries.forEach { opt ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = form.orientation == opt,
                                    onClick = { viewModel.updateOrientation(opt) }
                                )
                                Text(opt.label, color = NexoraTextPrimary)
                            }
                        }
                    }

                    5 -> {
                        Text("Android Permissions", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        Text(
                            "Pilih hanya permission yang benar-benar dibutuhkan website Anda.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = NexoraTextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        ALL_ANDROID_PERMISSIONS.forEach { perm ->
                            val checked = form.selectedPermissions.contains(perm.name)
                            Row(
                                verticalAlignment = Alignment.Top,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { viewModel.togglePermission(perm.name) }
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(perm.name, style = MaterialTheme.typography.labelLarge, color = NexoraTextPrimary)
                                        if (perm.isSensitive) {
                                            Icon(
                                                Icons.Default.WarningAmber,
                                                contentDescription = "Permission sensitif",
                                                tint = NexoraWarning,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = if (perm.isSensitive) "Sensitif: ${perm.description}" else perm.description,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (perm.isSensitive && checked) NexoraWarning else NexoraTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    6 -> {
                        Text("Ringkasan Konfigurasi Build", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                        Spacer(Modifier.height(10.dp))
                        SummaryRow("Nama Aplikasi", form.appName.ifBlank { "-" })
                        SummaryRow("Package Name", form.packageName)
                        SummaryRow("Versi", "${form.versionName} (Code ${form.versionCode})")
                        SummaryRow(
                            "Sumber",
                            when (form.sourceType) {
                                SourceType.URL -> form.url
                                else -> "${form.sourceType.label}: ${form.sourceFileName ?: "Belum dipilih"}"
                            }
                        )
                        SummaryRow("Icon", form.iconFileName ?: "Default / belum diunggah")
                        SummaryRow("Splash Screen", "${form.splashType.label} ${form.splashFileName?.let { "($it)" } ?: ""}")
                        SummaryRow("Orientasi", form.orientation.label)
                        SummaryRow("Permissions (${form.selectedPermissions.size})", form.selectedPermissions.joinToString(", "))

                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.saveDraft() },
                                modifier = Modifier.weight(1f).height(48.dp),
                                border = BorderStroke(1.dp, NexoraVioletAccent)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Simpan Draft")
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        GradientPrimaryButton(
                            text = "Mulai Build APK",
                            icon = Icons.Default.Build,
                            loading = execState is BuildExecutionState.Processing,
                            onClick = {
                                viewModel.startBuild(
                                    userProfile = profile,
                                    todayUsageCount = todayUsage,
                                    freeDailyQuota = freeDailyQuota
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "start_build_submit_button"
                        )
                    }
                }

                if (!stepValidationError.isNullOrBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(stepValidationError!!, style = MaterialTheme.typography.bodyMedium, color = NexoraError)
                }
            }
        }

        // Step Navigation Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (form.currentStep > 0) {
                    OutlinedButton(
                        onClick = {
                            stepValidationError = null
                            viewModel.setStep(form.currentStep - 1)
                        },
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Text("Kembali")
                    }
                }
                if (form.currentStep < 6) {
                    GradientPrimaryButton(
                        text = "Lanjut",
                        onClick = {
                            val err = viewModel.validateStep(form.currentStep)
                            if (err != null) {
                                stepValidationError = err
                            } else {
                                stepValidationError = null
                                viewModel.setStep(form.currentStep + 1)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        testTag = "build_next_step_button"
                    )
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
    }
}

private fun resolveDisplayName(context: Context, uri: Uri): String? {
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (idx != -1 && cursor.moveToFirst()) return cursor.getString(idx)
    }
    return uri.lastPathSegment
}

fun copyToClipboard(context: Context, label: String, text: String) {
    val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cb.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(context, "$label disalin.", Toast.LENGTH_SHORT).show()
}
