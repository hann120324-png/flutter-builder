package com.example.ui.navigation

object NexoraRoutes {
    // Public routes
    const val HOME = "public_home"
    const val LOGIN = "public_login"
    const val REGISTER = "public_register"
    const val FORGOT_PASSWORD = "public_forgot_password"
    const val PUBLIC_PACKAGES = "public_packages"
    const val ABOUT = "public_about"
    const val CONTACT = "public_contact"
    const val PRIVACY = "public_privacy"
    const val TERMS = "public_terms"
    const val FAQ = "public_faq"

    // User routes
    const val DASHBOARD = "user_dashboard"
    const val BUILD = "user_build"
    const val BUILD_HISTORY = "user_build_history"
    const val BUILD_DETAIL = "user_build_detail/{buildId}"
    const val PACKAGES = "user_packages"
    const val PAYMENT = "user_payment"
    const val PAYMENT_HISTORY = "user_payment_history"
    const val PROFILE = "user_profile"
    const val PROFILE_SECURITY = "user_profile_security"
    const val SUPPORT = "user_support"
    const val SUPPORT_CREATE = "user_support_create"
    const val SUPPORT_DETAIL = "user_support_detail/{ticketId}"
    const val NOTIFICATIONS = "user_notifications"

    // Admin routes
    const val ADMIN_OVERVIEW = "admin_overview"
    const val ADMIN_USERS = "admin_users"
    const val ADMIN_USER_DETAIL = "admin_user_detail/{userId}"
    const val ADMIN_BUILDS = "admin_builds"
    const val ADMIN_BUILD_DETAIL = "admin_build_detail/{buildId}"
    const val ADMIN_TRANSACTIONS = "admin_transactions"
    const val ADMIN_SUBSCRIPTIONS = "admin_subscriptions"
    const val ADMIN_PACKAGES = "admin_packages"
    const val ADMIN_TESTIMONIALS = "admin_testimonials"
    const val ADMIN_SUPPORT = "admin_support"
    const val ADMIN_ANNOUNCEMENTS = "admin_announcements"
    const val ADMIN_SETTINGS = "admin_settings"
    const val ADMIN_SETTINGS_API = "admin_settings_api"
    const val ADMIN_SETTINGS_PAYMENT = "admin_settings_payment"
    const val ADMIN_SETTINGS_WHATSAPP = "admin_settings_whatsapp"
    const val ADMIN_LOGS = "admin_logs"

    fun buildDetail(buildId: String) = "user_build_detail/$buildId"
    fun supportDetail(ticketId: String) = "user_support_detail/$ticketId"
    fun adminUserDetail(userId: String) = "admin_user_detail/$userId"
    fun adminBuildDetail(buildId: String) = "admin_build_detail/$buildId"
}
