package com.example.ui.screens.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Announcement
import com.example.data.model.PackagePlan
import com.example.data.model.PaymentTransaction
import com.example.data.model.SupportTicket
import com.example.data.model.Testimonial
import com.example.data.model.TicketStatus
import com.example.data.model.TransactionStatus
import com.example.data.model.UiState
import com.example.data.model.UserSubscription
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.StatusPill
import com.example.ui.components.formatRupiah
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent
import com.example.ui.theme.NexoraWarning

@Composable
fun AdminTransactionsScreen(transactionsState: UiState<List<PaymentTransaction>>) {
    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (transactions.isEmpty()) {
            item { EmptyStateCard("Belum Ada Transaksi", "Semua transaksi QRIS Midtrans akan muncul di sini.") }
        } else {
            items(transactions, key = { it.id }) { tx ->
                val st = TransactionStatus.from(tx.status)
                val color = when (st) {
                    TransactionStatus.PAID -> NexoraSuccess
                    TransactionStatus.PENDING -> NexoraWarning
                    else -> NexoraError
                }
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(tx.orderId, style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                            Text(formatRupiah(tx.amount), style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                        }
                        StatusPill(st.value, color)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("User UID: ${tx.userId}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                    Text("Tanggal: ${formatTimestamp(tx.createdAt)}", style = MaterialTheme.typography.labelSmall, color = NexoraTextSecondary)
                }
            }
        }
    }
}

@Composable
fun AdminSubscriptionsScreen(subscriptionsState: UiState<List<UserSubscription>>) {
    val subs = (subscriptionsState as? UiState.Success)?.data.orEmpty()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (subs.isEmpty()) {
            item { EmptyStateCard("Belum Ada Langganan", "Daftar langganan aktif pengguna akan muncul di sini.") }
        } else {
            items(subs, key = { it.userId }) { sub ->
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("UID: ${sub.userId}", style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                            Text("Paket: ${sub.packageCode.uppercase()}", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        }
                        StatusPill(
                            sub.status.uppercase(),
                            if (sub.packageCode == "pro") NexoraVioletAccent else NexoraElectricBlue
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Mulai: ${formatTimestamp(sub.startedAt)}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                }
            }
        }
    }
}

@Composable
fun AdminPackagesScreen(
    packagesState: UiState<List<PackagePlan>>,
    onSavePackage: (code: String, name: String, price: Long, quota: Long, desc: String, features: List<String>) -> Unit
) {
    val packages = (packagesState as? UiState.Success)?.data.orEmpty()
    val freePlan = packages.firstOrNull { it.code == "free" } ?: PackagePlan(code = "free", name = "FREE", price = 0L, dailyQuota = 3L, description = "Paket Gratis")
    val proPlan = packages.firstOrNull { it.code == "pro" } ?: PackagePlan(code = "pro", name = "NEXORA PRO", price = 10000L, dailyQuota = -1L, description = "Paket Pro")

    var freeQuota by remember(freePlan) { mutableStateOf(freePlan.dailyQuota.toString()) }
    var freeDesc by remember(freePlan) { mutableStateOf(freePlan.description) }
    var proPrice by remember(proPlan) { mutableStateOf(proPlan.price.toString()) }
    var proDesc by remember(proPlan) { mutableStateOf(proPlan.description) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Text("Pengaturan Paket FREE", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = freeQuota,
                    onValueChange = { freeQuota = it.filter { c -> c.isDigit() } },
                    label = { Text("Kuota Build Harian") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = freeDesc,
                    onValueChange = { freeDesc = it },
                    label = { Text("Deskripsi") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                GradientPrimaryButton(
                    text = "Simpan Paket FREE",
                    onClick = {
                        onSavePackage("free", freePlan.name.ifBlank { "FREE" }, 0L, freeQuota.toLongOrNull() ?: 3L, freeDesc, freePlan.features)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            GlassCard {
                Text("Pengaturan Paket NEXORA PRO", style = MaterialTheme.typography.titleLarge, color = NexoraVioletAccent)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = proPrice,
                    onValueChange = { proPrice = it.filter { c -> c.isDigit() } },
                    label = { Text("Harga (Rupiah)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = proDesc,
                    onValueChange = { proDesc = it },
                    label = { Text("Deskripsi") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                GradientPrimaryButton(
                    text = "Simpan Paket PRO",
                    onClick = {
                        onSavePackage("pro", proPlan.name.ifBlank { "NEXORA PRO" }, proPrice.toLongOrNull() ?: 10000L, -1L, proDesc, proPlan.features)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun AdminTestimonialsScreen(
    testimonialsState: UiState<List<Testimonial>>,
    onSaveTestimonial: (id: String?, name: String, desc: String, rating: Long, status: String, imageUrl: String?) -> Unit,
    onDeleteTestimonial: (String) -> Unit
) {
    val testimonials = (testimonialsState as? UiState.Success)?.data.orEmpty()
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var rating by remember { mutableStateOf("5") }
    var published by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Text("Tambah Testimoni Pelanggan", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Pelanggan") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Isi Testimoni") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = rating,
                    onValueChange = { rating = it.filter { c -> c.isDigit() }.take(1) },
                    label = { Text("Rating (1-5)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Publikasikan Langsung", color = NexoraTextPrimary)
                    Switch(checked = published, onCheckedChange = { published = it })
                }
                Spacer(Modifier.height(10.dp))
                GradientPrimaryButton(
                    text = "Simpan Testimoni",
                    icon = Icons.Default.Add,
                    enabled = name.isNotBlank() && description.length >= 3,
                    onClick = {
                        onSaveTestimonial(
                            null,
                            name,
                            description,
                            (rating.toLongOrNull() ?: 5L).coerceIn(1L, 5L),
                            if (published) "published" else "draft",
                            null
                        )
                        name = ""
                        description = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        items(testimonials, key = { it.id }) { item ->
            GlassCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.name, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                        StatusPill(item.status, if (item.status == "published") NexoraSuccess else NexoraWarning)
                    }
                    Row {
                        OutlinedButton(onClick = {
                            val nextStatus = if (item.status == "published") "draft" else "published"
                            onSaveTestimonial(item.id, item.name, item.description, item.rating, nextStatus, item.imageUrl)
                        }) {
                            Text(if (item.status == "published") "Draft" else "Publish")
                        }
                        Spacer(Modifier.width(4.dp))
                        IconButton(onClick = { onDeleteTestimonial(item.id) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Hapus testimoni", tint = NexoraError)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("${item.rating}/5 ★ — ${item.description}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
            }
        }
    }
}

@Composable
fun AdminSupportScreen(
    ticketsState: UiState<List<SupportTicket>>,
    onReplyTicket: (ticketId: String, status: String, reply: String) -> Unit
) {
    val tickets = (ticketsState as? UiState.Success)?.data.orEmpty()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (tickets.isEmpty()) {
            item { EmptyStateCard("Belum Ada Tiket CS", "Tiket kendala pengguna akan muncul di sini.") }
        } else {
            items(tickets, key = { it.id }) { ticket ->
                var replyText by remember(ticket.id) { mutableStateOf(ticket.adminReply ?: "") }
                var selectedStatus by remember(ticket.id) { mutableStateOf(ticket.status) }
                GlassCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(ticket.category, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                            Text("${ticket.userName} (${ticket.userEmail})", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                        }
                        StatusPill(TicketStatus.from(ticket.status).label, NexoraCyanGlow)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(ticket.message, style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("open", "in_progress", "resolved", "closed").forEach { st ->
                            FilterChip(
                                selected = selectedStatus == st,
                                onClick = { selectedStatus = st },
                                label = { Text(st) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        label = { Text("Balasan Admin") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    GradientPrimaryButton(
                        text = "Kirim Balasan & Update Status",
                        onClick = { onReplyTicket(ticket.id, selectedStatus, replyText) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun AdminAnnouncementsScreen(
    announcementsState: UiState<List<Announcement>>,
    onCreateAnnouncement: (title: String, message: String, active: Boolean) -> Unit,
    onToggleAnnouncement: (id: String, active: Boolean) -> Unit
) {
    val announcements = (announcementsState as? UiState.Success)?.data.orEmpty()
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Text("Buat Pengumuman Baru", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Judul Pengumuman") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("Isi Pengumuman") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                GradientPrimaryButton(
                    text = "Publikasikan Pengumuman",
                    enabled = title.isNotBlank() && message.isNotBlank(),
                    onClick = {
                        onCreateAnnouncement(title, message, true)
                        title = ""
                        message = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        items(announcements, key = { it.id }) { ann ->
            GlassCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(ann.title, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary, modifier = Modifier.weight(1f))
                    Switch(checked = ann.active, onCheckedChange = { onToggleAnnouncement(ann.id, it) })
                }
                Spacer(Modifier.height(4.dp))
                Text(ann.message, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
            }
        }
    }
}
