package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.PaymentTransaction
import com.example.data.model.TransactionStatus
import com.example.data.remote.MidtransConfigStatus
import com.example.data.remote.MidtransService
import com.example.data.repository.NexoraRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface PaymentFlowState {
    data object Idle : PaymentFlowState
    data object CreatingOrder : PaymentFlowState
    data class AwaitingPayment(
        val orderId: String,
        val amount: Long,
        val qrString: String?,
        val qrUrl: String?
    ) : PaymentFlowState
    data class CheckingStatus(val orderId: String) : PaymentFlowState
    data class Paid(val orderId: String) : PaymentFlowState
    data class Error(val message: String, val isConfigError: Boolean = false) : PaymentFlowState
}

class PaymentViewModel(
    private val repository: NexoraRepository,
    private val midtransService: MidtransService,
    private val currentUserId: String
) : ViewModel() {

    val configStatus: MidtransConfigStatus = midtransService.getConfigStatus()

    private val _flowState = MutableStateFlow<PaymentFlowState>(PaymentFlowState.Idle)
    val flowState = _flowState.asStateFlow()

    fun resumePendingTransaction(tx: PaymentTransaction) {
        if (TransactionStatus.from(tx.status) == TransactionStatus.PENDING) {
            _flowState.value = PaymentFlowState.AwaitingPayment(
                orderId = tx.orderId,
                amount = tx.amount,
                qrString = tx.qrString,
                qrUrl = tx.qrUrl
            )
        }
    }

    fun startProCheckout(
        amount: Long,
        customerName: String,
        customerEmail: String,
        existingPending: PaymentTransaction?
    ) {
        if (existingPending != null && TransactionStatus.from(existingPending.status) == TransactionStatus.PENDING) {
            resumePendingTransaction(existingPending)
            return
        }

        if (!midtransService.isConfigured()) {
            _flowState.value = PaymentFlowState.Error(
                message = "Konfigurasi Midtrans belum lengkap. Set MIDTRANS_SERVER_KEY dan MIDTRANS_CLIENT_KEY di Secrets panel AI Studio.",
                isConfigError = true
            )
            return
        }

        val orderId = "NX-${currentUserId.take(4).uppercase()}-${System.currentTimeMillis()}"
        _flowState.value = PaymentFlowState.CreatingOrder

        viewModelScope.launch {
            val charge = midtransService.createQrisCharge(
                orderId = orderId,
                amount = amount,
                customerName = customerName.ifBlank { "Pengguna NEXORA" },
                customerEmail = customerEmail.ifBlank { "user@nexora.app" }
            )

            if (!charge.success) {
                _flowState.value = PaymentFlowState.Error(
                    message = charge.errorMessage ?: "Gagal membuat tagihan QRIS Midtrans.",
                    isConfigError = charge.isConfigError
                )
                return@launch
            }

            val saveRes = repository.createPendingTransaction(
                orderId = orderId,
                amount = amount,
                qrString = charge.qrString,
                qrUrl = charge.qrUrl,
                midtransTransactionId = charge.transactionId
            )

            saveRes.fold(
                onSuccess = {
                    _flowState.value = PaymentFlowState.AwaitingPayment(
                        orderId = orderId,
                        amount = amount,
                        qrString = charge.qrString,
                        qrUrl = charge.qrUrl
                    )
                },
                onFailure = { err ->
                    _flowState.value = PaymentFlowState.Error(
                        message = err.localizedMessage ?: "Gagal menyimpan order ke database."
                    )
                }
            )
        }
    }

    fun checkOrderStatus(orderId: String, expectedAmount: Long, qrString: String?, qrUrl: String?) {
        _flowState.value = PaymentFlowState.CheckingStatus(orderId)
        viewModelScope.launch {
            val statusRes = midtransService.checkTransactionStatus(orderId, expectedAmount)
            if (!statusRes.success) {
                _flowState.value = PaymentFlowState.Error(
                    message = statusRes.errorMessage ?: "Gagal memeriksa status pembayaran."
                )
                return@launch
            }

            when (statusRes.status) {
                TransactionStatus.PAID -> {
                    val txId = statusRes.transactionId ?: "mid_${System.currentTimeMillis()}"
                    val updateRes = repository.updateTransactionFromMidtrans(
                        orderId = orderId,
                        newStatus = TransactionStatus.PAID,
                        midtransTransactionId = txId
                    )
                    updateRes.fold(
                        onSuccess = { _flowState.value = PaymentFlowState.Paid(orderId) },
                        onFailure = { err ->
                            _flowState.value = PaymentFlowState.Error(
                                err.localizedMessage ?: "Pembayaran terdeteksi, namun gagal mengaktifkan paket."
                            )
                        }
                    )
                }
                TransactionStatus.PENDING -> {
                    _flowState.value = PaymentFlowState.AwaitingPayment(
                        orderId = orderId,
                        amount = expectedAmount,
                        qrString = qrString,
                        qrUrl = qrUrl
                    )
                }
                TransactionStatus.EXPIRED, TransactionStatus.CANCELLED, TransactionStatus.FAILED -> {
                    repository.updateTransactionFromMidtrans(
                        orderId = orderId,
                        newStatus = statusRes.status,
                        midtransTransactionId = statusRes.transactionId
                    )
                    _flowState.value = PaymentFlowState.Error(
                        message = "Transaksi berstatus ${statusRes.status.value}. Silakan buat order baru."
                    )
                }
            }
        }
    }

    fun resetState() {
        _flowState.value = PaymentFlowState.Idle
    }
}
