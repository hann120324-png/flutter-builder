package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Announcement
import com.example.data.model.ApkBuild
import com.example.data.model.AuditLog
import com.example.data.model.PackagePlan
import com.example.data.model.PaymentTransaction
import com.example.data.model.PlatformSettings
import com.example.data.model.SupportTicket
import com.example.data.model.Testimonial
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.UserSubscription
import com.example.data.remote.MidtransConfigStatus
import com.example.data.remote.MidtransService
import com.example.data.remote.RfBuilderService
import com.example.data.remote.RfConnectionStatus
import com.example.data.repository.NexoraRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AdminViewModel(
    private val repository: NexoraRepository,
    private val rfBuilderService: RfBuilderService,
    midtransService: MidtransService,
    val currentUserId: String
) : ViewModel() {

    val allUsers: StateFlow<UiState<List<UserProfile>>> =
        repository.observeAllUsers().asUiState("allUsers")

    val allBuilds: StateFlow<UiState<List<ApkBuild>>> =
        repository.observeAllBuilds().asUiState("allBuilds")

    val allTransactions: StateFlow<UiState<List<PaymentTransaction>>> =
        repository.observeAllTransactions().asUiState("allTransactions")

    val allSubscriptions: StateFlow<UiState<List<UserSubscription>>> =
        repository.observeAllSubscriptions().asUiState("allSubscriptions")

    val allTickets: StateFlow<UiState<List<SupportTicket>>> =
        repository.observeAllTickets().asUiState("allTickets")

    val allTestimonials: StateFlow<UiState<List<Testimonial>>> =
        repository.observeAllTestimonials().asUiState("allTestimonials")

    val allAnnouncements: StateFlow<UiState<List<Announcement>>> =
        repository.observeAllAnnouncements().asUiState("allAnnouncements")

    val auditLogs: StateFlow<UiState<List<AuditLog>>> =
        repository.observeAuditLogs().asUiState("auditLogs")

    val packages: StateFlow<UiState<List<PackagePlan>>> =
        repository.observePackages().asUiState("packages")

    val platformSettings: StateFlow<UiState<PlatformSettings>> =
        repository.observePlatformSettings().asUiState("platformSettings")

    val midtransConfigStatus: MidtransConfigStatus = midtransService.getConfigStatus()

    private val _rfStatus = MutableStateFlow(
        RfConnectionStatus(
            isKeyConfigured = rfBuilderService.isConfigured(),
            maskedKey = rfBuilderService.maskedKey(),
            reachable = false,
            statusCode = null,
            message = if (rfBuilderService.isConfigured()) {
                "API Key terkonfigurasi. Tekan Uji Koneksi untuk verifikasi jaringan."
            } else {
                "RFBUILDER_API_KEY belum diset di Secrets panel AI Studio."
            }
        )
    )
    val rfStatus = _rfStatus.asStateFlow()

    private val _testingConnection = MutableStateFlow(false)
    val testingConnection = _testingConnection.asStateFlow()

    private val _adminToast = MutableStateFlow<String?>(null)
    val adminToast = _adminToast.asStateFlow()

    fun clearToast() {
        _adminToast.value = null
    }

    fun testRfBuilderConnection() {
        viewModelScope.launch {
            _testingConnection.value = true
            _rfStatus.value = rfBuilderService.testConnection()
            _testingConnection.value = false
        }
    }

    fun updateUser(targetUid: String, status: String, plan: String) {
        viewModelScope.launch {
            val res = repository.adminUpdateUser(targetUid, status, plan)
            _adminToast.value = res.fold(
                onSuccess = { "Status & paket pengguna diperbarui." },
                onFailure = { it.localizedMessage ?: "Gagal memperbarui pengguna." }
            )
        }
    }

    fun updatePackage(
        code: String,
        name: String,
        price: Long,
        dailyQuota: Long,
        description: String,
        features: List<String>
    ) {
        viewModelScope.launch {
            val res = repository.adminUpdatePackage(code, name, price, dailyQuota, description, features)
            _adminToast.value = res.fold(
                onSuccess = { "Paket $name berhasil diperbarui." },
                onFailure = { it.localizedMessage ?: "Gagal memperbarui paket." }
            )
        }
    }

    fun saveTestimonial(
        id: String?,
        name: String,
        description: String,
        rating: Long,
        status: String,
        imageUrl: String?
    ) {
        viewModelScope.launch {
            val res = repository.adminSaveTestimonial(id, name, description, rating, status, imageUrl)
            _adminToast.value = res.fold(
                onSuccess = { "Testimoni disimpan." },
                onFailure = { it.localizedMessage ?: "Gagal menyimpan testimoni." }
            )
        }
    }

    fun deleteTestimonial(id: String) {
        viewModelScope.launch {
            val res = repository.adminDeleteTestimonial(id)
            _adminToast.value = res.fold(
                onSuccess = { "Testimoni dihapus." },
                onFailure = { it.localizedMessage ?: "Gagal menghapus testimoni." }
            )
        }
    }

    fun replySupportTicket(ticketId: String, status: String, adminReply: String) {
        viewModelScope.launch {
            val res = repository.adminReplySupportTicket(ticketId, status, adminReply)
            _adminToast.value = res.fold(
                onSuccess = { "Balasan tiket disimpan." },
                onFailure = { it.localizedMessage ?: "Gagal membalas tiket." }
            )
        }
    }

    fun createAnnouncement(title: String, message: String, active: Boolean) {
        viewModelScope.launch {
            val res = repository.adminSaveAnnouncement(title, message, active)
            _adminToast.value = res.fold(
                onSuccess = { "Pengumuman dipublikasikan." },
                onFailure = { it.localizedMessage ?: "Gagal membuat pengumuman." }
            )
        }
    }

    fun toggleAnnouncement(id: String, active: Boolean) {
        viewModelScope.launch {
            val res = repository.adminToggleAnnouncement(id, active)
            _adminToast.value = res.fold(
                onSuccess = { if (active) "Pengumuman diaktifkan." else "Pengumuman dinonaktifkan." },
                onFailure = { it.localizedMessage ?: "Gagal mengubah status pengumuman." }
            )
        }
    }

    fun savePlatformSettings(settings: PlatformSettings) {
        viewModelScope.launch {
            val res = repository.adminSavePlatformSettings(settings)
            _adminToast.value = res.fold(
                onSuccess = { "Pengaturan platform berhasil disimpan." },
                onFailure = { it.localizedMessage ?: "Gagal menyimpan pengaturan." }
            )
        }
    }

    private fun <T> Flow<T>.asUiState(label: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $label", rootError)
                emit(UiState.Error(rootError.message ?: "Gagal memuat $label"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    private companion object {
        const val TAG = "AdminViewModel"
    }
}
