package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Announcement
import androidx.compose.material.icons.filled.Api
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Reviews
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.PlatformSettings
import com.example.data.model.UserProfile
import com.example.ui.navigation.NexoraRoutes
import com.example.ui.theme.NexoraAdminCrimson
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraDeepNavy
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraObsidian
import com.example.ui.theme.NexoraRoyalPurple
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraSurfaceCard
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraSurfaceElevated
import com.example.ui.theme.NexoraTextMuted
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent
import com.google.firebase.Timestamp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

val NexoraPrimaryGradient = Brush.horizontalGradient(
    colors = listOf(NexoraElectricBlue, NexoraRoyalPurple)
)

fun formatRupiah(amount: Long): String {
    val formatter = NumberFormat.getNumberInstance(Locale("in", "ID"))
    return "Rp${formatter.format(amount)}"
}

fun formatTimestamp(ts: Timestamp?): String {
    if (ts == null) return "Baru saja"
    val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("in", "ID"))
    return sdf.format(ts.toDate())
}

fun openExternalUrl(context: Context, rawUrl: String) {
    val trimmed = rawUrl.trim()
    if (!trimmed.startsWith("https://") && !trimmed.startsWith("http://")) {
        Toast.makeText(context, "URL tidak valid.", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(trimmed)))
    } catch (_: Exception) {
        Toast.makeText(context, "Tidak ada aplikasi untuk membuka tautan.", Toast.LENGTH_SHORT).show()
    }
}

fun buildWhatsAppUrl(phoneNumber: String?, prefillText: String): String? {
    val digits = phoneNumber.orEmpty().filter { it.isDigit() }
    if (digits.length < 8) return null
    val normalized = if (digits.startsWith("0")) "62${digits.drop(1)}" else digits
    return "https://wa.me/$normalized?text=${Uri.encode(prefillText)}"
}

@Composable
fun NexoraBrandLogo(
    modifier: Modifier = Modifier,
    subtitle: String? = "WEB2APK"
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(NexoraPrimaryGradient),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "N",
                style = MaterialTheme.typography.titleLarge,
                color = NexoraTextPrimary,
                fontWeight = FontWeight.Bold
            )
        }
        Column {
            Text(
                text = "NEXORA",
                style = MaterialTheme.typography.titleMedium,
                color = NexoraTextPrimary,
                fontWeight = FontWeight.Bold
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = NexoraCyanGlow
                )
            }
        }
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    borderColor: Color = NexoraBorderSubtle,
    containerColor: Color = NexoraSurfaceCard,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val cardModifier = modifier
        .fillMaxWidth()
        .clip(MaterialTheme.shapes.medium)
        .background(containerColor)
        .border(1.dp, borderColor, MaterialTheme.shapes.medium)
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }
        .padding(contentPadding)

    Column(modifier = cardModifier, content = content)
}

@Composable
fun GradientPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    icon: ImageVector? = null,
    testTag: String? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled && !loading,
        contentPadding = PaddingValues(0.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            disabledContainerColor = NexoraSurfaceElevated
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .height(50.dp)
            .let { if (testTag != null) it.testTag(testTag) else it }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    if (enabled && !loading) NexoraPrimaryGradient
                    else Brush.horizontalGradient(listOf(NexoraSurfaceElevated, NexoraSurfaceElevated)),
                    shape = RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = NexoraTextPrimary,
                    strokeWidth = 2.dp
                )
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (icon != null) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = NexoraTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = text,
                        style = MaterialTheme.typography.labelLarge,
                        color = NexoraTextPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun StatusPill(
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.16f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun SkeletonPlaceholderCard(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "skeleton")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(
            animation = tween(850),
            repeatMode = RepeatMode.Reverse
        ),
        label = "skeletonAlpha"
    )
    GlassCard(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.55f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(NexoraSurfaceElevated.copy(alpha = alpha))
        )
        Spacer(Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(NexoraSurfaceElevated.copy(alpha = alpha))
        )
    }
}

@Composable
fun EmptyStateCard(
    title: String,
    description: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_builds),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = NexoraTextPrimary
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = NexoraTextSecondary
            )
            if (actionLabel != null && onAction != null) {
                Spacer(Modifier.height(14.dp))
                GradientPrimaryButton(
                    text = actionLabel,
                    onClick = onAction,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun WhatsAppSupportButtons(
    settings: PlatformSettings,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val adminUrl = buildWhatsAppUrl(settings.whatsappAdmin, "Halo Admin NEXORA WEB2APK, saya ingin bertanya.")
    val csUrl = buildWhatsAppUrl(settings.whatsappCs, "Halo CS NEXORA WEB2APK, saya mengalami kendala.")
    val channelUrl = settings.whatsappChannel?.takeIf { it.startsWith("https://") }

    GlassCard(modifier = modifier) {
        Text(
            text = "Saluran Resmi WhatsApp",
            style = MaterialTheme.typography.titleMedium,
            color = NexoraTextPrimary
        )
        Spacer(Modifier.height(6.dp))
        if (adminUrl == null && csUrl == null && channelUrl == null) {
            Text(
                text = "Kontak WhatsApp Admin/CS dan Channel belum diatur oleh Admin.",
                style = MaterialTheme.typography.bodyMedium,
                color = NexoraTextSecondary
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (adminUrl != null) {
                    OutlinedButton(
                        onClick = { openExternalUrl(context, adminUrl) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("whatsapp_admin_button"),
                        border = BorderStroke(1.dp, NexoraSuccess)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, tint = NexoraSuccess)
                        Spacer(Modifier.width(8.dp))
                        Text("HUBUNGI ADMIN", color = NexoraSuccess)
                    }
                }
                if (csUrl != null) {
                    OutlinedButton(
                        onClick = { openExternalUrl(context, csUrl) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("whatsapp_cs_button"),
                        border = BorderStroke(1.dp, NexoraElectricBlue)
                    ) {
                        Icon(Icons.Default.SupportAgent, contentDescription = null, tint = NexoraElectricBlue)
                        Spacer(Modifier.width(8.dp))
                        Text("CS KENDALA", color = NexoraElectricBlue)
                    }
                }
                if (channelUrl != null) {
                    OutlinedButton(
                        onClick = { openExternalUrl(context, channelUrl) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("whatsapp_channel_button"),
                        border = BorderStroke(1.dp, NexoraVioletAccent)
                    ) {
                        Icon(Icons.Default.Groups, contentDescription = null, tint = NexoraVioletAccent)
                        Spacer(Modifier.width(8.dp))
                        Text("GABUNG CHANNEL", color = NexoraVioletAccent)
                    }
                }
            }
        }
    }
}

private data class BottomNavTab(
    val route: String,
    val label: String,
    val activeIcon: ImageVector,
    val inactiveIcon: ImageVector,
    val testTag: String
)

@Composable
fun UserBottomNavBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    val tabs = listOf(
        BottomNavTab(NexoraRoutes.DASHBOARD, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
        BottomNavTab(NexoraRoutes.BUILD, "Build", Icons.Filled.Build, Icons.Outlined.Build, "nav_build"),
        BottomNavTab(NexoraRoutes.BUILD_HISTORY, "Riwayat", Icons.Filled.History, Icons.Outlined.History, "nav_history"),
        BottomNavTab(NexoraRoutes.PACKAGES, "Paket", Icons.Filled.Inventory2, Icons.Outlined.Inventory2, "nav_packages"),
        BottomNavTab(NexoraRoutes.PROFILE, "Profil", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
    )

    NavigationBar(
        containerColor = NexoraSurfaceDark,
        contentColor = NexoraTextPrimary,
        windowInsets = WindowInsets.navigationBars,
        tonalElevation = 0.dp
    ) {
        tabs.forEach { tab ->
            val selected = currentRoute == tab.route ||
                (tab.route == NexoraRoutes.BUILD_HISTORY && currentRoute?.startsWith("user_build_detail") == true)
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(tab.route) },
                icon = {
                    Icon(
                        imageVector = if (selected) tab.activeIcon else tab.inactiveIcon,
                        contentDescription = tab.label
                    )
                },
                label = {
                    Text(
                        text = tab.label,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.labelSmall
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = NexoraCyanGlow,
                    selectedTextColor = NexoraCyanGlow,
                    indicatorColor = NexoraElectricBlue.copy(alpha = 0.18f),
                    unselectedIconColor = NexoraTextSecondary,
                    unselectedTextColor = NexoraTextSecondary
                ),
                modifier = Modifier.testTag(tab.testTag)
            )
        }
    }
}

@Composable
fun UserDrawerContent(
    user: UserProfile?,
    isAdmin: Boolean,
    currentRoute: String?,
    unreadNotifications: Int,
    settings: PlatformSettings,
    onNavigate: (String) -> Unit,
    onSwitchToAdmin: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    ModalDrawerSheet(
        drawerContainerColor = NexoraObsidian,
        drawerContentColor = NexoraTextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            NexoraBrandLogo(subtitle = "SAAS PLATFORM")
            Spacer(Modifier.height(14.dp))
            GlassCard(contentPadding = PaddingValues(12.dp)) {
                Text(
                    text = user?.name ?: "Pengguna NEXORA",
                    style = MaterialTheme.typography.titleMedium,
                    color = NexoraTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = user?.email ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexoraTextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(6.dp))
                StatusPill(
                    label = if (user?.plan == "pro") "PAKET PRO" else "PAKET FREE",
                    color = if (user?.plan == "pro") NexoraVioletAccent else NexoraElectricBlue
                )
            }
            Spacer(Modifier.height(16.dp))

            DrawerSectionLabel("MAIN")
            DrawerNavItem("Dashboard", Icons.Default.Dashboard, currentRoute == NexoraRoutes.DASHBOARD) {
                onNavigate(NexoraRoutes.DASHBOARD)
            }
            DrawerNavItem("Build APK", Icons.Default.Build, currentRoute == NexoraRoutes.BUILD) {
                onNavigate(NexoraRoutes.BUILD)
            }
            DrawerNavItem("Riwayat Build", Icons.Default.History, currentRoute == NexoraRoutes.BUILD_HISTORY) {
                onNavigate(NexoraRoutes.BUILD_HISTORY)
            }

            Spacer(Modifier.height(12.dp))
            DrawerSectionLabel("ACCOUNT")
            DrawerNavItem("Paket Saya", Icons.Default.Inventory2, currentRoute == NexoraRoutes.PACKAGES) {
                onNavigate(NexoraRoutes.PACKAGES)
            }
            DrawerNavItem("Pembayaran", Icons.Default.Payment, currentRoute == NexoraRoutes.PAYMENT) {
                onNavigate(NexoraRoutes.PAYMENT)
            }
            DrawerNavItem("Riwayat Transaksi", Icons.Default.ReceiptLong, currentRoute == NexoraRoutes.PAYMENT_HISTORY) {
                onNavigate(NexoraRoutes.PAYMENT_HISTORY)
            }
            DrawerNavItem("Profil", Icons.Default.Person, currentRoute == NexoraRoutes.PROFILE) {
                onNavigate(NexoraRoutes.PROFILE)
            }
            DrawerNavItem("Keamanan Akun", Icons.Default.Security, currentRoute == NexoraRoutes.PROFILE_SECURITY) {
                onNavigate(NexoraRoutes.PROFILE_SECURITY)
            }
            DrawerNavItem(
                label = if (unreadNotifications > 0) "Notifikasi ($unreadNotifications)" else "Notifikasi",
                icon = Icons.Default.Notifications,
                selected = currentRoute == NexoraRoutes.NOTIFICATIONS
            ) {
                onNavigate(NexoraRoutes.NOTIFICATIONS)
            }

            Spacer(Modifier.height(12.dp))
            DrawerSectionLabel("SUPPORT")
            DrawerNavItem("Pusat Bantuan", Icons.AutoMirrored.Filled.HelpOutline, currentRoute == NexoraRoutes.SUPPORT) {
                onNavigate(NexoraRoutes.SUPPORT)
            }
            DrawerNavItem("CS Kendala", Icons.Default.SupportAgent, currentRoute == NexoraRoutes.SUPPORT_CREATE) {
                onNavigate(NexoraRoutes.SUPPORT_CREATE)
            }
            DrawerNavItem("Channel WhatsApp", Icons.Default.Groups, false) {
                val ch = settings.whatsappChannel
                if (!ch.isNullOrBlank() && ch.startsWith("https://")) {
                    openExternalUrl(context, ch)
                } else {
                    Toast.makeText(context, "Channel WhatsApp belum diatur Admin.", Toast.LENGTH_SHORT).show()
                }
            }

            if (isAdmin) {
                Spacer(Modifier.height(14.dp))
                HorizontalDivider(color = NexoraBorderSubtle)
                Spacer(Modifier.height(10.dp))
                DrawerNavItem("Buka Admin Panel", Icons.Default.AdminPanelSettings, false, accent = NexoraAdminCrimson) {
                    onSwitchToAdmin()
                }
            }

            Spacer(Modifier.height(14.dp))
            HorizontalDivider(color = NexoraBorderSubtle)
            Spacer(Modifier.height(10.dp))
            DrawerNavItem("Logout", Icons.AutoMirrored.Filled.Logout, false) {
                onSignOut()
            }
        }
    }
}

@Composable
fun AdminDrawerContent(
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    onSwitchToUser: () -> Unit,
    onSignOut: () -> Unit
) {
    ModalDrawerSheet(
        drawerContainerColor = NexoraObsidian,
        drawerContentColor = NexoraTextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            NexoraBrandLogo(subtitle = "ADMIN CONSOLE")
            Spacer(Modifier.height(12.dp))
            StatusPill("ADMINISTRATOR", NexoraAdminCrimson)
            Spacer(Modifier.height(16.dp))

            DrawerSectionLabel("OVERVIEW")
            DrawerNavItem("Dashboard", Icons.Default.Dashboard, currentRoute == NexoraRoutes.ADMIN_OVERVIEW) {
                onNavigate(NexoraRoutes.ADMIN_OVERVIEW)
            }

            Spacer(Modifier.height(10.dp))
            DrawerSectionLabel("USER MANAGEMENT")
            DrawerNavItem("Pengguna", Icons.Default.Groups, currentRoute == NexoraRoutes.ADMIN_USERS) {
                onNavigate(NexoraRoutes.ADMIN_USERS)
            }
            DrawerNavItem("Langganan", Icons.Default.VerifiedUser, currentRoute == NexoraRoutes.ADMIN_SUBSCRIPTIONS) {
                onNavigate(NexoraRoutes.ADMIN_SUBSCRIPTIONS)
            }

            Spacer(Modifier.height(10.dp))
            DrawerSectionLabel("BUILD MANAGEMENT")
            DrawerNavItem("Semua Build", Icons.Default.Build, currentRoute == NexoraRoutes.ADMIN_BUILDS) {
                onNavigate(NexoraRoutes.ADMIN_BUILDS)
            }

            Spacer(Modifier.height(10.dp))
            DrawerSectionLabel("FINANCIAL")
            DrawerNavItem("Transaksi", Icons.Default.ReceiptLong, currentRoute == NexoraRoutes.ADMIN_TRANSACTIONS) {
                onNavigate(NexoraRoutes.ADMIN_TRANSACTIONS)
            }
            DrawerNavItem("Manajemen Paket", Icons.Default.Inventory2, currentRoute == NexoraRoutes.ADMIN_PACKAGES) {
                onNavigate(NexoraRoutes.ADMIN_PACKAGES)
            }

            Spacer(Modifier.height(10.dp))
            DrawerSectionLabel("CONTENT MANAGEMENT")
            DrawerNavItem("Testimoni", Icons.Default.Reviews, currentRoute == NexoraRoutes.ADMIN_TESTIMONIALS) {
                onNavigate(NexoraRoutes.ADMIN_TESTIMONIALS)
            }
            DrawerNavItem("Pengumuman", Icons.Default.Announcement, currentRoute == NexoraRoutes.ADMIN_ANNOUNCEMENTS) {
                onNavigate(NexoraRoutes.ADMIN_ANNOUNCEMENTS)
            }

            Spacer(Modifier.height(10.dp))
            DrawerSectionLabel("CUSTOMER SERVICE")
            DrawerNavItem("Tiket Kendala", Icons.Default.SupportAgent, currentRoute == NexoraRoutes.ADMIN_SUPPORT) {
                onNavigate(NexoraRoutes.ADMIN_SUPPORT)
            }

            Spacer(Modifier.height(10.dp))
            DrawerSectionLabel("SYSTEM SETTINGS")
            DrawerNavItem("Pengaturan Website", Icons.Default.Settings, currentRoute == NexoraRoutes.ADMIN_SETTINGS) {
                onNavigate(NexoraRoutes.ADMIN_SETTINGS)
            }
            DrawerNavItem("Pengaturan RFBuilder API", Icons.Default.Api, currentRoute == NexoraRoutes.ADMIN_SETTINGS_API) {
                onNavigate(NexoraRoutes.ADMIN_SETTINGS_API)
            }
            DrawerNavItem("Pengaturan Midtrans", Icons.Default.CreditCard, currentRoute == NexoraRoutes.ADMIN_SETTINGS_PAYMENT) {
                onNavigate(NexoraRoutes.ADMIN_SETTINGS_PAYMENT)
            }
            DrawerNavItem("Pengaturan WhatsApp", Icons.Default.Chat, currentRoute == NexoraRoutes.ADMIN_SETTINGS_WHATSAPP) {
                onNavigate(NexoraRoutes.ADMIN_SETTINGS_WHATSAPP)
            }

            Spacer(Modifier.height(10.dp))
            DrawerSectionLabel("SYSTEM")
            DrawerNavItem("Activity Logs", Icons.Default.History, currentRoute == NexoraRoutes.ADMIN_LOGS) {
                onNavigate(NexoraRoutes.ADMIN_LOGS)
            }
            DrawerNavItem("Buka User App", Icons.Default.Home, false, accent = NexoraCyanGlow) {
                onSwitchToUser()
            }
            DrawerNavItem("Logout", Icons.AutoMirrored.Filled.Logout, false) {
                onSignOut()
            }
        }
    }
}

@Composable
private fun DrawerSectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        color = NexoraTextMuted,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
    )
}

@Composable
private fun DrawerNavItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    accent: Color = NexoraCyanGlow,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        label = { Text(label, style = MaterialTheme.typography.bodyLarge) },
        icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp)) },
        selected = selected,
        onClick = onClick,
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = NexoraElectricBlue.copy(alpha = 0.2f),
            selectedIconColor = accent,
            selectedTextColor = NexoraTextPrimary,
            unselectedContainerColor = Color.Transparent,
            unselectedIconColor = if (accent != NexoraCyanGlow) accent else NexoraTextSecondary,
            unselectedTextColor = if (accent != NexoraCyanGlow) accent else NexoraTextSecondary
        ),
        modifier = Modifier.padding(vertical = 2.dp)
    )
}
