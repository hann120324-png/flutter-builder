package com.example.ui.screens.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AccountStatus
import com.example.data.model.ApkBuild
import com.example.data.model.BuildStatus
import com.example.data.model.PaymentTransaction
import com.example.data.model.PlanTier
import com.example.data.model.SupportTicket
import com.example.data.model.TicketStatus
import com.example.data.model.TransactionStatus
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.GlassCard
import com.example.ui.components.StatusPill
import com.example.ui.components.formatRupiah
import com.example.ui.navigation.NexoraRoutes
import com.example.ui.theme.NexoraAdminCrimson
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent
import com.example.ui.theme.NexoraWarning

@Composable
fun AdminOverviewScreen(
    usersState: UiState<List<UserProfile>>,
    buildsState: UiState<List<ApkBuild>>,
    transactionsState: UiState<List<PaymentTransaction>>,
    ticketsState: UiState<List<SupportTicket>>,
    onNavigate: (String) -> Unit
) {
    val users = (usersState as? UiState.Success)?.data.orEmpty()
    val builds = (buildsState as? UiState.Success)?.data.orEmpty()
    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    val tickets = (ticketsState as? UiState.Success)?.data.orEmpty()

    val activeUsers = users.count { AccountStatus.from(it.status) == AccountStatus.ACTIVE }
    val freeUsers = users.count { PlanTier.from(it.plan) == PlanTier.FREE }
    val proUsers = users.count { PlanTier.from(it.plan) == PlanTier.PRO }
    val successBuilds = builds.count { BuildStatus.from(it.status) == BuildStatus.SUCCESS }
    val failedBuilds = builds.count { BuildStatus.from(it.status) == BuildStatus.FAILED }
    val paidRevenue = transactions.filter { TransactionStatus.from(it.status) == TransactionStatus.PAID }.sumOf { it.amount }
    val openTickets = tickets.count { TicketStatus.from(it.status) == TicketStatus.OPEN }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard(borderColor = NexoraAdminCrimson.copy(alpha = 0.5f)) {
                StatusPill("ADMIN OVERVIEW", NexoraAdminCrimson)
                Spacer(Modifier.height(8.dp))
                Text("Ringkasan Ekosistem NEXORA", style = MaterialTheme.typography.headlineMedium, color = NexoraTextPrimary)
                Text("Data real-time langsung dari Cloud Firestore.", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatTile("Total Pengguna", users.size.toString(), NexoraElectricBlue, Modifier.weight(1f))
                AdminStatTile("Pengguna Aktif", activeUsers.toString(), NexoraSuccess, Modifier.weight(1f))
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatTile("Paket Free", freeUsers.toString(), NexoraCyanGlow, Modifier.weight(1f))
                AdminStatTile("Paket Pro", proUsers.toString(), NexoraVioletAccent, Modifier.weight(1f))
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatTile("Total Build", builds.size.toString(), NexoraElectricBlue, Modifier.weight(1f))
                AdminStatTile("Build Berhasil", successBuilds.toString(), NexoraSuccess, Modifier.weight(1f))
                AdminStatTile("Build Gagal", failedBuilds.toString(), NexoraError, Modifier.weight(1f))
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatTile("Total Transaksi", transactions.size.toString(), NexoraCyanGlow, Modifier.weight(1f))
                AdminStatTile("Pendapatan Paid", formatRupiah(paidRevenue), NexoraSuccess, Modifier.weight(1f))
            }
        }

        item {
            GlassCard {
                Text("Aksi Cepat Admin", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onNavigate(NexoraRoutes.ADMIN_USERS) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                        Text("Kelola Pengguna (${users.size})")
                    }
                    OutlinedButton(onClick = { onNavigate(NexoraRoutes.ADMIN_BUILDS) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                        Text("Monitor Semua Build (${builds.size})")
                    }
                    OutlinedButton(onClick = { onNavigate(NexoraRoutes.ADMIN_SUPPORT) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                        Text("Tiket Support Open ($openTickets)", color = if (openTickets > 0) NexoraWarning else NexoraTextPrimary)
                    }
                    OutlinedButton(onClick = { onNavigate(NexoraRoutes.ADMIN_SETTINGS_API) }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                        Text("Status RFBuilder API & Midtrans")
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatTile(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(modifier = modifier, contentPadding = PaddingValues(12.dp)) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
        Spacer(Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleLarge, color = color, fontWeight = FontWeight.Bold)
    }
}
