package com.example.ui.screens.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.AuditLog
import com.example.data.model.PlatformSettings
import com.example.data.model.UiState
import com.example.data.remote.MidtransConfigStatus
import com.example.data.remote.RfConnectionStatus
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.StatusPill
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraWarning

@Composable
fun AdminWebsiteSettingsScreen(
    settingsState: UiState<PlatformSettings>,
    onSaveSettings: (PlatformSettings) -> Unit
) {
    val current = (settingsState as? UiState.Success)?.data ?: PlatformSettings()
    var name by remember { mutableStateOf(current.platformName) }
    var tagline by remember { mutableStateOf(current.tagline) }
    var description by remember { mutableStateOf(current.description) }

    LaunchedEffect(current) {
        name = current.platformName
        tagline = current.tagline
        description = current.description
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Text("Pengaturan Identitas Website & Platform", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nama Platform") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = tagline, onValueChange = { tagline = it }, label = { Text("Tagline") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Deskripsi") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                GradientPrimaryButton(
                    text = "Simpan Pengaturan Website",
                    icon = Icons.Default.Save,
                    onClick = {
                        onSaveSettings(current.copy(platformName = name, tagline = tagline, description = description))
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun AdminApiSettingsScreen(
    rfStatus: RfConnectionStatus,
    testing: Boolean,
    onTestConnection: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("RFBuilder API", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                    StatusPill(
                        label = if (rfStatus.isKeyConfigured) "TERKONFIGURASI" else "BELUM DISET",
                        color = if (rfStatus.isKeyConfigured) NexoraSuccess else NexoraWarning
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("Endpoint: https://rfweb2apk.rfdevv.com/api/apk/build-api", style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                Spacer(Modifier.height(6.dp))
                Text("API Key (disamarkan): ${rfStatus.maskedKey}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                Spacer(Modifier.height(6.dp))
                Text(rfStatus.message, style = MaterialTheme.typography.bodyMedium, color = if (rfStatus.reachable) NexoraSuccess else NexoraTextSecondary)
                Spacer(Modifier.height(10.dp))
                Text(
                    "Catatan Kapasitas API: Free = 3 build/hari, Pro = 20 build/hari, ProMax/ProMax++ = Unlimited. Kunci API dikelola aman melalui panel Secrets AI Studio (RFBUILDER_API_KEY).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexoraTextSecondary
                )
                Spacer(Modifier.height(14.dp))
                GradientPrimaryButton(
                    text = "Uji Koneksi RFBuilder",
                    icon = Icons.Default.NetworkCheck,
                    loading = testing,
                    onClick = onTestConnection,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun AdminPaymentSettingsScreen(status: MidtransConfigStatus) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Midtrans Gateway", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                    StatusPill(
                        label = if (status.isConfigured) "AKTIF" else "BELUM LENGKAP",
                        color = if (status.isConfigured) NexoraSuccess else NexoraWarning
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("Mode: ${if (status.isProduction) "Production" else "Sandbox"}", style = MaterialTheme.typography.bodyLarge, color = NexoraCyanGlow)
                Spacer(Modifier.height(6.dp))
                Text("Server Key (disamarkan): ${status.maskedServerKey}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                Text("Client Key (disamarkan): ${status.maskedClientKey}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                Spacer(Modifier.height(10.dp))
                Text(
                    "Atur MIDTRANS_SERVER_KEY, MIDTRANS_CLIENT_KEY, dan MIDTRANS_IS_PRODUCTION melalui panel Secrets AI Studio. Kunci utuh tidak pernah ditampilkan di antarmuka.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexoraTextSecondary
                )
            }
        }
    }
}

@Composable
fun AdminWhatsAppSettingsScreen(
    settingsState: UiState<PlatformSettings>,
    onSaveSettings: (PlatformSettings) -> Unit
) {
    val current = (settingsState as? UiState.Success)?.data ?: PlatformSettings()
    var adminWa by remember { mutableStateOf(current.whatsappAdmin.orEmpty()) }
    var csWa by remember { mutableStateOf(current.whatsappCs.orEmpty()) }
    var channelUrl by remember { mutableStateOf(current.whatsappChannel.orEmpty()) }

    LaunchedEffect(current) {
        adminWa = current.whatsappAdmin.orEmpty()
        csWa = current.whatsappCs.orEmpty()
        channelUrl = current.whatsappChannel.orEmpty()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard {
                Text("Pengaturan WhatsApp Admin, CS & Channel", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = adminWa,
                    onValueChange = { adminWa = it },
                    label = { Text("Nomor WhatsApp Admin (cth: 62812xxxx)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = csWa,
                    onValueChange = { csWa = it },
                    label = { Text("Nomor WhatsApp CS Kendala (cth: 62812xxxx)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = channelUrl,
                    onValueChange = { channelUrl = it },
                    label = { Text("Link Channel WhatsApp (https://whatsapp.com/channel/...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(14.dp))
                GradientPrimaryButton(
                    text = "Simpan Kontak WhatsApp",
                    icon = Icons.Default.Save,
                    onClick = {
                        onSaveSettings(
                            current.copy(
                                whatsappAdmin = adminWa.ifBlank { null },
                                whatsappCs = csWa.ifBlank { null },
                                whatsappChannel = channelUrl.ifBlank { null }
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun AdminLogsScreen(logsState: UiState<List<AuditLog>>) {
    val logs = (logsState as? UiState.Success)?.data.orEmpty()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (logs.isEmpty()) {
            item { EmptyStateCard("Belum Ada Activity Log", "Setiap aksi admin akan tercatat secara otomatis di sini.") }
        } else {
            items(logs, key = { it.id }) { log ->
                GlassCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(log.action, style = MaterialTheme.typography.labelLarge, color = NexoraCyanGlow)
                        Text(formatTimestamp(log.createdAt), style = MaterialTheme.typography.labelSmall, color = NexoraTextSecondary)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(log.details, style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                    Text("Oleh: ${log.adminEmail}", style = MaterialTheme.typography.labelSmall, color = NexoraTextSecondary)
                }
            }
        }
    }
}
