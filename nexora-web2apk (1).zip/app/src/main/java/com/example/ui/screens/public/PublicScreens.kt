package com.example.ui.screens.public

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.NexoraBrandLogo
import com.example.ui.components.StatusPill
import com.example.ui.navigation.NexoraRoutes
import com.example.ui.theme.NexoraBorderSubtle
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraDeepNavy
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraObsidian
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraSurfaceDark
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublicLandingScreen(
    onNavigate: (String) -> Unit
) {
    Scaffold(
        containerColor = NexoraDeepNavy,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraObsidian),
                title = { NexoraBrandLogo() },
                actions = {
                    TextButton(onClick = { onNavigate(NexoraRoutes.PUBLIC_PACKAGES) }) {
                        Text("Harga", color = NexoraTextSecondary)
                    }
                    TextButton(onClick = { onNavigate(NexoraRoutes.FAQ) }) {
                        Text("FAQ", color = NexoraTextSecondary)
                    }
                    TextButton(
                        onClick = { onNavigate(NexoraRoutes.LOGIN) },
                        modifier = Modifier.testTag("landing_login_button")
                    ) {
                        Text("Masuk", color = NexoraCyanGlow)
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Hero Section
                item {
                    GlassCard(
                        borderColor = NexoraElectricBlue.copy(alpha = 0.45f),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_hero_banner),
                                contentDescription = "Ilustrasi NEXORA WEB2APK mengubah website menjadi aplikasi Android",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color.Transparent, NexoraDeepNavy.copy(alpha = 0.92f))
                                        )
                                    )
                            )
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(16.dp)
                            ) {
                                StatusPill("Your Website, Your Android App.", NexoraCyanGlow)
                            }
                        }

                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "Ubah Website Menjadi Aplikasi Android.",
                                style = MaterialTheme.typography.displaySmall,
                                color = NexoraTextPrimary
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "Buat APK Android dari website kamu dengan mudah, cepat, dan praktis langsung dari smartphone tanpa laptop atau coding.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = NexoraTextSecondary
                            )
                            Spacer(Modifier.height(16.dp))
                            GradientPrimaryButton(
                                text = "Mulai Build",
                                icon = Icons.Default.Build,
                                onClick = { onNavigate(NexoraRoutes.LOGIN) },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "hero_start_build_button"
                            )
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = { onNavigate(NexoraRoutes.PUBLIC_PACKAGES) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("hero_view_packages_button"),
                                border = BorderStroke(1.dp, NexoraBorderSubtle),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NexoraTextPrimary)
                            ) {
                                Text("Lihat Paket")
                            }
                        }
                    }
                }

                // Keunggulan
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Keunggulan Platform",
                            style = MaterialTheme.typography.headlineMedium,
                            color = NexoraTextPrimary
                        )
                        val features = listOf(
                            Triple("Build Online", "Kompilasi APK di cloud langsung melalui API RFBuilder.", Icons.Default.CloudDone),
                            Triple("Tidak Perlu Laptop", "Rancang aplikasi langsung dari HP Android Anda.", Icons.Default.PhoneAndroid),
                            Triple("Upload Icon Sendiri", "Gunakan icon PNG bisnis Anda dengan pratinjau langsung.", Icons.Default.Brush),
                            Triple("Custom Splash Screen", "Pilih Default, Image, HTML, atau Video MP4.", Icons.Default.CheckCircle),
                            Triple("Pengaturan Aplikasi", "Atur Package Name, Versi, Orientasi, dan Permissions.", Icons.Default.Settings),
                            Triple("Download APK", "Unduh file APK siap pasang setelah build selesai.", Icons.Default.Download)
                        )
                        features.forEach { (title, desc, icon) ->
                            FeatureRowCard(title = title, desc = desc, icon = icon)
                        }
                    }
                }

                // Cara Kerja
                item {
                    GlassCard {
                        Text(
                            text = "Cara Kerja 3 Langkah",
                            style = MaterialTheme.typography.titleLarge,
                            color = NexoraTextPrimary
                        )
                        Spacer(Modifier.height(12.dp))
                        StepItem("1", "Masukkan URL Website / HTML / ZIP", "Pilih sumber web online maupun file offline.")
                        Spacer(Modifier.height(10.dp))
                        StepItem("2", "Atur Konfigurasi Aplikasi", "Set nama aplikasi, package name, icon, splash screen, dan permissions.")
                        Spacer(Modifier.height(10.dp))
                        StepItem("3", "Build & Download APK", "Sistem memproses build secara real-time dan memberikan link download APK.")
                    }
                }

                // Paket Harga Ringkas
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Paket Harga Transparan",
                            style = MaterialTheme.typography.headlineMedium,
                            color = NexoraTextPrimary
                        )
                        PackagePreviewCard(
                            name = "FREE",
                            price = "Rp0",
                            badge = "MULAI GRATIS",
                            badgeColor = NexoraElectricBlue,
                            bullets = listOf(
                                "3 kali build per hari",
                                "Build URL, HTML offline, & ZIP offline",
                                "Upload icon, splash screen, & permissions"
                            ),
                            onSelect = { onNavigate(NexoraRoutes.LOGIN) }
                        )
                        PackagePreviewCard(
                            name = "NEXORA PRO",
                            price = "Rp10.000",
                            badge = "QRIS INSTAN",
                            badgeColor = NexoraVioletAccent,
                            bullets = listOf(
                                "Semua fasilitas paket Free",
                                "Kuota internal NEXORA tanpa batas harian",
                                "Mengikuti kapasitas limit API RFBuilder aktif"
                            ),
                            onSelect = { onNavigate(NexoraRoutes.LOGIN) }
                        )
                    }
                }

                // Honest Platform Stats & Testimonials note
                item {
                    GlassCard {
                        Text(
                            text = "Statistik & Testimoni Nyata",
                            style = MaterialTheme.typography.titleMedium,
                            color = NexoraTextPrimary
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Masuk dengan akun Google untuk melihat data statistik platform langsung dari database serta testimoni pelanggan terverifikasi.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = NexoraTextSecondary
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { onNavigate(NexoraRoutes.LOGIN) },
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Icon(Icons.Default.Login, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Masuk dengan Google")
                        }
                    }
                }

                // Footer Links
                item {
                    GlassCard(containerColor = NexoraObsidian) {
                        Text(
                            text = "NEXORA WEB2APK",
                            style = MaterialTheme.typography.titleMedium,
                            color = NexoraTextPrimary
                        )
                        Text(
                            text = "Build smarter. Launch faster. Go mobile.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = NexoraCyanGlow
                        )
                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider(color = NexoraBorderSubtle)
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TextButton(onClick = { onNavigate(NexoraRoutes.ABOUT) }) { Text("Tentang") }
                            TextButton(onClick = { onNavigate(NexoraRoutes.CONTACT) }) { Text("Kontak") }
                            TextButton(onClick = { onNavigate(NexoraRoutes.PRIVACY) }) { Text("Privasi") }
                            TextButton(onClick = { onNavigate(NexoraRoutes.TERMS) }) { Text("Syarat") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureRowCard(title: String, desc: String, icon: ImageVector) {
    GlassCard(contentPadding = PaddingValues(14.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(NexoraElectricBlue.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = NexoraCyanGlow)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                Text(desc, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
            }
        }
    }
}

@Composable
private fun StepItem(number: String, title: String, desc: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(NexoraElectricBlue),
            contentAlignment = Alignment.Center
        ) {
            Text(number, style = MaterialTheme.typography.labelLarge, color = NexoraTextPrimary)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
            Text(desc, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
        }
    }
}

@Composable
private fun PackagePreviewCard(
    name: String,
    price: String,
    badge: String,
    badgeColor: Color,
    bullets: List<String>,
    onSelect: () -> Unit
) {
    GlassCard(borderColor = badgeColor.copy(alpha = 0.45f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(name, style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
            StatusPill(badge, badgeColor)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = price,
            style = MaterialTheme.typography.headlineLarge,
            color = NexoraCyanGlow,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))
        bullets.forEach { bullet ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 2.dp)
            ) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = NexoraSuccess,
                    modifier = Modifier.size(16.dp)
                )
                Text(bullet, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
            }
        }
        Spacer(Modifier.height(12.dp))
        GradientPrimaryButton(
            text = "Pilih $name",
            onClick = onSelect,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    initialTab: String = NexoraRoutes.LOGIN,
    isLoading: Boolean,
    errorMessage: String?,
    onGoogleSignIn: () -> Unit,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val heading = when (initialTab) {
        NexoraRoutes.REGISTER -> "Daftar Akun NEXORA"
        NexoraRoutes.FORGOT_PASSWORD -> "Pemulihan Akses Akun"
        else -> "Masuk ke NEXORA WEB2APK"
    }

    Scaffold(
        containerColor = NexoraDeepNavy,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraSurfaceDark),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
                title = { Text(heading, style = MaterialTheme.typography.titleLarge) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            GlassCard(
                modifier = Modifier.widthIn(max = 460.dp),
                borderColor = NexoraElectricBlue.copy(alpha = 0.5f)
            ) {
                NexoraBrandLogo(subtitle = "SECURE ACCESS")
                Spacer(Modifier.height(16.dp))
                Text(
                    text = heading,
                    style = MaterialTheme.typography.headlineMedium,
                    color = NexoraTextPrimary
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (initialTab == NexoraRoutes.FORGOT_PASSWORD) {
                        "Akun NEXORA menggunakan autentikasi Google terverifikasi tanpa kata sandi terpisah. Gunakan tombol Google Sign-In di bawah untuk memulihkan akses."
                    } else {
                        "Masuk atau daftar instan secara aman menggunakan Akun Google Anda melalui Credential Manager Android."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = NexoraTextSecondary
                )
                Spacer(Modifier.height(18.dp))

                if (!errorMessage.isNullOrBlank()) {
                    GlassCard(
                        containerColor = com.example.ui.theme.NexoraError.copy(alpha = 0.14f),
                        borderColor = com.example.ui.theme.NexoraError.copy(alpha = 0.5f),
                        contentPadding = PaddingValues(12.dp)
                    ) {
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = NexoraTextPrimary
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                }

                GradientPrimaryButton(
                    text = "Lanjutkan dengan Google",
                    icon = Icons.Default.Security,
                    loading = isLoading,
                    onClick = onGoogleSignIn,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "google_signin_button"
                )
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = { onNavigate(NexoraRoutes.PRIVACY) }) {
                        Text("Kebijakan Privasi", color = NexoraTextSecondary)
                    }
                    TextButton(onClick = { onNavigate(NexoraRoutes.TERMS) }) {
                        Text("Syarat & Ketentuan", color = NexoraTextSecondary)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublicInfoScreen(
    route: String,
    onBack: () -> Unit,
    onGoToLogin: () -> Unit
) {
    val title = when (route) {
        NexoraRoutes.PUBLIC_PACKAGES -> "Paket & Harga"
        NexoraRoutes.ABOUT -> "Tentang NEXORA"
        NexoraRoutes.CONTACT -> "Kontak Kami"
        NexoraRoutes.PRIVACY -> "Kebijakan Privasi"
        NexoraRoutes.TERMS -> "Syarat & Ketentuan"
        else -> "Pertanyaan Umum (FAQ)"
    }

    Scaffold(
        containerColor = NexoraDeepNavy,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NexoraSurfaceDark),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Kembali")
                    }
                },
                title = { Text(title, style = MaterialTheme.typography.titleLarge) }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (route) {
                NexoraRoutes.PUBLIC_PACKAGES -> {
                    item {
                        PackagePreviewCard(
                            name = "FREE",
                            price = "Rp0",
                            badge = "3 BUILD / HARI",
                            badgeColor = NexoraElectricBlue,
                            bullets = listOf(
                                "3 kali build per hari (dihitung di server)",
                                "Build URL, HTML offline, ZIP offline",
                                "Upload icon PNG, custom splash, & permissions"
                            ),
                            onSelect = onGoToLogin
                        )
                    }
                    item {
                        PackagePreviewCard(
                            name = "NEXORA PRO",
                            price = "Rp10.000",
                            badge = "UNLIMITED INTERNAL",
                            badgeColor = NexoraVioletAccent,
                            bullets = listOf(
                                "Semua fitur paket Free",
                                "Kuota internal NEXORA tanpa batas harian",
                                "Kapasitas eksekusi mengikuti kuota aktif API RFBuilder"
                            ),
                            onSelect = onGoToLogin
                        )
                    }
                }
                NexoraRoutes.ABOUT -> {
                    item {
                        GlassCard {
                            Text("NEXORA WEB2APK", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "NEXORA WEB2APK adalah platform SaaS mobile-first yang membantu pemilik website, UMKM, dan kreator mengubah website maupun arsip HTML/ZIP menjadi aplikasi Android APK siap pakai langsung dari smartphone.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = NexoraTextSecondary
                            )
                        }
                    }
                }
                NexoraRoutes.CONTACT -> {
                    item {
                        GlassCard {
                            Text("Pusat Kontak & Dukungan", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Masuk ke aplikasi untuk membuat tiket kendala, melampirkan Build ID, dan mengakses tautan WhatsApp Admin, CS Kendala, serta Channel resmi yang dikelola oleh Admin.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NexoraTextSecondary
                            )
                            Spacer(Modifier.height(12.dp))
                            GradientPrimaryButton("Masuk untuk Hubungi CS", onGoToLogin, Modifier.fillMaxWidth())
                        }
                    }
                }
                NexoraRoutes.PRIVACY -> {
                    item {
                        GlassCard {
                            Text("Kebijakan Privasi", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Data akun Google (nama, email, UID), riwayat build, transaksi, dan tiket dukungan disimpan secara terisolasi per pengguna menggunakan aturan keamanan zero-trust. File icon/splash/sumber hanya dikirim ke layanan kompilasi APK saat Anda memulai build.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NexoraTextSecondary
                            )
                        }
                    }
                }
                NexoraRoutes.TERMS -> {
                    item {
                        GlassCard {
                            Text("Syarat & Ketentuan", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Pengguna dilarang membuat APK untuk tujuan phishing, malware, atau pelanggaran hak cipta. Paket PRO memberikan kuota internal tanpa batas harian namun tetap tunduk pada kapasitas API penyedia kompilasi RFBuilder.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = NexoraTextSecondary
                            )
                        }
                    }
                }
                else -> {
                    val faqs = listOf(
                        "Apakah perlu laptop atau coding?" to "Tidak. Semua konfigurasi aplikasi dan build dijalankan secara cloud langsung dari HP Android.",
                        "Bagaimana kuota paket Free dan Pro?" to "Paket Free mendapat 3 build/hari. Paket Pro (Rp10.000) menghapus batas harian internal NEXORA dan mengikuti kapasitas API RFBuilder.",
                        "Bagaimana metode pembayaran Pro?" to "Pembayaran diproses melalui gateway resmi Midtrans QRIS dan status diverifikasi langsung oleh server transaksi.",
                        "Di mana APK hasil build diunduh?" to "Setelah build berhasil, tautan unduhan resmi dari RFBuilder langsung tersedia di hasil build dan Riwayat Build."
                    )
                    faqs.forEach { (q, a) ->
                        item {
                            GlassCard {
                                Text(q, style = MaterialTheme.typography.titleMedium, color = NexoraCyanGlow)
                                Spacer(Modifier.height(6.dp))
                                Text(a, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}
