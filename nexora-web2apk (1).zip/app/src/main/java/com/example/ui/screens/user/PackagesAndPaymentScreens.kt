package com.example.ui.screens.user

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.rememberAsyncImagePainter
import com.example.data.model.BuildUsage
import com.example.data.model.PackagePlan
import com.example.data.model.PaymentTransaction
import com.example.data.model.PlanTier
import com.example.data.model.TransactionStatus
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.StatusPill
import com.example.ui.components.formatRupiah
import com.example.ui.components.formatTimestamp
import com.example.ui.navigation.NexoraRoutes
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent
import com.example.ui.theme.NexoraWarning
import com.example.ui.viewmodel.PaymentFlowState
import com.example.ui.viewmodel.PaymentViewModel

@Composable
fun PackagesScreen(
    userProfileState: UiState<UserProfile?>,
    usageState: UiState<BuildUsage?>,
    packagesState: UiState<List<PackagePlan>>,
    onUpgradePro: () -> Unit,
    onOpenPaymentHistory: () -> Unit
) {
    val profile = (userProfileState as? UiState.Success)?.data
    val activePlan = PlanTier.from(profile?.plan)
    val usageCount = ((usageState as? UiState.Success)?.data?.totalBuild ?: 0L).toInt()
    val remotePackages = (packagesState as? UiState.Success)?.data.orEmpty()

    val freePkg = remotePackages.firstOrNull { it.code == "free" } ?: PackagePlan(
        code = "free",
        name = "FREE",
        price = 0L,
        dailyQuota = 3L,
        description = "Mulai ubah website menjadi APK Android secara gratis.",
        features = listOf(
            "3 kali build per hari",
            "Build dari URL, HTML offline, & ZIP offline",
            "Upload icon & custom splash screen",
            "Pengaturan package name, versi, orientasi, & permissions",
            "Riwayat build & download APK"
        )
    )

    val proPkg = remotePackages.firstOrNull { it.code == "pro" } ?: PackagePlan(
        code = "pro",
        name = "NEXORA PRO",
        price = 10000L,
        dailyQuota = -1L,
        description = "Kuota internal NEXORA tanpa batas harian, mengikuti kapasitas aktif API RFBuilder.",
        features = listOf(
            "Semua fitur paket Free",
            "Kuota internal NEXORA tanpa batas harian",
            "Kapasitas eksekusi mengikuti kuota aktif API RFBuilder",
            "Riwayat build & download APK lengkap"
        )
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (activePlan == PlanTier.FREE && freePkg.dailyQuota > 0 && usageCount >= freePkg.dailyQuota) {
            item {
                GlassCard(borderColor = NexoraWarning) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = NexoraWarning)
                        Text(
                            text = "Kuota build harian kamu sudah habis. Upgrade ke Pro untuk mendapatkan kuota lebih besar.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = NexoraWarning
                        )
                    }
                }
            }
        }

        item {
            PackagePlanCard(
                plan = freePkg,
                isActive = activePlan == PlanTier.FREE,
                quotaLabel = "${freePkg.dailyQuota} build / hari",
                accent = NexoraElectricBlue,
                actionLabel = if (activePlan == PlanTier.FREE) "Paket Aktif" else "Paket Dasar",
                actionEnabled = false,
                onAction = {}
            )
        }

        item {
            PackagePlanCard(
                plan = proPkg,
                isActive = activePlan == PlanTier.PRO,
                quotaLabel = "Tanpa batas internal (mengikuti limit API RFBuilder)",
                accent = NexoraVioletAccent,
                actionLabel = if (activePlan == PlanTier.PRO) "Paket Pro Aktif" else "Upgrade ke Pro (${formatRupiah(proPkg.price)})",
                actionEnabled = activePlan != PlanTier.PRO,
                onAction = onUpgradePro
            )
        }

        item {
            OutlinedButton(
                onClick = onOpenPaymentHistory,
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.ReceiptLong, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Lihat Riwayat Transaksi")
            }
        }
    }
}

@Composable
private fun PackagePlanCard(
    plan: PackagePlan,
    isActive: Boolean,
    quotaLabel: String,
    accent: Color,
    actionLabel: String,
    actionEnabled: Boolean,
    onAction: () -> Unit
) {
    GlassCard(borderColor = if (isActive) accent else accent.copy(alpha = 0.4f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(plan.name, style = MaterialTheme.typography.headlineMedium, color = NexoraTextPrimary)
            StatusPill(
                label = if (isActive) "AKTIF" else plan.code.uppercase(),
                color = if (isActive) NexoraSuccess else accent
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = formatRupiah(plan.price),
            style = MaterialTheme.typography.headlineLarge,
            color = NexoraCyanGlow,
            fontWeight = FontWeight.Bold
        )
        Text("Batas penggunaan: $quotaLabel", style = MaterialTheme.typography.labelSmall, color = NexoraTextSecondary)
        Spacer(Modifier.height(8.dp))
        Text(plan.description, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
        Spacer(Modifier.height(10.dp))
        plan.features.forEach { feat ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 3.dp)
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexoraSuccess, modifier = Modifier.size(16.dp))
                Text(feat, style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
            }
        }
        Spacer(Modifier.height(14.dp))
        GradientPrimaryButton(
            text = actionLabel,
            enabled = actionEnabled,
            onClick = onAction,
            modifier = Modifier.fillMaxWidth(),
            testTag = "subscribe_${plan.code}_button"
        )
    }
}

@Composable
fun PaymentScreen(
    paymentViewModel: PaymentViewModel,
    userProfileState: UiState<UserProfile?>,
    transactionsState: UiState<List<PaymentTransaction>>,
    proPrice: Long,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current
    val flowState by paymentViewModel.flowState.collectAsStateWithLifecycle()
    val profile = (userProfileState as? UiState.Success)?.data
    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()
    val pendingTx = transactions.firstOrNull { TransactionStatus.from(it.status) == TransactionStatus.PENDING }
    val isPro = PlanTier.from(profile?.plan) == PlanTier.PRO

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            GlassCard(borderColor = NexoraVioletAccent.copy(alpha = 0.5f)) {
                Text("Ringkasan Upgrade Paket", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                Spacer(Modifier.height(8.dp))
                Text("Paket: NEXORA PRO", style = MaterialTheme.typography.bodyLarge, color = NexoraTextPrimary)
                Text("Harga: ${formatRupiah(proPrice)}", style = MaterialTheme.typography.headlineMedium, color = NexoraCyanGlow)
                Text("Metode Pembayaran: QRIS (Midtrans)", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                Spacer(Modifier.height(6.dp))
                StatusPill(
                    label = if (paymentViewModel.configStatus.isProduction) "MIDTRANS PRODUCTION" else "MIDTRANS SANDBOX",
                    color = if (paymentViewModel.configStatus.isConfigured) NexoraElectricBlue else NexoraWarning
                )
            }
        }

        if (!paymentViewModel.configStatus.isConfigured) {
            item {
                GlassCard(borderColor = NexoraWarning) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = NexoraWarning)
                        Text("Konfigurasi Midtrans Belum Lengkap", style = MaterialTheme.typography.titleMedium, color = NexoraWarning)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Kredensial MIDTRANS_SERVER_KEY dan MIDTRANS_CLIENT_KEY belum diatur di panel Secrets AI Studio. Pembayaran QRIS nyata akan aktif setelah kredensial dikonfigurasi.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = NexoraTextSecondary
                    )
                }
            }
        }

        if (isPro) {
            item {
                GlassCard(borderColor = NexoraSuccess) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexoraSuccess)
                        Text("Akun Anda Sudah NEXORA PRO", style = MaterialTheme.typography.titleMedium, color = NexoraSuccess)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Anda tidak perlu melakukan pembayaran ulang.", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                }
            }
        } else {
            item {
                when (val state = flowState) {
                    is PaymentFlowState.Idle -> {
                        GlassCard {
                            if (pendingTx != null) {
                                Text("Transaksi Tertunda Ditemukan", style = MaterialTheme.typography.titleMedium, color = NexoraWarning)
                                Text("Order ID: ${pendingTx.orderId}", style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                                Spacer(Modifier.height(10.dp))
                                GradientPrimaryButton(
                                    text = "Lanjutkan Pembayaran QRIS",
                                    icon = Icons.Default.QrCode2,
                                    onClick = { paymentViewModel.resumePendingTransaction(pendingTx) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else {
                                GradientPrimaryButton(
                                    text = "Buat Tagihan QRIS (${formatRupiah(proPrice)})",
                                    icon = Icons.Default.QrCode2,
                                    enabled = paymentViewModel.configStatus.isConfigured,
                                    onClick = {
                                        paymentViewModel.startProCheckout(
                                            amount = proPrice,
                                            customerName = profile?.name ?: "Pengguna NEXORA",
                                            customerEmail = profile?.email ?: "user@nexora.app",
                                            existingPending = pendingTx
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    testTag = "create_qris_payment_button"
                                )
                            }
                        }
                    }

                    is PaymentFlowState.CreatingOrder, is PaymentFlowState.CheckingStatus -> {
                        GlassCard {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = NexoraCyanGlow)
                                Text(
                                    text = if (state is PaymentFlowState.CreatingOrder) "Membuat transaksi QRIS di Midtrans..."
                                    else "Memverifikasi status pembayaran di Midtrans...",
                                    color = NexoraTextPrimary
                                )
                            }
                        }
                    }

                    is PaymentFlowState.AwaitingPayment -> {
                        GlassCard(borderColor = NexoraCyanGlow) {
                            Text("Scan QRIS untuk Membayar", style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                            Text("Order ID: ${state.orderId}", style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                            Text("Nominal: ${formatRupiah(state.amount)}", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                            Spacer(Modifier.height(12.dp))
                            if (!state.qrUrl.isNullOrBlank()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color.White)
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        painter = rememberAsyncImagePainter(state.qrUrl),
                                        contentDescription = "QRIS Midtrans",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.size(220.dp)
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                            }
                            if (!state.qrString.isNullOrBlank()) {
                                OutlinedButton(
                                    onClick = { copyToClipboard(context, "QRIS String", state.qrString) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Salin Kode QRIS")
                                }
                                Spacer(Modifier.height(8.dp))
                            }
                            GradientPrimaryButton(
                                text = "Verifikasi Status Pembayaran",
                                icon = Icons.Default.Refresh,
                                onClick = {
                                    paymentViewModel.checkOrderStatus(
                                        orderId = state.orderId,
                                        expectedAmount = state.amount,
                                        qrString = state.qrString,
                                        qrUrl = state.qrUrl
                                    )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "verify_payment_status_button"
                            )
                        }
                    }

                    is PaymentFlowState.Paid -> {
                        GlassCard(borderColor = NexoraSuccess) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NexoraSuccess)
                                Text("Pembayaran Berhasil!", style = MaterialTheme.typography.titleLarge, color = NexoraSuccess)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("Order ${state.orderId} telah terkonfirmasi dan paket NEXORA PRO Anda sudah aktif.", color = NexoraTextPrimary)
                            Spacer(Modifier.height(10.dp))
                            GradientPrimaryButton(
                                text = "Mulai Build Sekarang",
                                onClick = { onNavigate(NexoraRoutes.BUILD) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    is PaymentFlowState.Error -> {
                        GlassCard(borderColor = NexoraError) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = NexoraError)
                                Text("Status Pembayaran", style = MaterialTheme.typography.titleMedium, color = NexoraError)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(state.message, color = NexoraTextPrimary)
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = { paymentViewModel.resetState() },
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text("Kembali")
                            }
                        }
                    }
                }
            }
        }

        item {
            OutlinedButton(
                onClick = { onNavigate(NexoraRoutes.PAYMENT_HISTORY) },
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.ReceiptLong, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Riwayat Transaksi")
            }
        }
    }
}

@Composable
fun PaymentHistoryScreen(
    transactionsState: UiState<List<PaymentTransaction>>,
    onGoToPayment: () -> Unit
) {
    val transactions = (transactionsState as? UiState.Success)?.data.orEmpty()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (transactions.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "Belum Ada Transaksi",
                    description = "Semua pembayaran upgrade paket NEXORA PRO Anda akan tercatat di sini.",
                    actionLabel = "Upgrade ke Pro",
                    onAction = onGoToPayment
                )
            }
        } else {
            items(transactions, key = { it.id }) { tx ->
                val st = TransactionStatus.from(tx.status)
                val color = when (st) {
                    TransactionStatus.PAID -> NexoraSuccess
                    TransactionStatus.PENDING -> NexoraWarning
                    else -> NexoraError
                }
                GlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(tx.orderId, style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                            Text(formatRupiah(tx.amount), style = MaterialTheme.typography.titleLarge, color = NexoraTextPrimary)
                        }
                        StatusPill(st.value, color)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Metode: ${tx.paymentMethod.uppercase()} • ${formatTimestamp(tx.createdAt)}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                }
            }
        }
    }
}
