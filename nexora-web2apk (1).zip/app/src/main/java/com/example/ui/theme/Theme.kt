package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val NexoraDarkColorScheme = darkColorScheme(
    primary = NexoraElectricBlue,
    onPrimary = NexoraTextPrimary,
    primaryContainer = NexoraSurfaceElevated,
    onPrimaryContainer = NexoraCyanGlow,
    secondary = NexoraRoyalPurple,
    onSecondary = NexoraTextPrimary,
    secondaryContainer = Color(0xFF28194E),
    onSecondaryContainer = NexoraVioletAccent,
    tertiary = NexoraCyanGlow,
    onTertiary = NexoraObsidian,
    background = NexoraDeepNavy,
    onBackground = NexoraTextPrimary,
    surface = NexoraSurfaceDark,
    onSurface = NexoraTextPrimary,
    surfaceVariant = NexoraSurfaceCard,
    onSurfaceVariant = NexoraTextSecondary,
    outline = NexoraBorderSubtle,
    outlineVariant = Color(0xFF1A2546),
    error = NexoraError,
    onError = NexoraTextPrimary
)

private val NexoraShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NexoraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = NexoraDarkColorScheme,
        typography = NexoraTypography,
        shapes = NexoraShapes,
        content = content
    )
}
