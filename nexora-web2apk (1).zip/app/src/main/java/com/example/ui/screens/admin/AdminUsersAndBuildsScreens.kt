package com.example.ui.screens.admin

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.model.ApkBuild
import com.example.data.model.BuildStatus
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.remote.RfBuilderService
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.GlassCard
import com.example.ui.components.GradientPrimaryButton
import com.example.ui.components.StatusPill
import com.example.ui.components.formatTimestamp
import com.example.ui.components.openExternalUrl
import com.example.ui.screens.user.BuildSummaryCard
import com.example.ui.theme.NexoraCyanGlow
import com.example.ui.theme.NexoraElectricBlue
import com.example.ui.theme.NexoraError
import com.example.ui.theme.NexoraSuccess
import com.example.ui.theme.NexoraTextPrimary
import com.example.ui.theme.NexoraTextSecondary
import com.example.ui.theme.NexoraVioletAccent

@Composable
fun AdminUsersScreen(
    usersState: UiState<List<UserProfile>>,
    onOpenUserDetail: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    val users = (usersState as? UiState.Success)?.data.orEmpty()
    val filtered = remember(users, query, filter) {
        users.filter { u ->
            val qMatch = query.isBlank() || u.name.contains(query, true) || u.email.contains(query, true)
            val fMatch = when (filter) {
                "pro" -> u.plan == "pro"
                "free" -> u.plan == "free"
                "suspended" -> u.status == "suspended"
                else -> true
            }
            qMatch && fMatch
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Cari nama atau email pengguna") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("all" to "Semua", "pro" to "Pro", "free" to "Free", "suspended" to "Suspended")) { (k, label) ->
                    FilterChip(selected = filter == k, onClick = { filter = k }, label = { Text(label) })
                }
            }
        }
        if (filtered.isEmpty()) {
            item {
                EmptyStateCard("Pengguna Tidak Ditemukan", "Tidak ada pengguna yang cocok dengan pencarian Anda.")
            }
        } else {
            items(filtered, key = { it.userId }) { user ->
                GlassCard(onClick = { onOpenUserDetail(user.userId) }) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(user.name, style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                            Text(user.email, style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                        }
                        StatusPill(
                            label = user.plan.uppercase(),
                            color = if (user.plan == "pro") NexoraVioletAccent else NexoraElectricBlue
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusPill(user.status.uppercase(), if (user.status == "active") NexoraSuccess else NexoraError)
                        StatusPill(user.role.uppercase(), NexoraCyanGlow)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminUserDetailScreen(
    userId: String,
    usersState: UiState<List<UserProfile>>,
    onUpdateUser: (targetUid: String, status: String, plan: String) -> Unit,
    onBack: () -> Unit
) {
    val user = (usersState as? UiState.Success)?.data?.firstOrNull { it.userId == userId }
    var status by remember { mutableStateOf("active") }
    var plan by remember { mutableStateOf("free") }

    LaunchedEffect(user) {
        if (user != null) {
            status = user.status
            plan = user.plan
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (user == null) {
            item {
                EmptyStateCard("Pengguna Tidak Ditemukan", "Data pengguna tidak tersedia.", "Kembali", onBack)
            }
            return@LazyColumn
        }

        item {
            GlassCard {
                Text(user.name, style = MaterialTheme.typography.headlineMedium, color = NexoraTextPrimary)
                Text(user.email, style = MaterialTheme.typography.bodyLarge, color = NexoraCyanGlow)
                Text("UID: ${user.userId}", style = MaterialTheme.typography.labelSmall, color = NexoraTextSecondary)
                Text("Terdaftar: ${formatTimestamp(user.createdAt)}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
            }
        }

        item {
            GlassCard {
                Text("Status Akun", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = status == "active", onClick = { status = "active" })
                    Text("Active", color = NexoraTextPrimary)
                    RadioButton(selected = status == "suspended", onClick = { status = "suspended" })
                    Text("Suspended", color = NexoraError)
                }
                Spacer(Modifier.height(10.dp))
                Text("Paket Langganan", style = MaterialTheme.typography.titleMedium, color = NexoraTextPrimary)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = plan == "free", onClick = { plan = "free" })
                    Text("Free", color = NexoraTextPrimary)
                    RadioButton(selected = plan == "pro", onClick = { plan = "pro" })
                    Text("Pro", color = NexoraVioletAccent)
                }
                Spacer(Modifier.height(14.dp))
                GradientPrimaryButton(
                    text = "Simpan Perubahan Pengguna",
                    onClick = { onUpdateUser(user.userId, status, plan) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text("Kembali")
                }
            }
        }
    }
}

@Composable
fun AdminBuildsScreen(
    buildsState: UiState<List<ApkBuild>>,
    onOpenBuildDetail: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("all") }
    val builds = (buildsState as? UiState.Success)?.data.orEmpty()
    val filtered = remember(builds, query, statusFilter) {
        builds.filter { b ->
            val qMatch = query.isBlank() || b.appName.contains(query, true) || b.packageName.contains(query, true) || (b.buildId?.contains(query, true) == true)
            val sMatch = statusFilter == "all" || b.status == statusFilter
            qMatch && sMatch
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Cari app name, package, atau Build ID") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("all" to "Semua", "success" to "Success", "failed" to "Failed", "processing" to "Processing")) { (k, label) ->
                    FilterChip(selected = statusFilter == k, onClick = { statusFilter = k }, label = { Text(label) })
                }
            }
        }
        if (filtered.isEmpty()) {
            item { EmptyStateCard("Belum Ada Build", "Belum ada riwayat build di sistem.") }
        } else {
            items(filtered, key = { it.id }) { build ->
                BuildSummaryCard(build = build) { onOpenBuildDetail(build.id) }
            }
        }
    }
}

@Composable
fun AdminBuildDetailScreen(
    buildId: String,
    buildsState: UiState<List<ApkBuild>>,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val build = (buildsState as? UiState.Success)?.data?.firstOrNull { it.id == buildId }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (build == null) {
            item { EmptyStateCard("Build Tidak Ditemukan", "Data build tidak tersedia.", "Kembali", onBack) }
            return@LazyColumn
        }
        val status = BuildStatus.from(build.status)
        item {
            GlassCard {
                Text(build.appName, style = MaterialTheme.typography.headlineMedium, color = NexoraTextPrimary)
                Text(build.packageName, style = MaterialTheme.typography.labelSmall, color = NexoraCyanGlow)
                Spacer(Modifier.height(8.dp))
                Text("User UID: ${build.userId}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                Text("Build ID: ${build.buildId ?: build.id}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextSecondary)
                Text("Sumber: ${build.sourceType} — ${build.sourceValue}", style = MaterialTheme.typography.bodyMedium, color = NexoraTextPrimary)
                Text("Status: ${status.value.uppercase()}", style = MaterialTheme.typography.titleMedium, color = NexoraCyanGlow)
                if (!build.errorMessage.isNullOrBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Error Detail: ${build.errorMessage}", style = MaterialTheme.typography.bodyMedium, color = NexoraError)
                }
                Spacer(Modifier.height(12.dp))
                val dl = build.downloadUrl
                if (status == BuildStatus.SUCCESS && !dl.isNullOrBlank() && RfBuilderService.isTrustedDownloadUrl(dl)) {
                    GradientPrimaryButton("Download APK", onClick = { openExternalUrl(context, dl) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth().height(48.dp)) {
                    Text("Kembali ke Semua Build")
                }
            }
        }
    }
}
