package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NexoraDeepNavy = Color(0xFF060A18)
val NexoraObsidian = Color(0xFF03050C)
val NexoraSurfaceDark = Color(0xFF0B1124)
val NexoraSurfaceCard = Color(0xFF121B36)
val NexoraSurfaceElevated = Color(0xFF192447)
val NexoraBorderSubtle = Color(0xFF26345E)

val NexoraElectricBlue = Color(0xFF2E90FA)
val NexoraCyanGlow = Color(0xFF38BDF8)
val NexoraRoyalPurple = Color(0xFF7C3AED)
val NexoraVioletAccent = Color(0xFFA855F7)

val NexoraTextPrimary = Color(0xFFF8FAFC)
val NexoraTextSecondary = Color(0xFF94A3B8)
val NexoraTextMuted = Color(0xFF64748B)

val NexoraSuccess = Color(0xFF10B981)
val NexoraWarning = Color(0xFFF59E0B)
val NexoraError = Color(0xFFEF4444)
val NexoraAdminCrimson = Color(0xFFF43F5E)
