package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Announcement
import com.example.data.model.ApkBuild
import com.example.data.model.BuildUsage
import com.example.data.model.PackagePlan
import com.example.data.model.PaymentTransaction
import com.example.data.model.PlatformSettings
import com.example.data.model.SupportTicket
import com.example.data.model.Testimonial
import com.example.data.model.UiState
import com.example.data.model.UserNotification
import com.example.data.model.UserProfile
import com.example.data.model.UserSubscription
import com.example.data.repository.NexoraRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class UserViewModel(
    private val repository: NexoraRepository,
    val currentUserId: String
) : ViewModel() {

    val userProfile: StateFlow<UiState<UserProfile?>> =
        repository.observeUserProfile(currentUserId).asUiState("userProfile")

    val builds: StateFlow<UiState<List<ApkBuild>>> =
        repository.observeUserBuilds(currentUserId).asUiState("builds")

    val todayUsage: StateFlow<UiState<BuildUsage?>> =
        repository.observeTodayUsage(currentUserId).asUiState("todayUsage")

    val subscription: StateFlow<UiState<UserSubscription?>> =
        repository.observeSubscription(currentUserId).asUiState("subscription")

    val transactions: StateFlow<UiState<List<PaymentTransaction>>> =
        repository.observeUserTransactions(currentUserId).asUiState("transactions")

    val tickets: StateFlow<UiState<List<SupportTicket>>> =
        repository.observeUserTickets(currentUserId).asUiState("tickets")

    val notifications: StateFlow<UiState<List<UserNotification>>> =
        repository.observeUserNotifications(currentUserId).asUiState("notifications")

    val packages: StateFlow<UiState<List<PackagePlan>>> =
        repository.observePackages().asUiState("packages")

    val testimonials: StateFlow<UiState<List<Testimonial>>> =
        repository.observePublishedTestimonials().asUiState("testimonials")

    val announcements: StateFlow<UiState<List<Announcement>>> =
        repository.observeActiveAnnouncements().asUiState("announcements")

    val platformSettings: StateFlow<UiState<PlatformSettings>> =
        repository.observePlatformSettings().asUiState("platformSettings")

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage = _toastMessage.asStateFlow()

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(message: String) {
        _toastMessage.value = message
    }

    fun updateProfile(name: String, photoUrl: String?) {
        viewModelScope.launch {
            val result = repository.updateProfileNameAndPhoto(name, photoUrl)
            _toastMessage.value = result.fold(
                onSuccess = { "Profil berhasil diperbarui." },
                onFailure = { it.localizedMessage ?: "Gagal memperbarui profil." }
            )
        }
    }

    fun createSupportTicket(
        category: String,
        buildId: String?,
        message: String,
        screenshotUrl: String?,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.createSupportTicket(category, buildId, message, screenshotUrl)
            result.fold(
                onSuccess = { ticketId ->
                    _toastMessage.value = "Tiket kendala berhasil dikirim."
                    onSuccess(ticketId)
                },
                onFailure = {
                    _toastMessage.value = it.localizedMessage ?: "Gagal mengirim tiket."
                }
            )
        }
    }

    fun markNotificationRead(notificationId: String) {
        viewModelScope.launch {
            repository.markNotificationRead(notificationId)
        }
    }

    fun deleteDraft(docId: String) {
        viewModelScope.launch {
            val res = repository.deleteDraftBuild(docId)
            _toastMessage.value = res.fold(
                onSuccess = { "Draft build dihapus." },
                onFailure = { it.localizedMessage ?: "Gagal menghapus draft." }
            )
        }
    }

    private fun <T> Flow<T>.asUiState(label: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $label", rootError)
                emit(UiState.Error(rootError.message ?: "Gagal memuat $label"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    private companion object {
        const val TAG = "UserViewModel"
    }
}
