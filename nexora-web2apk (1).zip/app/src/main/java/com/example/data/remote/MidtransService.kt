package com.example.data.remote

import android.util.Base64
import com.example.BuildConfig
import com.example.data.model.TransactionStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

data class MidtransQrisChargeResult(
    val success: Boolean,
    val orderId: String,
    val transactionId: String? = null,
    val qrString: String? = null,
    val qrUrl: String? = null,
    val errorMessage: String? = null,
    val isConfigError: Boolean = false
)

data class MidtransStatusResult(
    val success: Boolean,
    val status: TransactionStatus = TransactionStatus.PENDING,
    val transactionId: String? = null,
    val grossAmount: String? = null,
    val errorMessage: String? = null
)

data class MidtransConfigStatus(
    val isConfigured: Boolean,
    val isProduction: Boolean,
    val maskedServerKey: String,
    val maskedClientKey: String
)

class MidtransService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    fun isProduction(): Boolean =
        BuildConfig.MIDTRANS_IS_PRODUCTION.equals("true", ignoreCase = true)

    fun isConfigured(): Boolean {
        val server = BuildConfig.MIDTRANS_SERVER_KEY
        val clientKey = BuildConfig.MIDTRANS_CLIENT_KEY
        return server.isNotBlank() &&
            server != "MY_MIDTRANS_SERVER_KEY" &&
            clientKey.isNotBlank() &&
            clientKey != "MY_MIDTRANS_CLIENT_KEY"
    }

    fun getConfigStatus(): MidtransConfigStatus {
        val server = BuildConfig.MIDTRANS_SERVER_KEY
        val cKey = BuildConfig.MIDTRANS_CLIENT_KEY
        return MidtransConfigStatus(
            isConfigured = isConfigured(),
            isProduction = isProduction(),
            maskedServerKey = mask(server, "MY_MIDTRANS_SERVER_KEY"),
            maskedClientKey = mask(cKey, "MY_MIDTRANS_CLIENT_KEY")
        )
    }

    private fun mask(value: String, placeholder: String): String {
        if (value.isBlank() || value == placeholder) return "Belum dikonfigurasi"
        return if (value.length <= 8) "••••${value.takeLast(2)}"
        else "${value.take(6)}••••••${value.takeLast(4)}"
    }

    private fun baseUrl(): String =
        if (isProduction()) "https://api.midtrans.com/v2" else "https://api.sandbox.midtrans.com/v2"

    private fun basicAuthHeader(): String {
        val raw = "${BuildConfig.MIDTRANS_SERVER_KEY}:"
        val encoded = Base64.encodeToString(raw.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        return "Basic $encoded"
    }

    suspend fun createQrisCharge(
        orderId: String,
        amount: Long,
        customerName: String,
        customerEmail: String
    ): MidtransQrisChargeResult = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext MidtransQrisChargeResult(
                success = false,
                orderId = orderId,
                errorMessage = "Konfigurasi Midtrans belum lengkap. Set MIDTRANS_SERVER_KEY dan MIDTRANS_CLIENT_KEY di Secrets panel AI Studio.",
                isConfigError = true
            )
        }

        val payload = JSONObject().apply {
            put("payment_type", "qris")
            put("transaction_details", JSONObject().apply {
                put("order_id", orderId)
                put("gross_amount", amount)
            })
            put("customer_details", JSONObject().apply {
                put("first_name", customerName.take(50))
                put("email", customerEmail)
            })
            put("qris", JSONObject().apply {
                put("acquirer", "gopay")
            })
        }

        val request = Request.Builder()
            .url("${baseUrl()}/charge")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .addHeader("Accept", "application/json")
            .addHeader("Content-Type", "application/json")
            .addHeader("Authorization", basicAuthHeader())
            .build()

        return@withContext try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (raw.isBlank()) {
                    return@use MidtransQrisChargeResult(
                        success = false,
                        orderId = orderId,
                        errorMessage = "Respons Midtrans kosong (HTTP ${response.code})."
                    )
                }
                val json = JSONObject(raw)
                val statusCode = json.optString("status_code")
                if (!response.isSuccessful || (statusCode != "201" && statusCode != "200")) {
                    return@use MidtransQrisChargeResult(
                        success = false,
                        orderId = orderId,
                        errorMessage = json.optString("status_message")
                            .ifBlank { "Gagal membuat transaksi Midtrans QRIS (HTTP ${response.code})." }
                    )
                }
                var qrUrl: String? = null
                val actions = json.optJSONArray("actions")
                if (actions != null) {
                    for (i in 0 until actions.length()) {
                        val action = actions.optJSONObject(i) ?: continue
                        if (action.optString("name") == "generate-qr-code") {
                            qrUrl = action.optString("url")
                            break
                        }
                    }
                }
                MidtransQrisChargeResult(
                    success = true,
                    orderId = orderId,
                    transactionId = json.optString("transaction_id").ifBlank { null },
                    qrString = json.optString("qr_string").ifBlank { null },
                    qrUrl = qrUrl
                )
            }
        } catch (e: Exception) {
            MidtransQrisChargeResult(
                success = false,
                orderId = orderId,
                errorMessage = "Gagal menghubungi Midtrans: ${e.localizedMessage ?: "Kesalahan jaringan"}"
            )
        }
    }

    suspend fun checkTransactionStatus(
        orderId: String,
        expectedAmount: Long
    ): MidtransStatusResult = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext MidtransStatusResult(
                success = false,
                errorMessage = "Konfigurasi Midtrans belum lengkap."
            )
        }

        val request = Request.Builder()
            .url("${baseUrl()}/$orderId/status")
            .get()
            .addHeader("Accept", "application/json")
            .addHeader("Authorization", basicAuthHeader())
            .build()

        return@withContext try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (raw.isBlank()) {
                    return@use MidtransStatusResult(false, errorMessage = "Respons status kosong.")
                }
                val json = JSONObject(raw)
                if (!response.isSuccessful) {
                    return@use MidtransStatusResult(
                        success = false,
                        errorMessage = json.optString("status_message")
                            .ifBlank { "Gagal memeriksa status (HTTP ${response.code})." }
                    )
                }
                val txStatus = json.optString("transaction_status")
                val statusCode = json.optString("status_code")
                val grossAmount = json.optString("gross_amount")
                val signatureKey = json.optString("signature_key")
                val transactionId = json.optString("transaction_id").ifBlank { null }

                if (signatureKey.isNotBlank()) {
                    val expectedSig = sha512("$orderId$statusCode$grossAmount${BuildConfig.MIDTRANS_SERVER_KEY}")
                    if (!expectedSig.equals(signatureKey, ignoreCase = true)) {
                        return@use MidtransStatusResult(
                            success = false,
                            errorMessage = "Signature Midtrans tidak valid."
                        )
                    }
                }

                val parsedAmount = grossAmount.toDoubleOrNull()?.toLong()
                if (parsedAmount != null && parsedAmount != expectedAmount) {
                    return@use MidtransStatusResult(
                        success = false,
                        errorMessage = "Nominal transaksi tidak sesuai."
                    )
                }

                val mappedStatus = when (txStatus.lowercase()) {
                    "settlement", "capture" -> TransactionStatus.PAID
                    "expire" -> TransactionStatus.EXPIRED
                    "cancel" -> TransactionStatus.CANCELLED
                    "deny", "failure" -> TransactionStatus.FAILED
                    else -> TransactionStatus.PENDING
                }

                MidtransStatusResult(
                    success = true,
                    status = mappedStatus,
                    transactionId = transactionId,
                    grossAmount = grossAmount
                )
            }
        } catch (e: Exception) {
            MidtransStatusResult(
                success = false,
                errorMessage = "Gagal memeriksa status Midtrans: ${e.localizedMessage ?: "Kesalahan jaringan"}"
            )
        }
    }

    private fun sha512(input: String): String {
        val digest = MessageDigest.getInstance("SHA-512").digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
