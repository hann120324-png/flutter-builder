package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Announcement
import com.example.data.model.ApkBuild
import com.example.data.model.AuditLog
import com.example.data.model.BuildStatus
import com.example.data.model.BuildUsage
import com.example.data.model.PackagePlan
import com.example.data.model.PaymentTransaction
import com.example.data.model.PlatformSettings
import com.example.data.model.SupportTicket
import com.example.data.model.Testimonial
import com.example.data.model.TransactionStatus
import com.example.data.model.UserNotification
import com.example.data.model.UserProfile
import com.example.data.model.UserSubscription
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class NexoraRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Pengguna harus login dengan Google terlebih dahulu.")
    }

    fun isBootstrappedAdmin(email: String?, isVerified: Boolean): Boolean =
        email.equals(AuthRepository.BOOTSTRAPPED_ADMIN_EMAIL, ignoreCase = true) && isVerified

    fun todayDateKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun todayUsageDocId(uid: String): String =
        "${uid}_${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}"

    // --- Bootstrap User Profile & Catalog ---

    suspend fun ensureUserProfile(user: FirebaseUser): Result<Unit> {
        val uid = user.uid
        val path = "users/$uid"
        return try {
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            val adminRole = if (isBootstrappedAdmin(user.email, user.isEmailVerified)) "admin" else "user"
            if (!snap.exists()) {
                val payload = mapOf(
                    "userId" to uid,
                    "name" to (user.displayName?.take(80)?.ifBlank { "Pengguna NEXORA" } ?: "Pengguna NEXORA"),
                    "email" to (user.email ?: "user@nexora.app"),
                    "photoUrl" to user.photoUrl?.toString()?.take(500),
                    "role" to adminRole,
                    "status" to "active",
                    "plan" to "free",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()

                val subRef = db.collection("subscriptions").document(uid)
                val subPayload = mapOf(
                    "userId" to uid,
                    "packageCode" to "free",
                    "status" to "active",
                    "startedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                subRef.set(subPayload).await()
            } else if (adminRole == "admin" && snap.getString("role") != "admin") {
                docRef.update(
                    mapOf(
                        "role" to "admin",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            if (adminRole == "admin") {
                ensureDefaultCatalogAndSettings()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private suspend fun ensureDefaultCatalogAndSettings() {
        try {
            val freeRef = db.collection("packages").document("free")
            if (!freeRef.get().await().exists()) {
                freeRef.set(
                    mapOf(
                        "code" to "free",
                        "name" to "FREE",
                        "price" to 0L,
                        "dailyQuota" to 3L,
                        "description" to "Mulai ubah website menjadi APK Android secara gratis.",
                        "features" to listOf(
                            "3 kali build per hari",
                            "Build dari URL, HTML offline, & ZIP offline",
                            "Upload icon & custom splash screen",
                            "Pengaturan package name, versi, & orientasi",
                            "Android permissions & riwayat build",
                            "Download APK langsung"
                        ),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            val proRef = db.collection("packages").document("pro")
            if (!proRef.get().await().exists()) {
                proRef.set(
                    mapOf(
                        "code" to "pro",
                        "name" to "NEXORA PRO",
                        "price" to 10000L,
                        "dailyQuota" to -1L,
                        "description" to "Kuota internal tanpa batas harian mengikuti kapasitas API RFBuilder.",
                        "features" to listOf(
                            "Semua fitur paket Free",
                            "Kuota internal NEXORA tanpa batas harian",
                            "Mengikuti limit kapasitas API RFBuilder aktif",
                            "Riwayat build & download APK lengkap",
                            "Prioritas dukungan kendala"
                        ),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            val settingsRef = db.collection("settings").document("platform")
            if (!settingsRef.get().await().exists()) {
                settingsRef.set(
                    mapOf(
                        "platformName" to "NEXORA WEB2APK",
                        "tagline" to "Your Website, Your Android App.",
                        "description" to "Platform mudah untuk mengubah website menjadi aplikasi Android APK secara online.",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "packages/settings")
        }
    }

    // --- Real-time Observers (User Scoped) ---

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { it.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamError(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeUserBuilds(userId: String): Flow<List<ApkBuild>> = flow {
        val path = "builds"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ApkBuild::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeTodayUsage(userId: String): Flow<BuildUsage?> = flow {
        val docId = todayUsageDocId(userId)
        val path = "build_usage/$docId"
        emitAll(
            db.collection("build_usage").document(docId)
                .snapshots()
                .map { it.toObject(BuildUsage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamError(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeSubscription(userId: String): Flow<UserSubscription?> = flow {
        val path = "subscriptions/$userId"
        emitAll(
            db.collection("subscriptions").document(userId)
                .snapshots()
                .map { it.toObject(UserSubscription::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    logStreamError(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeUserTransactions(userId: String): Flow<List<PaymentTransaction>> = flow {
        val path = "transactions"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(PaymentTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeUserTickets(userId: String): Flow<List<SupportTicket>> = flow {
        val path = "support_tickets"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(SupportTicket::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeUserNotifications(userId: String): Flow<List<UserNotification>> = flow {
        val path = "notifications"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(UserNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observePackages(): Flow<List<PackagePlan>> = flow {
        val path = "packages"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(PackagePlan::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.price }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, auth.currentUser?.uid ?: "")
                    throw error
                }
        )
    }

    fun observePublishedTestimonials(): Flow<List<Testimonial>> = flow {
        val path = "testimonials"
        emitAll(
            db.collection(path)
                .whereEqualTo("status", "published")
                .snapshots()
                .map { snap ->
                    snap.toObjects(Testimonial::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, auth.currentUser?.uid ?: "")
                    throw error
                }
        )
    }

    fun observeActiveAnnouncements(): Flow<List<Announcement>> = flow {
        val path = "announcements"
        emitAll(
            db.collection(path)
                .whereEqualTo("active", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(Announcement::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, path, auth.currentUser?.uid ?: "")
                    throw error
                }
        )
    }

    fun observePlatformSettings(): Flow<PlatformSettings> = flow {
        val path = "settings/platform"
        emitAll(
            db.collection("settings").document("platform")
                .snapshots()
                .map { snap ->
                    snap.toObject(PlatformSettings::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?: PlatformSettings()
                }
                .catch { error ->
                    logStreamError(error, OperationType.GET, path, auth.currentUser?.uid ?: "")
                    throw error
                }
        )
    }

    // --- User Mutations ---

    suspend fun updateProfileNameAndPhoto(name: String, photoUrl: String?): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Belum login"))
        val path = "users/$uid"
        return try {
            require(name.trim().length in 1..80) { "Nama harus 1-80 karakter." }
            val updates = mutableMapOf<String, Any>(
                "name" to name.trim(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!photoUrl.isNullOrBlank()) {
                updates["photoUrl"] = photoUrl.take(500)
            }
            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun createBuildRecord(
        appName: String,
        packageName: String,
        versionName: String,
        versionCode: Long,
        sourceType: String,
        sourceValue: String,
        splashType: String,
        orientation: String,
        permissions: List<String>,
        status: BuildStatus
    ): Result<String> {
        val docId = "bld_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        val path = "builds/$docId"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "userId" to uid,
                "appName" to appName.trim().take(80),
                "packageName" to packageName.trim().take(120),
                "versionName" to versionName.trim().take(40),
                "versionCode" to versionCode.coerceAtLeast(1L),
                "sourceType" to sourceType,
                "sourceValue" to sourceValue.take(2000),
                "splashType" to splashType,
                "orientation" to orientation,
                "permissions" to permissions.take(25),
                "status" to status.value,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("builds").document(docId).set(payload).await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun completeBuildSuccess(
        docId: String,
        rfBuildId: String,
        fileName: String,
        fileSize: String,
        downloadUrl: String
    ): Result<Unit> {
        val path = "builds/$docId"
        return try {
            val uid = requireUserId()
            db.collection("builds").document(docId).update(
                mapOf(
                    "buildId" to rfBuildId.take(128),
                    "status" to BuildStatus.SUCCESS.value,
                    "fileName" to fileName.take(200),
                    "fileSize" to fileSize.take(64),
                    "downloadUrl" to downloadUrl.take(1000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            incrementTodayBuildUsage(uid)
            createUserNotification(
                userId = uid,
                title = "Build APK Berhasil",
                message = "$fileName ($fileSize) siap didownload. Build ID: $rfBuildId"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun completeBuildFailure(docId: String, errorMessage: String): Result<Unit> {
        val path = "builds/$docId"
        return try {
            val uid = requireUserId()
            db.collection("builds").document(docId).update(
                mapOf(
                    "status" to BuildStatus.FAILED.value,
                    "errorMessage" to errorMessage.take(1000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            createUserNotification(
                userId = uid,
                title = "Build APK Gagal",
                message = errorMessage.take(300)
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteDraftBuild(docId: String): Result<Unit> {
        val path = "builds/$docId"
        return try {
            requireUserId()
            db.collection("builds").document(docId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private suspend fun incrementTodayBuildUsage(uid: String) {
        val docId = todayUsageDocId(uid)
        val path = "build_usage/$docId"
        try {
            val docRef = db.collection("build_usage").document(docId)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "date" to todayDateKey(),
                        "totalBuild" to 1L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val current = snap.getLong("totalBuild") ?: 0L
                docRef.update(
                    mapOf(
                        "totalBuild" to current + 1L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
        }
    }

    suspend fun createPendingTransaction(
        orderId: String,
        amount: Long,
        qrString: String?,
        qrUrl: String?,
        midtransTransactionId: String?
    ): Result<Unit> {
        val path = "transactions/$orderId"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "userId" to uid,
                "orderId" to orderId,
                "packageCode" to "pro",
                "amount" to amount,
                "status" to TransactionStatus.PENDING.value,
                "paymentMethod" to "qris",
                "qrString" to qrString?.take(2000),
                "qrUrl" to qrUrl?.take(1000),
                "midtransTransactionId" to midtransTransactionId?.take(128),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            db.collection("transactions").document(orderId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateTransactionFromMidtrans(
        orderId: String,
        newStatus: TransactionStatus,
        midtransTransactionId: String?
    ): Result<Unit> {
        val path = "transactions/$orderId"
        return try {
            val uid = requireUserId()
            val txUpdates = mutableMapOf<String, Any>(
                "status" to newStatus.value,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!midtransTransactionId.isNullOrBlank()) {
                txUpdates["midtransTransactionId"] = midtransTransactionId.take(128)
            }
            if (newStatus == TransactionStatus.PAID) {
                txUpdates["paidAt"] = FieldValue.serverTimestamp()
            }
            db.collection("transactions").document(orderId).update(txUpdates).await()

            if (newStatus == TransactionStatus.PAID) {
                db.collection("subscriptions").document(uid).set(
                    mapOf(
                        "userId" to uid,
                        "packageCode" to "pro",
                        "status" to "active",
                        "orderId" to orderId,
                        "startedAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                db.collection("users").document(uid).update(
                    mapOf(
                        "plan" to "pro",
                        "lastPaidOrderId" to orderId,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                createUserNotification(
                    userId = uid,
                    title = "NEXORA PRO Aktif",
                    message = "Pembayaran Order $orderId berhasil dikonfirmasi. Akun Anda kini menggunakan paket NEXORA PRO."
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun createSupportTicket(
        category: String,
        buildId: String?,
        message: String,
        screenshotUrl: String?
    ): Result<String> {
        val ticketId = "tkt_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "support_tickets/$ticketId"
        return try {
            val user = auth.currentUser
                ?: throw IllegalStateException("Pengguna belum login.")
            require(message.trim().length in 5..2000) { "Deskripsi kendala minimal 5 karakter." }
            val payload = mapOf(
                "userId" to user.uid,
                "userEmail" to (user.email ?: "user@nexora.app"),
                "userName" to (user.displayName?.ifBlank { "Pengguna" } ?: "Pengguna"),
                "buildId" to buildId?.trim()?.take(128)?.ifBlank { null },
                "category" to category.trim().take(80),
                "message" to message.trim().take(2000),
                "screenshotUrl" to screenshotUrl?.take(1000)?.ifBlank { null },
                "status" to "open",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            db.collection("support_tickets").document(ticketId).set(payload).await()
            Result.success(ticketId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> {
        val path = "notifications/$notificationId"
        return try {
            requireUserId()
            db.collection("notifications").document(notificationId)
                .update("read", true)
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    private suspend fun createUserNotification(userId: String, title: String, message: String) {
        val notifId = "ntf_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "notifications/$notifId"
        try {
            db.collection("notifications").document(notifId).set(
                mapOf(
                    "userId" to userId,
                    "title" to title.take(120),
                    "message" to message.take(1000),
                    "read" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
        }
    }

    // --- Admin Observers ---

    fun observeAllUsers(): Flow<List<UserProfile>> = observeAdminCollection("users", UserProfile::class.java) {
        it.sortedByDescending { u -> u.createdAt ?: Timestamp(0, 0) }
    }

    fun observeAllBuilds(): Flow<List<ApkBuild>> = observeAdminCollection("builds", ApkBuild::class.java) {
        it.sortedByDescending { b -> b.createdAt ?: Timestamp(0, 0) }
    }

    fun observeAllTransactions(): Flow<List<PaymentTransaction>> = observeAdminCollection("transactions", PaymentTransaction::class.java) {
        it.sortedByDescending { t -> t.createdAt ?: Timestamp(0, 0) }
    }

    fun observeAllSubscriptions(): Flow<List<UserSubscription>> = observeAdminCollection("subscriptions", UserSubscription::class.java) {
        it.sortedByDescending { s -> s.updatedAt ?: Timestamp(0, 0) }
    }

    fun observeAllTickets(): Flow<List<SupportTicket>> = observeAdminCollection("support_tickets", SupportTicket::class.java) {
        it.sortedByDescending { t -> t.createdAt ?: Timestamp(0, 0) }
    }

    fun observeAllTestimonials(): Flow<List<Testimonial>> = observeAdminCollection("testimonials", Testimonial::class.java) {
        it.sortedByDescending { t -> t.createdAt ?: Timestamp(0, 0) }
    }

    fun observeAllAnnouncements(): Flow<List<Announcement>> = observeAdminCollection("announcements", Announcement::class.java) {
        it.sortedByDescending { a -> a.createdAt ?: Timestamp(0, 0) }
    }

    fun observeAuditLogs(): Flow<List<AuditLog>> = observeAdminCollection("audit_logs", AuditLog::class.java) {
        it.sortedByDescending { l -> l.createdAt ?: Timestamp(0, 0) }
    }

    private fun <T> observeAdminCollection(
        collection: String,
        clazz: Class<T>,
        sort: (List<T>) -> List<T>
    ): Flow<List<T>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection(collection)
                .snapshots()
                .map { snap -> sort(snap.toObjects(clazz, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)) }
                .catch { error ->
                    logStreamError(error, OperationType.LIST, collection, uid)
                    throw error
                }
        )
    }

    // --- Admin Mutations ---

    suspend fun adminUpdateUser(targetUid: String, status: String, plan: String): Result<Unit> {
        val path = "users/$targetUid"
        return try {
            val admin = auth.currentUser ?: throw IllegalStateException("Belum login")
            db.collection("users").document(targetUid).update(
                mapOf(
                    "status" to status,
                    "plan" to plan,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            db.collection("subscriptions").document(targetUid).set(
                mapOf(
                    "userId" to targetUid,
                    "packageCode" to plan,
                    "status" to if (status == "active") "active" else "cancelled",
                    "startedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            recordAuditLog(admin, "UPDATE_USER", "Updated user $targetUid -> status=$status, plan=$plan")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminUpdatePackage(
        code: String,
        name: String,
        price: Long,
        dailyQuota: Long,
        description: String,
        features: List<String>
    ): Result<Unit> {
        val path = "packages/$code"
        return try {
            val admin = auth.currentUser ?: throw IllegalStateException("Belum login")
            db.collection("packages").document(code).set(
                mapOf(
                    "code" to code,
                    "name" to name.trim().take(60),
                    "price" to price.coerceAtLeast(0L),
                    "dailyQuota" to dailyQuota,
                    "description" to description.trim().take(500),
                    "features" to features.take(20),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            recordAuditLog(admin, "UPDATE_PACKAGE", "Updated package $code: Rp$price, quota=$dailyQuota")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminSaveTestimonial(
        id: String?,
        name: String,
        description: String,
        rating: Long,
        status: String,
        imageUrl: String?
    ): Result<Unit> {
        val docId = id?.takeIf { it.isNotBlank() } ?: "tst_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        val path = "testimonials/$docId"
        return try {
            val admin = auth.currentUser ?: throw IllegalStateException("Belum login")
            val existing = if (id != null) db.collection("testimonials").document(docId).get().await() else null
            val payload = mutableMapOf<String, Any>(
                "userId" to admin.uid,
                "name" to name.trim().take(80),
                "description" to description.trim().take(600),
                "rating" to rating.coerceIn(1L, 5L),
                "status" to status,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!imageUrl.isNullOrBlank()) {
                payload["imageUrl"] = imageUrl.trim().take(1000)
            }
            if (existing?.exists() == true) {
                db.collection("testimonials").document(docId).update(payload).await()
            } else {
                payload["createdAt"] = FieldValue.serverTimestamp()
                db.collection("testimonials").document(docId).set(payload).await()
            }
            recordAuditLog(admin, "SAVE_TESTIMONIAL", "Saved testimonial $docId ($status) for $name")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun adminDeleteTestimonial(docId: String): Result<Unit> {
        val path = "testimonials/$docId"
        return try {
            val admin = auth.currentUser ?: throw IllegalStateException("Belum login")
            db.collection("testimonials").document(docId).delete().await()
            recordAuditLog(admin, "DELETE_TESTIMONIAL", "Deleted testimonial $docId")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun adminReplySupportTicket(
        ticketId: String,
        status: String,
        adminReply: String
    ): Result<Unit> {
        val path = "support_tickets/$ticketId"
        return try {
            val admin = auth.currentUser ?: throw IllegalStateException("Belum login")
            val updates = mutableMapOf<String, Any>(
                "status" to status,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (adminReply.isNotBlank()) {
                updates["adminReply"] = adminReply.trim().take(2000)
            }
            db.collection("support_tickets").document(ticketId).update(updates).await()
            recordAuditLog(admin, "REPLY_TICKET", "Ticket $ticketId updated -> $status")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminSaveAnnouncement(title: String, message: String, active: Boolean): Result<Unit> {
        val docId = "ann_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        val path = "announcements/$docId"
        return try {
            val admin = auth.currentUser ?: throw IllegalStateException("Belum login")
            db.collection("announcements").document(docId).set(
                mapOf(
                    "title" to title.trim().take(120),
                    "message" to message.trim().take(1000),
                    "active" to active,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            recordAuditLog(admin, "CREATE_ANNOUNCEMENT", "Created announcement: $title (active=$active)")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminToggleAnnouncement(docId: String, active: Boolean): Result<Unit> {
        val path = "announcements/$docId"
        return try {
            val admin = auth.currentUser ?: throw IllegalStateException("Belum login")
            db.collection("announcements").document(docId).update(
                mapOf(
                    "active" to active,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            recordAuditLog(admin, "TOGGLE_ANNOUNCEMENT", "Announcement $docId active=$active")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun adminSavePlatformSettings(settings: PlatformSettings): Result<Unit> {
        val path = "settings/platform"
        return try {
            val admin = auth.currentUser ?: throw IllegalStateException("Belum login")
            val payload = mapOf(
                "platformName" to settings.platformName.trim().take(80),
                "tagline" to settings.tagline.trim().take(160),
                "description" to settings.description.trim().take(500),
                "whatsappAdmin" to settings.whatsappAdmin?.trim()?.take(40)?.ifBlank { null },
                "whatsappCs" to settings.whatsappCs?.trim()?.take(40)?.ifBlank { null },
                "whatsappChannel" to settings.whatsappChannel?.trim()?.take(300)?.ifBlank { null },
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            db.collection("settings").document("platform").set(payload).await()
            recordAuditLog(admin, "UPDATE_SETTINGS", "Updated platform & WhatsApp settings")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    private suspend fun recordAuditLog(admin: FirebaseUser, action: String, details: String) {
        val logId = "log_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "audit_logs/$logId"
        try {
            db.collection("audit_logs").document(logId).set(
                mapOf(
                    "adminId" to admin.uid,
                    "adminEmail" to (admin.email ?: "admin@nexora.app"),
                    "action" to action.take(100),
                    "details" to details.take(1000),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
        }
    }

    private fun logStreamError(
        error: Throwable,
        op: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
    }
}
