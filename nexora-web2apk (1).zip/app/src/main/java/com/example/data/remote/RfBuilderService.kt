package com.example.data.remote

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.BuildConfig
import com.example.data.model.ScreenOrientationOption
import com.example.data.model.SourceType
import com.example.data.model.SplashType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class RfBuildRequest(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Int,
    val sourceType: SourceType,
    val url: String,
    val sourceFileUri: Uri?,
    val iconUri: Uri?,
    val splashType: SplashType,
    val splashFileUri: Uri?,
    val orientation: ScreenOrientationOption,
    val permissions: List<String>
)

sealed interface RfBuildResult {
    data class Success(
        val buildId: String,
        val fileName: String,
        val size: String,
        val downloadUrl: String,
        val usedToday: Int,
        val remainingToday: Int,
        val limit: Int,
        val role: String,
        val splashType: String
    ) : RfBuildResult

    data class Failure(
        val httpCode: Int?,
        val message: String,
        val isConfigError: Boolean = false
    ) : RfBuildResult
}

data class RfConnectionStatus(
    val isKeyConfigured: Boolean,
    val maskedKey: String,
    val reachable: Boolean,
    val statusCode: Int?,
    val message: String
)

class RfBuilderService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    fun isConfigured(): Boolean {
        val key = BuildConfig.RFBUILDER_API_KEY
        return key.isNotBlank() && key != "MY_RFBUILDER_API_KEY"
    }

    fun maskedKey(): String {
        val key = BuildConfig.RFBUILDER_API_KEY
        if (!isConfigured()) return "Belum dikonfigurasi"
        return if (key.length <= 8) "••••${key.takeLast(2)}"
        else "${key.take(4)}••••••••${key.takeLast(4)}"
    }

    suspend fun testConnection(): RfConnectionStatus = withContext(Dispatchers.IO) {
        val configured = isConfigured()
        val masked = maskedKey()
        if (!configured) {
            return@withContext RfConnectionStatus(
                isKeyConfigured = false,
                maskedKey = masked,
                reachable = false,
                statusCode = null,
                message = "RFBUILDER_API_KEY belum diset di Secrets panel AI Studio."
            )
        }
        try {
            val request = Request.Builder()
                .url(BASE_URL)
                .head()
                .addHeader("X-API-Key", BuildConfig.RFBUILDER_API_KEY)
                .build()
            client.newCall(request).execute().use { response ->
                RfConnectionStatus(
                    isKeyConfigured = true,
                    maskedKey = masked,
                    reachable = response.code < 500,
                    statusCode = response.code,
                    message = if (response.code < 500) {
                        "Endpoint RFBuilder dapat dijangkau (HTTP ${response.code})."
                    } else {
                        "Server RFBuilder merespons HTTP ${response.code}."
                    }
                )
            }
        } catch (e: Exception) {
            RfConnectionStatus(
                isKeyConfigured = true,
                maskedKey = masked,
                reachable = false,
                statusCode = null,
                message = "Gagal terhubung ke RFBuilder: ${e.localizedMessage ?: "Kesalahan jaringan"}"
            )
        }
    }

    suspend fun buildApk(req: RfBuildRequest): RfBuildResult = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext RfBuildResult.Failure(
                httpCode = null,
                message = "Konfigurasi RFBUILDER_API_KEY belum lengkap. Silakan atur di panel Secrets AI Studio.",
                isConfigError = true
            )
        }

        if (!isValidPackageName(req.packageName)) {
            return@withContext RfBuildResult.Failure(
                httpCode = null,
                message = "Format package name tidak valid (contoh: com.nexora.aplikasi)."
            )
        }

        val bodyBuilder = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("appName", req.appName.trim())
            .addFormDataPart("packageName", req.packageName.trim())
            .addFormDataPart("versionName", req.versionName.trim())
            .addFormDataPart("versionCode", req.versionCode.toString())
            .addFormDataPart("orientation", req.orientation.value)
            .addFormDataPart("splashType", req.splashType.value)

        req.permissions.distinct().forEach { perm ->
            bodyBuilder.addFormDataPart("permissions", perm)
        }

        when (req.sourceType) {
            SourceType.URL -> {
                val url = req.url.trim()
                if (!url.startsWith("https://") && !url.startsWith("http://")) {
                    return@withContext RfBuildResult.Failure(
                        httpCode = null,
                        message = "URL website harus diawali https:// atau http://"
                    )
                }
                bodyBuilder.addFormDataPart("url", url)
            }
            SourceType.HTML -> {
                val uri = req.sourceFileUri ?: return@withContext RfBuildResult.Failure(
                    httpCode = null,
                    message = "File HTML belum dipilih."
                )
                val part = readUriAsRequestBody(uri, "text/html", MAX_ASSET_BYTES)
                    ?: return@withContext RfBuildResult.Failure(null, "File HTML gagal dibaca atau melebihi batas 15 MB.")
                bodyBuilder.addFormDataPart("html", part.first, part.second)
            }
            SourceType.ZIP -> {
                val uri = req.sourceFileUri ?: return@withContext RfBuildResult.Failure(
                    httpCode = null,
                    message = "File ZIP belum dipilih."
                )
                val part = readUriAsRequestBody(uri, "application/zip", MAX_ZIP_BYTES)
                    ?: return@withContext RfBuildResult.Failure(null, "File ZIP gagal dibaca atau melebihi batas 25 MB.")
                bodyBuilder.addFormDataPart("zip", part.first, part.second)
            }
        }

        req.iconUri?.let { iconUri ->
            val iconPart = readUriAsRequestBody(iconUri, "image/png", MAX_ICON_BYTES)
                ?: return@withContext RfBuildResult.Failure(null, "Icon PNG gagal dibaca atau melebihi batas 5 MB.")
            bodyBuilder.addFormDataPart("icon", iconPart.first, iconPart.second)
        }

        when (req.splashType) {
            SplashType.DEFAULT -> Unit
            SplashType.IMAGE -> {
                val uri = req.splashFileUri ?: return@withContext RfBuildResult.Failure(null, "Gambar splash belum dipilih.")
                val part = readUriAsRequestBody(uri, "image/*", MAX_ICON_BYTES)
                    ?: return@withContext RfBuildResult.Failure(null, "Gambar splash gagal dibaca atau melebihi 5 MB.")
                bodyBuilder.addFormDataPart("splash", part.first, part.second)
            }
            SplashType.HTML -> {
                val uri = req.splashFileUri ?: return@withContext RfBuildResult.Failure(null, "File HTML splash belum dipilih.")
                val part = readUriAsRequestBody(uri, "text/html", MAX_ICON_BYTES)
                    ?: return@withContext RfBuildResult.Failure(null, "File HTML splash gagal dibaca atau melebihi 5 MB.")
                bodyBuilder.addFormDataPart("splashHtml", part.first, part.second)
            }
            SplashType.VIDEO -> {
                val uri = req.splashFileUri ?: return@withContext RfBuildResult.Failure(null, "Video MP4 splash belum dipilih.")
                val part = readUriAsRequestBody(uri, "video/mp4", MAX_ASSET_BYTES)
                    ?: return@withContext RfBuildResult.Failure(null, "Video MP4 splash gagal dibaca atau melebihi 15 MB.")
                bodyBuilder.addFormDataPart("splashVideo", part.first, part.second)
            }
        }

        val httpRequest = Request.Builder()
            .url(BUILD_ENDPOINT)
            .post(bodyBuilder.build())
            .addHeader("X-API-Key", BuildConfig.RFBUILDER_API_KEY)
            .build()

        return@withContext try {
            client.newCall(httpRequest).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                when (response.code) {
                    401 -> RfBuildResult.Failure(401, "API Key RFBuilder tidak valid (HTTP 401).")
                    429 -> RfBuildResult.Failure(429, "Limit API RFBuilder habis untuk hari ini (HTTP 429).")
                    in 500..599 -> RfBuildResult.Failure(response.code, "Server RFBuilder mengalami masalah (HTTP ${response.code}).")
                    else -> parseResponseBody(response.code, response.isSuccessful, rawBody)
                }
            }
        } catch (e: IOException) {
            RfBuildResult.Failure(
                httpCode = null,
                message = "Koneksi ke RFBuilder terputus atau timeout: ${e.localizedMessage ?: "Periksa jaringan Anda"}"
            )
        } catch (e: Exception) {
            RfBuildResult.Failure(
                httpCode = null,
                message = "Terjadi kesalahan saat memproses build: ${e.localizedMessage ?: "Kesalahan tidak diketahui"}"
            )
        }
    }

    private fun parseResponseBody(code: Int, isHttpOk: Boolean, rawBody: String): RfBuildResult {
        if (rawBody.isBlank()) {
            return RfBuildResult.Failure(code, "Respons server kosong (HTTP $code).")
        }
        return try {
            val json = JSONObject(rawBody)
            val success = json.optBoolean("success", false)
            if (!isHttpOk || !success) {
                val err = json.optString("error").ifBlank { json.optString("message") }
                    .ifBlank { "Build gagal diproses oleh RFBuilder (HTTP $code)." }
                return RfBuildResult.Failure(code, err)
            }
            val downloadUrl = json.optString("downloadUrl")
            if (!isTrustedDownloadUrl(downloadUrl)) {
                return RfBuildResult.Failure(code, "URL download APK dari server tidak valid atau tidak terpercaya.")
            }
            RfBuildResult.Success(
                buildId = json.optString("buildId").ifBlank { "rf_${System.currentTimeMillis()}" },
                fileName = json.optString("fileName").ifBlank { "app-release.apk" },
                size = json.optString("size").ifBlank { "-" },
                downloadUrl = downloadUrl,
                usedToday = json.optInt("usedToday", 0),
                remainingToday = json.optInt("remainingToday", 0),
                limit = json.optInt("limit", 0),
                role = json.optString("role", "free"),
                splashType = json.optString("splashType", "default")
            )
        } catch (e: Exception) {
            RfBuildResult.Failure(code, "Format respons JSON dari RFBuilder tidak valid.")
        }
    }

    private fun readUriAsRequestBody(
        uri: Uri,
        fallbackMime: String,
        maxBytes: Int
    ): Pair<String, RequestBody>? {
        val resolver = context.contentResolver
        val fileName = resolveFileName(uri) ?: "upload_${System.currentTimeMillis()}"
        val mime = resolver.getType(uri) ?: fallbackMime
        val bytes = resolver.openInputStream(uri)?.use { input ->
            val buffer = input.readBytes()
            if (buffer.size > maxBytes) return null
            buffer
        } ?: return null
        return fileName to bytes.toRequestBody(mime.toMediaTypeOrNull())
    }

    private fun resolveFileName(uri: Uri): String? {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (nameIdx != -1 && cursor.moveToFirst()) {
                return cursor.getString(nameIdx)
            }
        }
        return uri.lastPathSegment
    }

    companion object {
        const val BASE_URL = "https://rfweb2apk.rfdevv.com"
        const val BUILD_ENDPOINT = "$BASE_URL/api/apk/build-api"
        private const val MAX_ICON_BYTES = 5 * 1024 * 1024
        private const val MAX_ASSET_BYTES = 15 * 1024 * 1024
        private const val MAX_ZIP_BYTES = 25 * 1024 * 1024

        private val PACKAGE_REGEX = Regex("^[a-z][a-z0-9_]*(\\.[a-z0-9_]+)+$")

        fun isValidPackageName(packageName: String): Boolean =
            PACKAGE_REGEX.matches(packageName.trim())

        fun isTrustedDownloadUrl(url: String): Boolean {
            if (url.isBlank()) return false
            val parsed = Uri.parse(url)
            val host = parsed.host?.lowercase().orEmpty()
            return parsed.scheme == "https" &&
                (host == "rfweb2apk.rfdevv.com" || host.endsWith(".rfdevv.com"))
        }
    }
}
