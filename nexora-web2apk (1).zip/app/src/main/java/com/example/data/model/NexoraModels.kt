package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class UserRole(val value: String) {
    USER("user"),
    ADMIN("admin");

    companion object {
        fun from(raw: String?): UserRole =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: USER
    }
}

enum class AccountStatus(val value: String) {
    ACTIVE("active"),
    SUSPENDED("suspended");

    companion object {
        fun from(raw: String?): AccountStatus =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: ACTIVE
    }
}

enum class PlanTier(val value: String) {
    FREE("free"),
    PRO("pro");

    companion object {
        fun from(raw: String?): PlanTier =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: FREE
    }
}

enum class BuildStatus(val value: String) {
    DRAFT("draft"),
    WAITING("waiting"),
    PROCESSING("processing"),
    SUCCESS("success"),
    FAILED("failed");

    companion object {
        fun from(raw: String?): BuildStatus =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: WAITING
    }
}

enum class SourceType(val value: String, val label: String) {
    URL("url", "Website URL"),
    HTML("html", "Upload HTML"),
    ZIP("zip", "Upload ZIP");

    companion object {
        fun from(raw: String?): SourceType =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: URL
    }
}

enum class SplashType(val value: String, val label: String) {
    DEFAULT("default", "Default"),
    IMAGE("image", "Image (PNG/JPG)"),
    HTML("html", "HTML File"),
    VIDEO("video", "Video (MP4)");

    companion object {
        fun from(raw: String?): SplashType =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: DEFAULT
    }
}

enum class ScreenOrientationOption(val value: String, val label: String) {
    PORTRAIT("portrait", "Portrait"),
    LANDSCAPE("landscape", "Landscape"),
    AUTO("auto", "Auto");

    companion object {
        fun from(raw: String?): ScreenOrientationOption =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: PORTRAIT
    }
}

enum class TransactionStatus(val value: String) {
    PENDING("pending"),
    PAID("paid"),
    EXPIRED("expired"),
    FAILED("failed"),
    CANCELLED("cancelled");

    companion object {
        fun from(raw: String?): TransactionStatus =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: PENDING
    }
}

enum class TicketStatus(val value: String, val label: String) {
    OPEN("open", "Open"),
    IN_PROGRESS("in_progress", "Diproses"),
    RESOLVED("resolved", "Selesai"),
    CLOSED("closed", "Ditutup");

    companion object {
        fun from(raw: String?): TicketStatus =
            entries.firstOrNull { it.value.equals(raw, ignoreCase = true) } ?: OPEN
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val email: String = "",
    val photoUrl: String? = null,
    val role: String = "user",
    val status: String = "active",
    val plan: String = "free",
    val lastPaidOrderId: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ApkBuild(
    @DocumentId val id: String = "",
    val userId: String = "",
    val buildId: String? = null,
    val appName: String = "",
    val packageName: String = "",
    val versionName: String = "1.0.0",
    val versionCode: Long = 1L,
    val sourceType: String = "url",
    val sourceValue: String = "",
    val splashType: String = "default",
    val orientation: String = "portrait",
    val permissions: List<String> = listOf("INTERNET", "ACCESS_NETWORK_STATE"),
    val status: String = "waiting",
    val fileName: String? = null,
    val fileSize: String? = null,
    val downloadUrl: String? = null,
    val errorMessage: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class BuildUsage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val date: String = "",
    val totalBuild: Long = 0L,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserSubscription(
    @DocumentId val id: String = "",
    val userId: String = "",
    val packageCode: String = "free",
    val status: String = "active",
    val orderId: String? = null,
    @ServerTimestamp val startedAt: Timestamp? = null,
    val expiresAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PaymentTransaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val orderId: String = "",
    val packageCode: String = "pro",
    val amount: Long = 10000L,
    val status: String = "pending",
    val paymentMethod: String = "qris",
    val qrString: String? = null,
    val qrUrl: String? = null,
    val midtransTransactionId: String? = null,
    val paidAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SupportTicket(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userEmail: String = "",
    val userName: String = "",
    val buildId: String? = null,
    val category: String = "",
    val message: String = "",
    val screenshotUrl: String? = null,
    val status: String = "open",
    val adminReply: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PackagePlan(
    @DocumentId val id: String = "",
    val code: String = "free",
    val name: String = "",
    val price: Long = 0L,
    val dailyQuota: Long = 3L,
    val description: String = "",
    val features: List<String> = emptyList(),
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Testimonial(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val imageUrl: String? = null,
    val description: String = "",
    val rating: Long = 5L,
    val status: String = "published",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserNotification(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val message: String = "",
    val read: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Announcement(
    @DocumentId val id: String = "",
    val title: String = "",
    val message: String = "",
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PlatformSettings(
    @DocumentId val id: String = "",
    val platformName: String = "NEXORA WEB2APK",
    val tagline: String = "Your Website, Your Android App.",
    val description: String = "Platform mudah untuk mengubah website menjadi aplikasi Android APK secara online.",
    val whatsappAdmin: String? = null,
    val whatsappCs: String? = null,
    val whatsappChannel: String? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AuditLog(
    @DocumentId val id: String = "",
    val adminId: String = "",
    val adminEmail: String = "",
    val action: String = "",
    val details: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
